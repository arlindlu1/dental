<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$user = Auth::user();
$clinicId = (int)($_SESSION['clinic_id'] ?? 0);
if ($clinicId <= 0) {
    // Invalid session or missing clinic context
    redirect('/login.php');
}
$db = Database::getInstance();

// If clinic already has required fields, redirect to dashboard
$stmtCheck = $db->prepare("SELECT name, address, phone, business_number, contact_person, contact_phone, city, postal_code, opening_hours, timezone, logo FROM clinics WHERE id = ? LIMIT 1");
$stmtCheck->bind_param("i", $clinicId);
$clinicRow = safe_stmt_fetch_assoc($stmtCheck);
// Consider both phone and contact_phone as valid phone values
$hasPhone = !empty($clinicRow['contact_phone']) || !empty($clinicRow['phone']);
if ($clinicRow && !empty($clinicRow['address']) && $hasPhone && !empty($clinicRow['business_number']) && !empty($clinicRow['contact_person'])) {
    redirect('/views/dashboard.php');
}

// Compute onboarding progress
$progressFields = ['business_number','contact_person','contact_phone','address','logo'];
$filled = 0;
foreach ($progressFields as $f) {
    if (!empty($clinicRow[$f])) $filled++;
}
$progress = (int) round(($filled / count($progressFields)) * 100);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid CSRF token.';
    } else {
        // Basic sanitization and length limits
        $business_number = substr(sanitize($_POST['business_number'] ?? ''), 0, 128);
        $contact_person = substr(sanitize($_POST['contact_person'] ?? ''), 0, 128);
        $contact_phone = substr(sanitize($_POST['contact_phone'] ?? ''), 0, 64);
        $address = substr(sanitize($_POST['address'] ?? ''), 0, 1000);
        $city = substr(sanitize($_POST['city'] ?? ''), 0, 128);
        $postal_code = substr(sanitize($_POST['postal_code'] ?? ''), 0, 64);
        $opening_hours = substr(sanitize($_POST['opening_hours'] ?? ''), 0, 1000);
        $timezone = substr(sanitize($_POST['timezone'] ?? ''), 0, 128);

        // No strict business number validation per request — accept freeform input

        // Handle logo upload if provided
        $logoPath = $clinicRow['logo'] ?? null;
        if (!empty($_FILES['logo']) && !empty($_FILES['logo']['name'])) {
            $upload = uploadFile($_FILES['logo'], 'clinics');
            if ($upload === false) {
                $errors[] = 'Logo upload failed. Ensure file is an image and writable uploads folder exists.';
            } else {
                $logoPath = $upload;
            }
        }

        $isDraft = !empty($_POST['save_draft']);

        if (!$isDraft && (empty($business_number) || empty($contact_person) || empty($contact_phone) || empty($address))) {
            $errors[] = lang('onboarding.fill_required', 'Please fill in all required fields: Business Number, Contact, Phone, Address.');
        } else {
            $stmt = $db->prepare("UPDATE clinics SET business_number = ?, contact_person = ?, contact_phone = ?, address = ?, city = ?, postal_code = ?, opening_hours = ?, timezone = ?, logo = ? WHERE id = ?");
            $stmt->bind_param("sssssssssi", $business_number, $contact_person, $contact_phone, $address, $city, $postal_code, $opening_hours, $timezone, $logoPath, $clinicId);
            $stmt->execute();

            if ($isDraft) {
                Auth::logActivity('save_onboarding_progress', 'clinic', $clinicId, json_encode(['by_user' => $user['id']]));
                redirect('/views/dashboard.php?onboard_draft=1');
            } else {
                Auth::logActivity('complete_onboarding', 'clinic', $clinicId, json_encode(['by_user' => $user['id']]));
                redirect('/views/dashboard.php?onboarded=1');
            }
        }
    }
}

include __DIR__ . '/layout/header.php';
?>
<div class="container" style="max-width:900px; margin:32px auto;">
    <div class="card">
        <h1><?= lang('onboarding.title', "Welcome — Let's set up your clinic") ?></h1>
        <p class="muted"><?= lang('onboarding.intro', 'Please provide your clinic\'s business details so we can complete your profile and enable billing, invoices and public-facing features.') ?></p>
        <div style="background:#fffbeb;border:1px solid #f5d0a9;padding:10px;border-radius:6px;margin:12px 0;display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#92400e;font-size:14px;">
                <?= lang('onboarding.complete_later_banner', 'You can save progress and complete onboarding later.') ?>
            </div>
            <div>
                <button type="button" id="saveDraftTop" class="btn btn-outline"><?= lang('onboarding.save_progress', 'Save progress') ?></button>
            </div>
        </div>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">

            <div style="margin-bottom:12px;">
                <label style="font-weight:600;"><?= lang('onboarding.progress', 'Onboarding progress') ?>: </label>
                <div style="background:#eef2f7; border-radius:8px; overflow:hidden; width:100%; height:12px; margin-top:6px;">
                    <div style="width:<?= $progress ?>%; height:100%; background: linear-gradient(90deg,#6366f1,#06b6d4);"></div>
                </div>
                <small style="color:#6b7280;"><?= $progress ?>% complete</small>
            </div>

            <div class="form-group">
                <label>Clinic Name</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($clinicRow['name'] ?? '') ?>" disabled>
            </div>

            <div class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div class="form-group">
                    <label>Business Number (Tax ID) *</label>
                    <input type="text" name="business_number" class="form-control" value="<?= htmlspecialchars($clinicRow['business_number'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Contact Person *</label>
                    <input type="text" name="contact_person" class="form-control" value="<?= htmlspecialchars($clinicRow['contact_person'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:12px;">
                <div class="form-group">
                    <label>Contact Phone *</label>
                    <input type="text" name="contact_phone" class="form-control" value="<?= htmlspecialchars($clinicRow['contact_phone'] ?? $clinicRow['phone'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Clinic Email</label>
                    <input type="email" name="clinic_email" class="form-control" value="<?= htmlspecialchars($clinicRow['email'] ?? '') ?>" disabled>
                </div>
            </div>

            <div class="form-group" style="margin-top:12px;">
                <label>Address *</label>
                <textarea name="address" class="form-control" rows="3" required><?= htmlspecialchars($clinicRow['address'] ?? '') ?></textarea>
            </div>

            <div class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:12px;">
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($clinicRow['city'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Postal Code</label>
                    <input type="text" name="postal_code" class="form-control" value="<?= htmlspecialchars($clinicRow['postal_code'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group" style="margin-top:12px;">
                <label>Opening Hours (optional)</label>
                <textarea name="opening_hours" class="form-control" rows="3"><?= htmlspecialchars($clinicRow['opening_hours'] ?? '') ?></textarea>
            </div>

            <div class="form-group" style="margin-top:12px;">
                <label><?= lang('onboarding.logo', 'Clinic Logo') ?></label>
                <div style="display:flex; gap:12px; align-items:center;">
                    <div>
                        <?php if (!empty($clinicRow['logo'])): ?>
                            <img id="logoPreview" src="<?= htmlspecialchars($clinicRow['logo']) ?>" style="max-width:120px; border-radius:8px; border:1px solid #e5e7eb;" />
                        <?php else: ?>
                            <img id="logoPreview" src="<?= asset('images/clinic-placeholder.png') ?>" style="max-width:120px; border-radius:8px; border:1px solid #e5e7eb;" />
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="logo" id="logoInput" accept="image/*">
                        <div style="margin-top:8px; color:#6b7280; font-size:13px;"><?= lang('onboarding.logo_help', 'PNG/JPG up to 2MB recommended') ?></div>
                    </div>
                </div>
            </div>

            <div class="form-group" style="margin-top:12px;">
                <label>Timezone</label>
                <input type="text" name="timezone" class="form-control" value="<?= htmlspecialchars($clinicRow['timezone'] ?? (defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Europe/Tirane')) ?>">
            </div>

            <div style="display:flex; gap:12px; margin-top:18px;">
                <button type="submit" class="btn btn-primary"><?= lang('onboarding.save_and_continue', 'Save and continue') ?></button>
                <button type="submit" name="save_draft" value="1" class="btn btn-outline"><?= lang('onboarding.save_progress', 'Save progress') ?></button>
                <a href="/views/dashboard.php" class="btn btn-secondary"><?= lang('onboarding.skip_for_now', 'Skip for now') ?></a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/layout/footer.php'; ?>
<script>
document.getElementById('logoInput')?.addEventListener('change', function(e){
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(ev){
        document.getElementById('logoPreview').src = ev.target.result;
    }
    reader.readAsDataURL(file);
});
// Top-banner save draft handler: submits the form as a draft
document.getElementById('saveDraftTop')?.addEventListener('click', function(){
    const form = document.querySelector('form');
    if (!form) return;
    let hidden = form.querySelector('input[name="save_draft"]');
    if (!hidden) {
        hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'save_draft';
        hidden.value = '1';
        form.appendChild(hidden);
    }
    form.submit();
});
</script>
