<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$patientId = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_tooth_treatment'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    try {
        $patientId = (int)$_POST['patient_id'];
        $doctorId = (int)$_POST['doctor_id'];
        $date = $_POST['date'];
        $procedure = sanitize($_POST['procedure']);
        $toothNumber = sanitize($_POST['tooth_number']);
        $notes = sanitize($_POST['notes'] ?? '');
        $status = sanitize($_POST['status'] ?? 'filling');
        
        // Start transaction
        $db->query("START TRANSACTION");
        
        // 1. Insert treatment record (without price)
        $stmt = $db->prepare("INSERT INTO treatments (clinic_id, patient_id, doctor_id, date, `procedure`, tooth_number, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiissss", $clinicId, $patientId, $doctorId, $date, $procedure, $toothNumber, $notes);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to insert treatment");
        }
        
        $treatmentId = $stmt->insert_id;
        
        // 2. Update or insert tooth chart record
        $stmt = $db->prepare("INSERT INTO patient_tooth_records (patient_id, clinic_id, tooth_number, status, notes, doctor_id, date) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status), notes = VALUES(notes), doctor_id = VALUES(doctor_id), date = VALUES(date)");
        $stmt->bind_param("iisssis", $patientId, $clinicId, $toothNumber, $status, $notes, $doctorId, $date);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update tooth record");
        }
        
        // Commit transaction
        $db->query("COMMIT");
        
        Auth::logActivity('create_treatment', 'treatment', $treatmentId, "Created treatment for tooth $toothNumber");
        
        redirect('/views/patients/view.php?id=' . $patientId . '&tab=toothchart&success=1');
        
    } catch (Exception $e) {
        $db->query("ROLLBACK");
        error_log("Tooth treatment error: " . $e->getMessage());
        redirect('/views/patients/view.php?id=' . $patientId . '&tab=toothchart&error=' . urlencode($e->getMessage()));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $uploadDir = __DIR__ . '/../../uploads/documents/' . $clinicId . '/' . $patientId . '/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $file = $_FILES['document'];
    $fileName = time() . '_' . basename($file['name']);
    $filePath = $uploadDir . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        $description = $_POST['description'] ?? '';
        
        $stmt = $db->prepare("INSERT INTO patient_files (patient_id, clinic_id, file_name, file_path, file_type, file_size, description, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $relPath = '/uploads/documents/' . $clinicId . '/' . $patientId . '/' . $fileName;
        $fileType = $file['type'];
        $fileSize = $file['size'];
        $stmt->bind_param("iisssiis", $patientId, $clinicId, $fileName, $relPath, $fileType, $fileSize, $description, $userId);
        $stmt->execute();
        
        redirect('/views/patients/view.php?id=' . $patientId . '&tab=documents');
    }
}

if (isset($_GET['delete_doc'])) {
    $docId = (int)$_GET['delete_doc'];
    $stmt = $db->prepare("SELECT file_path FROM patient_files WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("ii", $docId, $clinicId);
    $doc = safe_stmt_fetch_assoc($stmt);
    
    if ($doc) {
        @unlink(__DIR__ . '/../..' . $doc['file_path']);
        $stmt = $db->prepare("DELETE FROM patient_files WHERE id = ? AND clinic_id = ?");
        $stmt->bind_param("ii", $docId, $clinicId);
        $stmt->execute();
    }
    
    redirect('/views/patients/view.php?id=' . $patientId . '&tab=documents');
}

$stmt = $db->prepare("SELECT * FROM patients WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("ii", $patientId, $clinicId);
$patient = safe_stmt_fetch_assoc($stmt);

if (!$patient) {
    redirect('/views/patients/index.php');
}

$pageTitle = $patient['first_name'] . ' ' . $patient['last_name'];
$breadcrumb = lang('patients.view');

// Get appointments
$stmt = $db->prepare("SELECT a.*, u.name as doctor_name FROM appointments a JOIN users u ON a.doctor_id = u.id WHERE a.patient_id = ? ORDER BY a.date DESC, a.time DESC LIMIT 10");
$stmt->bind_param("i", $patientId);
$appointments = safe_stmt_fetch_all($stmt);

// Get treatments
$stmt = $db->prepare("SELECT t.*, u.name as doctor_name FROM treatments t JOIN users u ON t.doctor_id = u.id WHERE t.patient_id = ? ORDER BY t.date DESC LIMIT 10");
$stmt->bind_param("i", $patientId);
$treatments = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT * FROM patient_tooth_records WHERE patient_id = ? AND clinic_id = ?");
$stmt->bind_param("ii", $patientId, $clinicId);
$toothRecords = safe_stmt_fetch_all($stmt);

// Create tooth map for easy lookup
$toothMap = [];
foreach ($toothRecords as $record) {
    $toothMap[$record['tooth_number']] = $record;
}

// Get invoices
$stmt = $db->prepare("SELECT * FROM invoices WHERE patient_id = ? ORDER BY date DESC LIMIT 10");
$stmt->bind_param("i", $patientId);
$invoices = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT pf.*, u.name as uploaded_by_name FROM patient_files pf LEFT JOIN users u ON pf.uploaded_by = u.id WHERE pf.patient_id = ? ORDER BY pf.created_at DESC");
$stmt->bind_param("i", $patientId);
$documents = safe_stmt_fetch_all($stmt);

$activeTab = $_GET['tab'] ?? 'appointments';

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></h2>
        <div class="table-actions">
            <a href="/views/patients/edit.php?id=<?= $patient['id'] ?>" class="btn btn-primary"><?= lang('common.edit') ?></a>
        </div>
    </div>
    
    <div style="padding: 32px;">
        <?php if (isset($_GET['success'])): ?>
            <!-- Updated success message to not mention invoices -->
            <div style="background: #d1fae5; border-left: 4px solid #10b981; padding: 16px; border-radius: 8px; margin-bottom: 24px;">
                <strong style="color: #065f46;">Success!</strong> Treatment record saved successfully.
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div style="background: #fee2e2; border-left: 4px solid #ef4444; padding: 16px; border-radius: 8px; margin-bottom: 24px;">
                <strong style="color: #991b1b;">Error!</strong> <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>
        
        <!-- Patient Info -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 32px;">
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.phone') ?></div>
                <div style="font-weight: 500;"><?= htmlspecialchars($patient['phone']) ?></div>
            </div>
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.email') ?></div>
                <div style="font-weight: 500;"><?= htmlspecialchars($patient['email'] ?? '-') ?></div>
            </div>
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.birthday') ?></div>
                <div style="font-weight: 500;"><?= $patient['birthday'] ? formatDate($patient['birthday']) : '-' ?></div>
            </div>
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.gender') ?></div>
                <div style="font-weight: 500;"><?= $patient['gender'] ? ucfirst($patient['gender']) : '-' ?></div>
            </div>
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.address') ?></div>
                <div style="font-weight: 500;"><?= htmlspecialchars($patient['address'] ?? '-') ?></div>
            </div>
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;"><?= lang('patients.balance') ?></div>
                <div style="font-weight: 500;"><?= formatMoney($patient['balance']) ?></div>
            </div>
        </div>
        
        <!-- Medical History -->
        <?php if ($patient['allergies'] || $patient['chronic_diseases'] || $patient['medications']): ?>
        <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; border-radius: 8px; margin-bottom: 32px;">
            <h3 style="margin-bottom: 12px; color: #92400e;">Medical History</h3>
            <?php if ($patient['allergies']): ?>
                <div style="margin-bottom: 8px;">
                    <strong>Allergies:</strong> <?= htmlspecialchars($patient['allergies']) ?>
                </div>
            <?php endif; ?>
            <?php if ($patient['chronic_diseases']): ?>
                <div style="margin-bottom: 8px;">
                    <strong>Chronic Diseases:</strong> <?= htmlspecialchars($patient['chronic_diseases']) ?>
                </div>
            <?php endif; ?>
            <?php if ($patient['medications']): ?>
                <div>
                    <strong>Medications:</strong> <?= htmlspecialchars($patient['medications']) ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <!-- Tabs -->
        <div style="border-bottom: 2px solid #e5e7eb; margin-bottom: 24px;">
            <div style="display: flex; gap: 24px;">
                <button onclick="showTab('appointments')" id="tab-appointments" class="tab-btn <?= $activeTab === 'appointments' ? 'active' : '' ?>" style="padding: 12px 0; border: none; background: none; cursor: pointer; <?= $activeTab === 'appointments' ? 'border-bottom: 2px solid #3b82f6; margin-bottom: -2px; font-weight: 500;' : 'color: #6b7280;' ?>">
                    Appointments
                </button>
                <button onclick="showTab('treatments')" id="tab-treatments" class="tab-btn <?= $activeTab === 'treatments' ? 'active' : '' ?>" style="padding: 12px 0; border: none; background: none; cursor: pointer; <?= $activeTab === 'treatments' ? 'border-bottom: 2px solid #3b82f6; margin-bottom: -2px; font-weight: 500;' : 'color: #6b7280;' ?>">
                    Treatments
                </button>
                <button onclick="showTab('toothchart')" id="tab-toothchart" class="tab-btn <?= $activeTab === 'toothchart' ? 'active' : '' ?>" style="padding: 12px 0; border: none; background: none; cursor: pointer; <?= $activeTab === 'toothchart' ? 'border-bottom: 2px solid #3b82f6; margin-bottom: -2px; font-weight: 500;' : 'color: #6b7280;' ?>">
                    Tooth Chart
                </button>
                <button onclick="showTab('documents')" id="tab-documents" class="tab-btn <?= $activeTab === 'documents' ? 'active' : '' ?>" style="padding: 12px 0; border: none; background: none; cursor: pointer; <?= $activeTab === 'documents' ? 'border-bottom: 2px solid #3b82f6; margin-bottom: -2px; font-weight: 500;' : 'color: #6b7280;' ?>">
                    Documents
                </button>
                <button onclick="showTab('invoices')" id="tab-invoices" class="tab-btn <?= $activeTab === 'invoices' ? 'active' : '' ?>" style="padding: 12px 0; border: none; background: none; cursor: pointer; <?= $activeTab === 'invoices' ? 'border-bottom: 2px solid #3b82f6; margin-bottom: -2px; font-weight: 500;' : 'color: #6b7280;' ?>">
                    Invoices
                </button>
            </div>
        </div>
        
        <!-- Appointments Tab -->
        <div id="content-appointments" class="tab-content" style="display: <?= $activeTab === 'appointments' ? 'block' : 'none' ?>;">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Doctor</th>
                        <th>Service</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($appointments)): ?>
                        <tr><td colspan="5" style="text-align: center; padding: 40px;">No appointments</td></tr>
                    <?php else: ?>
                        <?php foreach ($appointments as $apt): ?>
                            <tr>
                                <td><?= formatDate($apt['date']) ?></td>
                                <td><?= date('H:i', strtotime($apt['time'])) ?></td>
                                <td>Dr. <?= htmlspecialchars($apt['doctor_name']) ?></td>
                                <td><?= htmlspecialchars($apt['service']) ?></td>
                                <td><?= getStatusBadge($apt['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Treatments Tab -->
        <div id="content-treatments" class="tab-content" style="display: <?= $activeTab === 'treatments' ? 'block' : 'none' ?>;">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Doctor</th>
                        <th>Procedure</th>
                        <th>Tooth</th>
                        <th>Cost</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($treatments)): ?>
                        <tr><td colspan="5" style="text-align: center; padding: 40px;">No treatments</td></tr>
                    <?php else: ?>
                        <?php foreach ($treatments as $treatment): ?>
                            <tr>
                                <td><?= formatDate($treatment['date']) ?></td>
                                <td>Dr. <?= htmlspecialchars($treatment['doctor_name']) ?></td>
                                <td><?= htmlspecialchars($treatment['procedure']) ?></td>
                                <td><?= htmlspecialchars($treatment['tooth_number'] ?? '-') ?></td>
                                <td><?= formatMoney($treatment['price']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Complete rewrite of tooth chart with anatomical SVG teeth -->
        <div id="content-toothchart" class="tab-content" style="display: <?= $activeTab === 'toothchart' ? 'block' : 'none' ?>;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 48px; border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.15);">
                <div style="text-align: center; margin-bottom: 40px;">
                    <h2 style="color: white; font-size: 32px; font-weight: 700; margin-bottom: 8px;">Interactive Tooth Chart</h2>
                    <p style="color: rgba(255,255,255,0.9); font-size: 16px;">FDI World Dental Federation Notation • Click any tooth to view history or add treatment</p>
                </div>
                
                <div style="background: white; padding: 40px; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);">
                    <!-- Upper Jaw -->
                    <div style="margin-bottom: 60px;">
                        <div style="text-align: center; margin-bottom: 24px;">
                            <div style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 8px 24px; border-radius: 20px; font-weight: 600; font-size: 14px; letter-spacing: 0.5px;">
                                UPPER JAW (Maxilla)
                            </div>
                        </div>
                        <div style="display: flex; justify-content: center; gap: 4px; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
                            <?php 
                            // Right side (18-11)
                            for ($i = 18; $i >= 11; $i--): 
                                $record = $toothMap[$i] ?? null;
                                $fillColor = '#f3f4f6';
                                $strokeColor = '#9ca3af';
                                $statusText = 'Healthy';
                                
                                if ($record) {
                                    switch ($record['status']) {
                                        case 'filling':
                                        case 'treated':
                                            $fillColor = '#dbeafe';
                                            $strokeColor = '#3b82f6';
                                            $statusText = 'Treated';
                                            break;
                                        case 'caries':
                                            $fillColor = '#fef3c7';
                                            $strokeColor = '#f59e0b';
                                            $statusText = 'Caries';
                                            break;
                                        case 'crown':
                                            $fillColor = '#e9d5ff';
                                            $strokeColor = '#a855f7';
                                            $statusText = 'Crown';
                                            break;
                                        case 'root_canal':
                                            $fillColor = '#fce7f3';
                                            $strokeColor = '#ec4899';
                                            $statusText = 'Root Canal';
                                            break;
                                        case 'implant':
                                            $fillColor = '#d1fae5';
                                            $strokeColor = '#10b981';
                                            $statusText = 'Implant';
                                            break;
                                        case 'missing':
                                        case 'extracted':
                                            $fillColor = '#fee2e2';
                                            $strokeColor = '#ef4444';
                                            $statusText = 'Missing';
                                            break;
                                    }
                                }
                                
                                // Determine tooth type for SVG shape
                                $toothType = 'molar'; // default
                                if ($i == 11 || $i == 21 || $i == 31 || $i == 41) $toothType = 'incisor-central';
                                elseif ($i == 12 || $i == 22 || $i == 32 || $i == 42) $toothType = 'incisor-lateral';
                                elseif ($i == 13 || $i == 23 || $i == 33 || $i == 43) $toothType = 'canine';
                                elseif ($i == 14 || $i == 15 || $i == 24 || $i == 25 || $i == 34 || $i == 35 || $i == 44 || $i == 45) $toothType = 'premolar';
                            ?>
                                <div class="tooth-item" data-tooth="<?= $i ?>" data-status="<?= $statusText ?>" 
                                     style="cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; width: 60px;">
                                    <?php if ($toothType == 'incisor-central'): ?>
                                        <!-- Central Incisor SVG -->
                                        <svg viewBox="0 0 60 120" style="width: 100%; height: auto;">
                                            <!-- Crown -->
                                            <path d="M 15 20 Q 15 10 20 10 L 40 10 Q 45 10 45 20 L 45 50 Q 45 60 40 60 L 20 60 Q 15 60 15 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <!-- Root -->
                                            <path d="M 20 60 L 25 110 L 35 110 L 40 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <!-- Number -->
                                            <text x="30" y="38" font-size="16" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'incisor-lateral'): ?>
                                        <!-- Lateral Incisor SVG -->
                                        <svg viewBox="0 0 55 115" style="width: 100%; height: auto;">
                                            <!-- Crown -->
                                            <path d="M 15 22 Q 15 12 20 12 L 35 12 Q 40 12 40 22 L 40 52 Q 40 60 35 60 L 20 60 Q 15 60 15 52 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <!-- Root -->
                                            <path d="M 20 60 L 24 105 L 31 105 L 35 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <!-- Number -->
                                            <text x="27.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="45" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'canine'): ?>
                                        <!-- Canine SVG -->
                                        <svg viewBox="0 0 60 125" style="width: 100%; height: auto;">
                                            <!-- Crown with pointed cusp -->
                                            <path d="M 20 15 L 30 5 L 40 15 L 42 55 Q 42 62 37 62 L 23 62 Q 18 62 18 55 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <!-- Long root -->
                                            <path d="M 23 62 L 26 115 L 34 115 L 37 62 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <!-- Number -->
                                            <text x="30" y="40" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'premolar'): ?>
                                        <!-- Premolar SVG -->
                                        <svg viewBox="0 0 65 115" style="width: 100%; height: auto;">
                                            <!-- Crown with two cusps -->
                                            <path d="M 18 15 L 25 8 L 32.5 13 L 40 8 L 47 15 L 47 50 Q 47 58 42 58 L 23 58 Q 18 58 18 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <!-- Root -->
                                            <path d="M 23 58 L 27 105 L 38 105 L 42 58 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <!-- Number -->
                                            <text x="32.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="55" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php else: ?>
                                        <!-- Molar SVG -->
                                        <svg viewBox="0 0 70 110" style="width: 100%; height: auto;">
                                            <!-- Crown with multiple cusps -->
                                            <path d="M 15 12 L 22 5 L 28 10 L 35 5 L 42 10 L 48 5 L 55 12 L 55 48 Q 55 56 50 56 L 20 56 Q 15 56 15 48 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <!-- Multiple roots -->
                                            <path d="M 20 56 L 22 100 L 28 100 L 28 56 M 42 56 L 42 100 L 48 100 L 50 56" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <!-- Number -->
                                            <text x="35" y="35" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="60" cy="10" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                            
                            <?php 
                            // Left side (21-28)
                            for ($i = 21; $i <= 28; $i++): 
                                $record = $toothMap[$i] ?? null;
                                $fillColor = '#f3f4f6';
                                $strokeColor = '#9ca3af';
                                $statusText = 'Healthy';
                                
                                if ($record) {
                                    switch ($record['status']) {
                                        case 'filling':
                                        case 'treated':
                                            $fillColor = '#dbeafe';
                                            $strokeColor = '#3b82f6';
                                            $statusText = 'Treated';
                                            break;
                                        case 'caries':
                                            $fillColor = '#fef3c7';
                                            $strokeColor = '#f59e0b';
                                            $statusText = 'Caries';
                                            break;
                                        case 'crown':
                                            $fillColor = '#e9d5ff';
                                            $strokeColor = '#a855f7';
                                            $statusText = 'Crown';
                                            break;
                                        case 'root_canal':
                                            $fillColor = '#fce7f3';
                                            $strokeColor = '#ec4899';
                                            $statusText = 'Root Canal';
                                            break;
                                        case 'implant':
                                            $fillColor = '#d1fae5';
                                            $strokeColor = '#10b981';
                                            $statusText = 'Implant';
                                            break;
                                        case 'missing':
                                        case 'extracted':
                                            $fillColor = '#fee2e2';
                                            $strokeColor = '#ef4444';
                                            $statusText = 'Missing';
                                            break;
                                    }
                                }
                                
                                $toothType = 'molar';
                                if ($i == 11 || $i == 21 || $i == 31 || $i == 41) $toothType = 'incisor-central';
                                elseif ($i == 12 || $i == 22 || $i == 32 || $i == 42) $toothType = 'incisor-lateral';
                                elseif ($i == 13 || $i == 23 || $i == 33 || $i == 43) $toothType = 'canine';
                                elseif ($i == 14 || $i == 15 || $i == 24 || $i == 25 || $i == 34 || $i == 35 || $i == 44 || $i == 45) $toothType = 'premolar';
                            ?>
                                <div class="tooth-item" data-tooth="<?= $i ?>" data-status="<?= $statusText ?>"
                                     style="cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; width: 60px;">
                                    <?php if ($toothType == 'incisor-central'): ?>
                                        <svg viewBox="0 0 60 120" style="width: 100%; height: auto;">
                                            <path d="M 15 20 Q 15 10 20 10 L 40 10 Q 45 10 45 20 L 45 50 Q 45 60 40 60 L 20 60 Q 15 60 15 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 25 110 L 35 110 L 40 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="38" font-size="16" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'incisor-lateral'): ?>
                                        <svg viewBox="0 0 55 115" style="width: 100%; height: auto;">
                                            <path d="M 15 22 Q 15 12 20 12 L 35 12 Q 40 12 40 22 L 40 52 Q 40 60 35 60 L 20 60 Q 15 60 15 52 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 24 105 L 31 105 L 35 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="27.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="45" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'canine'): ?>
                                        <svg viewBox="0 0 60 125" style="width: 100%; height: auto;">
                                            <path d="M 20 15 L 30 5 L 40 15 L 42 55 Q 42 62 37 62 L 23 62 Q 18 62 18 55 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 62 L 26 115 L 34 115 L 37 62 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="40" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'premolar'): ?>
                                        <svg viewBox="0 0 65 115" style="width: 100%; height: auto;">
                                            <path d="M 18 15 L 25 8 L 32.5 13 L 40 8 L 47 15 L 47 50 Q 47 58 42 58 L 23 58 Q 18 58 18 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 58 L 27 105 L 38 105 L 42 58 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="32.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="55" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php else: ?>
                                        <svg viewBox="0 0 70 110" style="width: 100%; height: auto;">
                                            <path d="M 15 12 L 22 5 L 28 10 L 35 5 L 42 10 L 48 5 L 55 12 L 55 48 Q 55 56 50 56 L 20 56 Q 15 56 15 48 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 56 L 22 100 L 28 100 L 28 56 M 42 56 L 42 100 L 48 100 L 50 56" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="35" y="35" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="60" cy="10" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <!-- Lower Jaw -->
                    <div>
                        <div style="text-align: center; margin-bottom: 24px;">
                            <div style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 8px 24px; border-radius: 20px; font-weight: 600; font-size: 14px; letter-spacing: 0.5px;">
                                LOWER JAW (Mandible)
                            </div>
                        </div>
                        <div style="display: flex; justify-content: center; gap: 4px; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
                            <?php 
                            // Right side (48-41)
                            for ($i = 48; $i >= 41; $i--): 
                                $record = $toothMap[$i] ?? null;
                                $fillColor = '#f3f4f6';
                                $strokeColor = '#9ca3af';
                                $statusText = 'Healthy';
                                
                                if ($record) {
                                    switch ($record['status']) {
                                        case 'filling':
                                        case 'treated':
                                            $fillColor = '#dbeafe';
                                            $strokeColor = '#3b82f6';
                                            $statusText = 'Treated';
                                            break;
                                        case 'caries':
                                            $fillColor = '#fef3c7';
                                            $strokeColor = '#f59e0b';
                                            $statusText = 'Caries';
                                            break;
                                        case 'crown':
                                            $fillColor = '#e9d5ff';
                                            $strokeColor = '#a855f7';
                                            $statusText = 'Crown';
                                            break;
                                        case 'root_canal':
                                            $fillColor = '#fce7f3';
                                            $strokeColor = '#ec4899';
                                            $statusText = 'Root Canal';
                                            break;
                                        case 'implant':
                                            $fillColor = '#d1fae5';
                                            $strokeColor = '#10b981';
                                            $statusText = 'Implant';
                                            break;
                                        case 'missing':
                                        case 'extracted':
                                            $fillColor = '#fee2e2';
                                            $strokeColor = '#ef4444';
                                            $statusText = 'Missing';
                                            break;
                                    }
                                }
                                
                                $toothType = 'molar';
                                if ($i == 11 || $i == 21 || $i == 31 || $i == 41) $toothType = 'incisor-central';
                                elseif ($i == 12 || $i == 22 || $i == 32 || $i == 42) $toothType = 'incisor-lateral';
                                elseif ($i == 13 || $i == 23 || $i == 33 || $i == 43) $toothType = 'canine';
                                elseif ($i == 14 || $i == 15 || $i == 24 || $i == 25 || $i == 34 || $i == 35 || $i == 44 || $i == 45) $toothType = 'premolar';
                            ?>
                                <div class="tooth-item" data-tooth="<?= $i ?>" data-status="<?= $statusText ?>"
                                     style="cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; width: 60px; transform: scaleY(-1);">
                                    <?php if ($toothType == 'incisor-central'): ?>
                                        <svg viewBox="0 0 60 120" style="width: 100%; height: auto;">
                                            <path d="M 15 20 Q 15 10 20 10 L 40 10 Q 45 10 45 20 L 45 50 Q 45 60 40 60 L 20 60 Q 15 60 15 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 25 110 L 35 110 L 40 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="38" font-size="16" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'incisor-lateral'): ?>
                                        <svg viewBox="0 0 55 115" style="width: 100%; height: auto;">
                                            <path d="M 15 22 Q 15 12 20 12 L 35 12 Q 40 12 40 22 L 40 52 Q 40 60 35 60 L 20 60 Q 15 60 15 52 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 24 105 L 31 105 L 35 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="27.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="45" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'canine'): ?>
                                        <svg viewBox="0 0 60 125" style="width: 100%; height: auto;">
                                            <path d="M 20 15 L 30 5 L 40 15 L 42 55 Q 42 62 37 62 L 23 62 Q 18 62 18 55 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 62 L 26 115 L 34 115 L 37 62 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="40" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -80)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'premolar'): ?>
                                        <svg viewBox="0 0 65 115" style="width: 100%; height: auto;">
                                            <path d="M 18 15 L 25 8 L 32.5 13 L 40 8 L 47 15 L 47 50 Q 47 58 42 58 L 23 58 Q 18 58 18 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 58 L 27 105 L 38 105 L 42 58 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="32.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="55" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php else: ?>
                                        <svg viewBox="0 0 70 110" style="width: 100%; height: auto;">
                                            <path d="M 15 12 L 22 5 L 28 10 L 35 5 L 42 10 L 48 5 L 55 12 L 55 48 Q 55 56 50 56 L 20 56 Q 15 56 15 48 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 56 L 22 100 L 28 100 L 28 56 M 42 56 L 42 100 L 48 100 L 50 56" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="35" y="35" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -70)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="60" cy="10" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                            
                            <?php 
                            // Left side (31-38)
                            for ($i = 31; $i <= 38; $i++): 
                                $record = $toothMap[$i] ?? null;
                                $fillColor = '#f3f4f6';
                                $strokeColor = '#9ca3af';
                                $statusText = 'Healthy';
                                
                                if ($record) {
                                    switch ($record['status']) {
                                        case 'filling':
                                        case 'treated':
                                            $fillColor = '#dbeafe';
                                            $strokeColor = '#3b82f6';
                                            $statusText = 'Treated';
                                            break;
                                        case 'caries':
                                            $fillColor = '#fef3c7';
                                            $strokeColor = '#f59e0b';
                                            $statusText = 'Caries';
                                            break;
                                        case 'crown':
                                            $fillColor = '#e9d5ff';
                                            $strokeColor = '#a855f7';
                                            $statusText = 'Crown';
                                            break;
                                        case 'root_canal':
                                            $fillColor = '#fce7f3';
                                            $strokeColor = '#ec4899';
                                            $statusText = 'Root Canal';
                                            break;
                                        case 'implant':
                                            $fillColor = '#d1fae5';
                                            $strokeColor = '#10b981';
                                            $statusText = 'Implant';
                                            break;
                                        case 'missing':
                                        case 'extracted':
                                            $fillColor = '#fee2e2';
                                            $strokeColor = '#ef4444';
                                            $statusText = 'Missing';
                                            break;
                                    }
                                }
                                
                                $toothType = 'molar';
                                if ($i == 11 || $i == 21 || $i == 31 || $i == 41) $toothType = 'incisor-central';
                                elseif ($i == 12 || $i == 22 || $i == 32 || $i == 42) $toothType = 'incisor-lateral';
                                elseif ($i == 13 || $i == 23 || $i == 33 || $i == 43) $toothType = 'canine';
                                elseif ($i == 14 || $i == 15 || $i == 24 || $i == 25 || $i == 34 || $i == 35 || $i == 44 || $i == 45) $toothType = 'premolar';
                            ?>
                                <div class="tooth-item" data-tooth="<?= $i ?>" data-status="<?= $statusText ?>"
                                     style="cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; width: 60px; transform: scaleY(-1);">
                                    <?php if ($toothType == 'incisor-central'): ?>
                                        <svg viewBox="0 0 60 120" style="width: 100%; height: auto;">
                                            <path d="M 15 20 Q 15 10 20 10 L 40 10 Q 45 10 45 20 L 45 50 Q 45 60 40 60 L 20 60 Q 15 60 15 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 25 110 L 35 110 L 40 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="38" font-size="16" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'incisor-lateral'): ?>
                                        <svg viewBox="0 0 55 115" style="width: 100%; height: auto;">
                                            <path d="M 15 22 Q 15 12 20 12 L 35 12 Q 40 12 40 22 L 40 52 Q 40 60 35 60 L 20 60 Q 15 60 15 52 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 60 L 24 105 L 31 105 L 35 60 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="27.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="45" cy="15" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'canine'): ?>
                                        <svg viewBox="0 0 60 125" style="width: 100%; height: auto;">
                                            <path d="M 20 15 L 30 5 L 40 15 L 42 55 Q 42 62 37 62 L 23 62 Q 18 62 18 55 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 62 L 26 115 L 34 115 L 37 62 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="30" y="40" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -80)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="50" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php elseif ($toothType == 'premolar'): ?>
                                        <svg viewBox="0 0 65 115" style="width: 100%; height: auto;">
                                            <path d="M 18 15 L 25 8 L 32.5 13 L 40 8 L 47 15 L 47 50 Q 47 58 42 58 L 23 58 Q 18 58 18 50 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 23 58 L 27 105 L 38 105 L 42 58 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="32.5" y="38" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -76)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="55" cy="12" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php else: ?>
                                        <svg viewBox="0 0 70 110" style="width: 100%; height: auto;">
                                            <path d="M 15 12 L 22 5 L 28 10 L 35 5 L 42 10 L 48 5 L 55 12 L 55 48 Q 55 56 50 56 L 20 56 Q 15 56 15 48 Z" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2"/>
                                            <path d="M 20 56 L 22 100 L 28 100 L 28 56 M 42 56 L 42 100 L 48 100 L 50 56" 
                                                  fill="<?= $fillColor ?>" stroke="<?= $strokeColor ?>" stroke-width="2" opacity="0.7"/>
                                            <text x="35" y="35" font-size="14" font-weight="700" fill="#1f2937" text-anchor="middle" transform="scale(1, -1) translate(0, -70)"><?= $i ?></text>
                                            <?php if ($record): ?>
                                                <circle cx="60" cy="10" r="4" fill="<?= $strokeColor ?>"/>
                                            <?php endif; ?>
                                        </svg>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <!-- Legend -->
                    <div style="margin-top: 48px; padding: 24px; background: #f9fafb; border-radius: 12px;">
                        <div style="text-align: center; margin-bottom: 20px; font-weight: 600; color: #374151; font-size: 16px;">Tooth Status Legend</div>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px;">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #f3f4f6; border: 3px solid #9ca3af; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Healthy</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #dbeafe; border: 3px solid #3b82f6; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Treated/Filling</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #fef3c7; border: 3px solid #f59e0b; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Caries</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #e9d5ff; border: 3px solid #a855f7; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Crown</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #fce7f3; border: 3px solid #ec4899; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Root Canal</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #d1fae5; border: 3px solid #10b981; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Implant</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 32px; height: 32px; background: #fee2e2; border: 3px solid #ef4444; border-radius: 8px; flex-shrink: 0;"></div>
                                <span style="font-size: 14px; font-weight: 500; color: #374151;">Missing/Extracted</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Treatment History Panel -->
                <div id="tooth-detail-panel" style="display: none; margin-top: 32px; background: white; padding: 32px; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                        <div>
                            <h3 style="font-size: 24px; font-weight: 700; color: #1f2937; margin-bottom: 4px;">
                                Tooth <span id="selected-tooth-number"></span>
                            </h3>
                            <p style="color: #6b7280; font-size: 14px;">Status: <span id="selected-tooth-status" style="font-weight: 600;"></span></p>
                        </div>
                        <button onclick="openAddTreatmentModal()" class="btn btn-primary" style="padding: 12px 24px; font-size: 15px;">
                            <span style="margin-right: 8px;">+</span> Add Treatment
                        </button>
                    </div>
                    
                    <div id="tooth-treatments-list"></div>
                </div>
            </div>
        </div>
        
        <!-- Documents Tab -->
        <div id="content-documents" class="tab-content" style="display: <?= $activeTab === 'documents' ? 'block' : 'none' ?>;">
            <div style="margin-bottom: 24px;">
                <button onclick="openModal('uploadDocModal')" class="btn btn-primary">Upload Document</button>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 16px;">
                <?php if (empty($documents)): ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 60px; color: #6b7280;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📄</div>
                        <p>No documents uploaded yet</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($documents as $doc): ?>
                        <div style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 16px; transition: all 0.2s;">
                            <div style="display: flex; align-items: center; justify-content: center; height: 120px; background: #f9fafb; border-radius: 8px; margin-bottom: 12px;">
                                <?php if (strpos($doc['file_type'], 'image') !== false): ?>
                                    <img src="<?= htmlspecialchars($doc['file_path']) ?>" style="max-width: 100%; max-height: 100%; border-radius: 8px;" alt="Document">
                                <?php else: ?>
                                    <div style="font-size: 48px;">📄</div>
                                <?php endif; ?>
                            </div>
                            <div style="font-weight: 600; margin-bottom: 4px; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($doc['file_name']) ?>">
                                <?= htmlspecialchars($doc['file_name']) ?>
                            </div>
                            <?php if ($doc['description']): ?>
                                <div style="font-size: 13px; color: #6b7280; margin-bottom: 8px;">
                                    <?= htmlspecialchars($doc['description']) ?>
                                </div>
                            <?php endif; ?>
                            <div style="font-size: 12px; color: #9ca3af; margin-bottom: 12px;">
                                <?= formatDate($doc['created_at']) ?> • <?= htmlspecialchars($doc['uploaded_by_name'] ?? 'Unknown') ?>
                            </div>
                            <div style="display: flex; gap: 8px;">
                                <a href="<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-sm btn-primary" style="flex: 1; text-align: center; padding: 6px 12px; font-size: 13px;">View</a>
                                <a href="?id=<?= $patientId ?>&delete_doc=<?= $doc['id'] ?>&tab=documents" onclick="return confirm('Delete this document?')" class="btn btn-sm btn-danger" style="padding: 6px 12px; font-size: 13px;">Delete</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Invoices Tab -->
        <div id="content-invoices" class="tab-content" style="display: <?= $activeTab === 'invoices' ? 'block' : 'none' ?>;">
            <table>
                <thead>
                    <tr>
                        <th>Invoice No</th>
                        <th>Date</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($invoices)): ?>
                        <tr><td colspan="6" style="text-align: center; padding: 40px;">No invoices</td></tr>
                    <?php else: ?>
                        <?php foreach ($invoices as $invoice): ?>
                            <tr>
                                <td><?= htmlspecialchars($invoice['invoice_no']) ?></td>
                                <td><?= formatDate($invoice['date']) ?></td>
                                <td><?= formatMoney($invoice['total']) ?></td>
                                <td><?= formatMoney($invoice['paid_amount']) ?></td>
                                <td><?= getStatusBadge($invoice['payment_status']) ?></td>
                                <td>
                                    <a href="/views/billing/view.php?id=<?= $invoice['id'] ?>" class="btn-link">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Upload Document Modal -->
<div id="uploadDocModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Upload Document</h3>
            <button onclick="closeModal('uploadDocModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="form-group">
                    <label>Document File *</label>
                    <input type="file" name="document" required class="form-control" accept="image/*,.pdf,.doc,.docx">
                    <small style="color: #6b7280;">Accepted: Images, PDF, Word documents</small>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="X-ray, consent form, medical report, etc."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('uploadDocModal')" class="btn btn-secondary">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload</button>
            </div>
        </form>
    </div>
</div>

<!-- Add Treatment Modal -->
<div id="addTreatmentModal" class="modal">
    <div class="modal-content" style="max-width: 700px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 12px 12px 0 0; padding: 24px;">
            <h3 style="margin: 0; font-size: 24px;">Add Treatment to Tooth <span id="modal-tooth-number" style="font-weight: 800;"></span></h3>
            <button onclick="window.closeModal('addTreatmentModal')" class="modal-close" style="color: white; font-size: 32px; opacity: 0.9;">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="patient_id" value="<?= $patientId ?>">
            <input type="hidden" name="tooth_number" id="form-tooth-number">
            <input type="hidden" name="add_tooth_treatment" value="1">
            
            <div class="modal-body" style="padding: 32px;">
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Doctor *</label>
                    <select name="doctor_id" class="form-control" required style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;">
                        <?php
                        $stmt = $db->prepare("SELECT id, name FROM users WHERE clinic_id = ? AND role IN ('doctor', 'admin') ORDER BY name");
                        $stmt->bind_param("i", $clinicId);
                        $doctors = safe_stmt_fetch_all($stmt);
                        foreach ($doctors as $doctor):
                        ?>
                            <option value="<?= $doctor['id'] ?>" <?= $doctor['id'] == $_SESSION['user_id'] ? 'selected' : '' ?>>
                                Dr. <?= htmlspecialchars($doctor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Date *</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;">
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Tooth Status *</label>
                    <select name="status" class="form-control" required style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;">
                        <option value="healthy">Healthy</option>
                        <option value="caries">Caries</option>
                        <option value="filling" selected>Filling</option>
                        <option value="crown">Crown</option>
                        <option value="root_canal">Root Canal</option>
                        <option value="implant">Implant</option>
                        <option value="missing">Missing</option>
                        <option value="extracted">Extracted</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Procedure / Treatment *</label>
                    <input type="text" name="procedure" class="form-control" required style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;" placeholder="e.g., Composite filling, Crown placement, Root canal">
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Notes</label>
                    <textarea name="notes" class="form-control" rows="4" style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;" placeholder="Additional notes about the treatment, observations, or follow-up instructions..."></textarea>
                </div>
                
                <div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-top: 20px;">
                    <div style="font-size: 13px; color: #1e40af; font-weight: 500;">
                        <strong>Note:</strong> This will update the tooth chart and save the treatment record for patient history.
                    </div>
                </div>
            </div>
            <!-- Updated modal footer with prominent submit button -->
            <div class="modal-footer" style="padding: 20px 32px; background: #f9fafb; border-radius: 0 0 12px 12px; display: flex; justify-content: flex-end; gap: 12px;">
                <button type="button" onclick="window.closeModal('addTreatmentModal')" class="btn btn-secondary" style="padding: 12px 24px; font-size: 15px;">Cancel</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 32px; font-weight: 600; font-size: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none;">
                    Save Treatment Record
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function showTab(tab) {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(el => {
        el.style.borderBottom = 'none';
        el.style.color = '#6b7280';
        el.style.fontWeight = 'normal';
        el.classList.remove('active');
    });
    
    document.getElementById('content-' + tab).style.display = 'block';
    const btn = document.getElementById('tab-' + tab);
    btn.style.borderBottom = '2px solid #3b82f6';
    btn.style.color = 'inherit';
    btn.style.fontWeight = '500';
    btn.classList.add('active');
}

function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

let selectedToothNumber = null;
let selectedToothStatus = null;

function openAddTreatmentModal() {
    if (selectedToothNumber) {
        document.getElementById('modal-tooth-number').textContent = selectedToothNumber;
        document.getElementById('form-tooth-number').value = selectedToothNumber;
        window.openModal('addTreatmentModal');
    } else {
        alert('Please select a tooth first by clicking on it');
    }
}

// Load tooth chart data and setup interactions
document.addEventListener('DOMContentLoaded', function() {
    const treatments = <?= json_encode($treatments) ?>;
    const toothTreatmentMap = {};
    
    // Group treatments by tooth number
    treatments.forEach(t => {
        if (t.tooth_number) {
            if (!toothTreatmentMap[t.tooth_number]) {
                toothTreatmentMap[t.tooth_number] = [];
            }
            toothTreatmentMap[t.tooth_number].push(t);
        }
    });
    
    // Setup tooth interactions
    document.querySelectorAll('.tooth-item').forEach(tooth => {
        const toothNum = tooth.dataset.tooth;
        const toothStatus = tooth.dataset.status;
        
        // Click handler
        tooth.addEventListener('click', function() {
            selectedToothNumber = toothNum;
            selectedToothStatus = toothStatus;
            
            // Update selected tooth display
            document.getElementById('selected-tooth-number').textContent = toothNum;
            document.getElementById('selected-tooth-status').textContent = toothStatus;
            
            // Show treatment history
            const panel = document.getElementById('tooth-detail-panel');
            const treatmentsList = document.getElementById('tooth-treatments-list');
            
            if (toothTreatmentMap[toothNum] && toothTreatmentMap[toothNum].length > 0) {
                let html = '<div style="display: flex; flex-direction: column; gap: 16px;">';
                html += '<h4 style="font-size: 16px; font-weight: 600; color: #374151; margin-bottom: 8px;">Treatment History</h4>';
                
                toothTreatmentMap[toothNum].forEach(t => {
                    html += `
                        <div style="padding: 20px; background: linear-gradient(135deg, #f9fafb 0%, #ffffff 100%); border-radius: 12px; border: 2px solid #e5e7eb; transition: all 0.2s;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
                                <div>
                                    <div style="font-weight: 700; font-size: 16px; color: #1f2937; margin-bottom: 4px;">${t.procedure}</div>
                                    <div style="font-size: 14px; color: #6b7280;">Dr. ${t.doctor_name}</div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 13px; color: #6b7280;">${new Date(t.date).toLocaleDateString()}</div>
                                </div>
                            </div>
                            ${t.notes ? `<div style="margin-top: 12px; padding: 12px; background: white; border-radius: 8px; font-size: 14px; color: #4b5563; border-left: 3px solid #3b82f6;"><strong>Notes:</strong> ${t.notes}</div>` : ''}
                        </div>
                    `;
                });
                html += '</div>';
                treatmentsList.innerHTML = html;
            } else {
                treatmentsList.innerHTML = `
                    <div style="text-align: center; padding: 48px; background: #f9fafb; border-radius: 12px; border: 2px dashed #d1d5db;">
                        <div style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;">🦷</div>
                        <p style="color: #6b7280; font-size: 15px; margin: 0;">No treatments recorded for this tooth yet</p>
                    </div>
                `;
            }
            
            panel.style.display = 'block';
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
        
        // Hover effects
        tooth.addEventListener('mouseenter', function() {
            this.style.transform = this.style.transform.includes('scaleY(-1)') ? 'scaleY(-1) scale(1.15)' : 'scale(1.15)';
            this.style.filter = 'drop-shadow(0 8px 16px rgba(0,0,0,0.15))';
            this.style.zIndex = '10';
        });
        
        tooth.addEventListener('mouseleave', function() {
            this.style.transform = this.style.transform.includes('scaleY(-1)') ? 'scaleY(-1) scale(1)' : 'scale(1)';
            this.style.filter = 'none';
            this.style.zIndex = '1';
        });
    });
});
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
