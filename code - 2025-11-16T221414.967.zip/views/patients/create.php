<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('patients.add');
$breadcrumb = lang('patients.add');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $firstName = sanitize($_POST['first_name']);
    $lastName = sanitize($_POST['last_name']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email'] ?? '');
    $birthday = !empty($_POST['birthday']) ? $_POST['birthday'] : null;
    $gender = !empty($_POST['gender']) ? $_POST['gender'] : null;
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? '');
    $allergies = sanitize($_POST['allergies'] ?? '');
    $chronicDiseases = sanitize($_POST['chronic_diseases'] ?? '');
    $medications = sanitize($_POST['medications'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    
    $stmt = $db->prepare("INSERT INTO patients (clinic_id, first_name, last_name, phone, email, birthday, gender, address, city, allergies, chronic_diseases, medications, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssssssssi", $clinicId, $firstName, $lastName, $phone, $email, $birthday, $gender, $address, $city, $allergies, $chronicDiseases, $medications, $notes, $userId);
    
    if ($stmt->execute()) {
        Auth::logActivity('create_patient', 'patient', $stmt->insert_id, "Created patient: $firstName $lastName");
        redirect('/views/patients/index.php');
    } else {
        $error = 'Failed to create patient';
    }
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('patients.add') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('patients.first_name') ?> *</label>
                    <input type="text" name="first_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.last_name') ?> *</label>
                    <input type="text" name="last_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.phone') ?> *</label>
                    <input type="tel" name="phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.email') ?></label>
                    <input type="email" name="email" class="form-control">
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.birthday') ?></label>
                    <input type="date" name="birthday" class="form-control">
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.gender') ?></label>
                    <select name="gender" class="form-control">
                        <option value="">-</option>
                        <option value="male"><?= lang('patients.male') ?></option>
                        <option value="female"><?= lang('patients.female') ?></option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.address') ?></label>
                    <input type="text" name="address" class="form-control">
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.city') ?></label>
                    <input type="text" name="city" class="form-control">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 20px;">
                <div class="form-group">
                    <label><?= lang('patients.allergies') ?></label>
                    <textarea name="allergies" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.chronic_diseases') ?></label>
                    <textarea name="chronic_diseases" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.medications') ?></label>
                    <textarea name="medications" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label><?= lang('patients.notes') ?></label>
                    <textarea name="notes" class="form-control"></textarea>
                </div>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/patients/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
