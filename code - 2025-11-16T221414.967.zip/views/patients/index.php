<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$pageTitle = 'Patients';
$breadcrumb = 'Patients';

include __DIR__ . '/../layout/header.php';

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        redirect('/views/patients/index.php?error=csrf');
        exit;
    }

    $patientId = (int)$_POST['patient_id'];
    $stmt = $db->prepare("DELETE FROM patients WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("ii", $patientId, $clinicId);
    $stmt->execute();
    redirect('/views/patients/index.php?success=deleted');
}

// Handle search and filters
$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? 'all';

$sql = "SELECT * FROM patients WHERE clinic_id = ?";
$params = [$clinicId];
$types = "i";

if ($search) {
    $sql .= " AND (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
    $types .= "sss";
}

if ($filter === 'this_month') {
    $sql .= " AND MONTH(created_at) = MONTH(CURDATE())";
} elseif ($filter === 'with_debt') {
    $sql .= " AND balance < 0";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $db->prepare($sql);
$stmt->bind_param($types, ...$params);
$patients = safe_stmt_fetch_all($stmt);
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('patients.title') ?></h2>
        <div class="table-actions">
            <div class="search-box">
                <span class="search-icon">🔍</span>
                <form method="get" style="display: inline;">
                    <input type="text" name="search" placeholder="<?= lang('patients.search') ?>" value="<?= htmlspecialchars($search) ?>">
                </form>
            </div>
            <a href="/views/patients/create.php" class="btn btn-primary">+ <?= lang('patients.add') ?></a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success" style="margin: 20px 24px;">
            <?= $_GET['success'] === 'deleted' ? 'Patient deleted successfully!' : 'Action completed successfully!' ?>
        </div>
    <?php endif; ?>
    
    <div style="padding: 16px 24px; border-bottom: 1px solid var(--gray-200); display: flex; gap: 12px;">
        <a href="?filter=all" class="btn <?= $filter === 'all' ? 'btn-primary' : 'btn-secondary' ?>"><?= lang('patients.all') ?></a>
        <a href="?filter=this_month" class="btn <?= $filter === 'this_month' ? 'btn-primary' : 'btn-secondary' ?>"><?= lang('patients.this_month') ?></a>
        <a href="?filter=with_debt" class="btn <?= $filter === 'with_debt' ? 'btn-primary' : 'btn-secondary' ?>"><?= lang('patients.with_debt') ?></a>
    </div>
    
    <table>
        <thead>
            <tr>
                <th><?= lang('patients.first_name') ?></th>
                <th><?= lang('patients.last_name') ?></th>
                <th><?= lang('patients.phone') ?></th>
                <th><?= lang('patients.email') ?></th>
                <th><?= lang('patients.status') ?></th>
                <th><?= lang('patients.balance') ?></th>
                <!-- Made actions column responsive -->
                <th style="min-width: 180px;"><?= lang('common.actions') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($patients)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <?= lang('common.no_data') ?>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($patients as $patient): ?>
                    <tr>
                        <td><?= htmlspecialchars($patient['first_name']) ?></td>
                        <td><?= htmlspecialchars($patient['last_name']) ?></td>
                        <td><?= htmlspecialchars($patient['phone']) ?></td>
                        <td><?= htmlspecialchars($patient['email'] ?? '-') ?></td>
                        <td><?= getStatusBadge($patient['status']) ?></td>
                        <td><?= formatMoney($patient['balance']) ?></td>
                        <!-- Responsive actions with dropdown for mobile -->
                        <td>
                            <div class="actions-wrapper" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                                <a href="/views/patients/view.php?id=<?= $patient['id'] ?>" class="btn btn-sm btn-primary" style="padding: 6px 12px; font-size: 13px; white-space: nowrap;">View</a>
                                <a href="/views/patients/edit.php?id=<?= $patient['id'] ?>" class="btn btn-sm btn-secondary" style="padding: 6px 12px; font-size: 13px; white-space: nowrap;">Edit</a>
                                <form method="POST" style="display: inline; margin: 0;" onsubmit="return confirm('Are you sure you want to delete this patient?')">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="patient_id" value="<?= $patient['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" style="padding: 6px 12px; font-size: 13px; white-space: nowrap;">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
/* Responsive table styles */
@media (max-width: 768px) {
    .actions-wrapper {
        justify-content: flex-start;
    }
    
    table {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
}
</style>

<?php include __DIR__ . '/../layout/footer.php'; ?>
