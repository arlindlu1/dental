<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('appointments.add');
$breadcrumb = lang('appointments.add');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$stmt = $db->prepare("SELECT id, first_name, last_name FROM patients WHERE clinic_id = ? ORDER BY first_name");
$stmt->bind_param("i", $clinicId);
$patients = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT id, name FROM users WHERE clinic_id = ? AND role IN ('doctor', 'admin') ORDER BY name");
$stmt->bind_param("i", $clinicId);
$doctors = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT * FROM procedures WHERE clinic_id IS NULL OR clinic_id = ? ORDER BY name_" . Lang::current());
$stmt->bind_param("i", $clinicId);
$procedures = safe_stmt_fetch_all($stmt);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_new_patient'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $firstName = sanitize($_POST['new_patient_first_name']);
    $lastName = sanitize($_POST['new_patient_last_name']);
    $phone = sanitize($_POST['new_patient_phone']);
    $email = sanitize($_POST['new_patient_email'] ?? '');
    
    // Convert empty email to NULL
    $email = $email === '' ? null : $email;
    
    $stmt = $db->prepare("INSERT INTO patients (clinic_id, first_name, last_name, phone, email, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssi", $clinicId, $firstName, $lastName, $phone, $email, $userId);
    
    if ($stmt->execute()) {
        $newPatientId = $db->lastInsertId();
        Auth::logActivity('create_patient', 'patient', $newPatientId, "Quick created patient: $firstName $lastName");
        // Use relative redirect to avoid absolute-root path issues on some hosts
        redirect('create.php?patient_id=' . $newPatientId . '&success=patient_created');
    } else {
        $error = 'Failed to create patient';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['create_new_patient'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $patientId = (int)$_POST['patient_id'];
    $doctorId = (int)$_POST['doctor_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $duration = (int)$_POST['duration'];
    $service = sanitize($_POST['service']);
    $notes = sanitize($_POST['notes'] ?? '');
    
    // Convert empty notes to NULL
    $notes = $notes === '' ? null : $notes;
    
    $stmt = $db->prepare("INSERT INTO appointments (clinic_id, patient_id, doctor_id, date, time, duration, service, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiississi", $clinicId, $patientId, $doctorId, $date, $time, $duration, $service, $notes, $userId);
    
    if ($stmt->execute()) {
        Auth::logActivity('create_appointment', 'appointment', $db->lastInsertId(), "Created appointment for patient ID: $patientId");
        // Use relative redirect to the index in same folder
        redirect('index.php?success=created');
    } else {
        $error = 'Failed to create appointment. Please try again.';
    }
}

$preSelectedPatientId = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
if (isset($_GET['success']) && $_GET['success'] === 'patient_created') {
    $success = 'Patient created successfully! Now create the appointment.';
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('appointments.add') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        
        <form method="post" id="appointmentForm">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('appointments.patient') ?> *</label>
                    <div style="display: flex; gap: 8px;">
                        <select name="patient_id" id="patientSelect" class="form-control" style="flex: 1;" required>
                            <option value="">Select patient...</option>
                            <?php foreach ($patients as $patient): ?>
                                <option value="<?= $patient['id'] ?>" <?= $patient['id'] == $preSelectedPatientId ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" onclick="window.openModal('newPatientModal')" class="btn btn-secondary">+ New</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.doctor') ?> *</label>
                    <select name="doctor_id" class="form-control" required>
                        <option value="">Select doctor</option>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= $doctor['id'] ?>">Dr. <?= htmlspecialchars($doctor['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.date') ?> *</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.time') ?> *</label>
                    <!-- Enhanced time input with better UX -->
                    <input type="time" name="time" class="form-control" required 
                           style="padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 15px;"
                           value="<?= date('H:00') ?>">
                    <small style="color: #6b7280; font-size: 13px; margin-top: 4px; display: block;">
                        Select appointment time (HH:MM format)
                    </small>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.service') ?> *</label>
                    <select name="service" class="form-control" required>
                        <option value="">Select service</option>
                        <?php foreach ($procedures as $proc): ?>
                            <option value="<?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?>">
                                <?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?> - <?= formatMoney($proc['price']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.duration') ?> (minutes) *</label>
                    <input type="number" name="duration" class="form-control" value="30" min="15" step="15" required>
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px;">
                <label><?= lang('appointments.notes') ?></label>
                <textarea name="notes" class="form-control" rows="3"></textarea>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/appointments/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<!-- Quick patient creation modal -->
<div id="newPatientModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="window.closeModal('newPatientModal')">&times;</span>
        <h2>Quick Add Patient</h2>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="create_new_patient" value="1">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>First Name *</label>
                    <input type="text" name="new_patient_first_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Last Name *</label>
                    <input type="text" name="new_patient_last_name" class="form-control" required>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Phone *</label>
                    <input type="tel" name="new_patient_phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="new_patient_email" class="form-control">
                </div>
            </div>
            
            <div style="margin-top: 20px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary">Create Patient</button>
                <button type="button" onclick="window.closeModal('newPatientModal')" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
