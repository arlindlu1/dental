<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$appointmentId = (int)($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM appointments WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("ii", $appointmentId, $clinicId);
$appointment = safe_stmt_fetch_assoc($stmt);

if (!$appointment) {
    redirect('/views/appointments/index.php');
}

$pageTitle = lang('appointments.edit');
$breadcrumb = lang('appointments.edit');

// Get patients and doctors
$stmt = $db->prepare("SELECT id, first_name, last_name FROM patients WHERE clinic_id = ? ORDER BY first_name");
$stmt->bind_param("i", $clinicId);
$patients = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT id, name FROM users WHERE clinic_id = ? AND role IN ('doctor', 'admin') ORDER BY name");
$stmt->bind_param("i", $clinicId);
$doctors = safe_stmt_fetch_all($stmt);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $patientId = (int)$_POST['patient_id'];
    $doctorId = (int)$_POST['doctor_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $duration = (int)$_POST['duration'];
    $service = sanitize($_POST['service']);
    $status = $_POST['status'];
    $notes = sanitize($_POST['notes'] ?? '');
    
    $stmt = $db->prepare("UPDATE appointments SET patient_id = ?, doctor_id = ?, date = ?, time = ?, duration = ?, service = ?, status = ?, notes = ? WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("iississsii", $patientId, $doctorId, $date, $time, $duration, $service, $status, $notes, $appointmentId, $clinicId);
    
    if ($stmt->execute()) {
        Auth::logActivity('update_appointment', 'appointment', $appointmentId, "Updated appointment ID: $appointmentId");
        redirect('/views/appointments/index.php');
    } else {
        $error = 'Failed to update appointment';
    }
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('appointments.edit') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('appointments.patient') ?> *</label>
                    <select name="patient_id" class="form-control" required>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?= $patient['id'] ?>" <?= $patient['id'] == $appointment['patient_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.doctor') ?> *</label>
                    <select name="doctor_id" class="form-control" required>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= $doctor['id'] ?>" <?= $doctor['id'] == $appointment['doctor_id'] ? 'selected' : '' ?>>
                                Dr. <?= htmlspecialchars($doctor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.date') ?> *</label>
                    <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($appointment['date']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.time') ?> *</label>
                    <input type="time" name="time" class="form-control" value="<?= htmlspecialchars($appointment['time']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.service') ?> *</label>
                    <input type="text" name="service" class="form-control" value="<?= htmlspecialchars($appointment['service']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.duration') ?> *</label>
                    <input type="number" name="duration" class="form-control" value="<?= $appointment['duration'] ?>" min="15" step="15" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('appointments.status') ?> *</label>
                    <select name="status" class="form-control" required>
                        <option value="scheduled" <?= $appointment['status'] === 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
                        <option value="confirmed" <?= $appointment['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="completed" <?= $appointment['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                        <option value="cancelled" <?= $appointment['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        <option value="no_show" <?= $appointment['status'] === 'no_show' ? 'selected' : '' ?>>No Show</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px;">
                <label><?= lang('appointments.notes') ?></label>
                <textarea name="notes" class="form-control"><?= htmlspecialchars($appointment['notes'] ?? '') ?></textarea>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/appointments/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
