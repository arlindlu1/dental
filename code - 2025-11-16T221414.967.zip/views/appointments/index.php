<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$pageTitle = 'Appointments';
$breadcrumb = 'Appointments';

include __DIR__ . '/../layout/header.php';

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'update_status') {
            $appointmentId = (int)$_POST['appointment_id'];
            $status = sanitize($_POST['status']);
            $stmt = $db->prepare("UPDATE appointments SET status = ? WHERE id = ? AND clinic_id = ?");
            $stmt->bind_param("sii", $status, $appointmentId, $clinicId);
            $stmt->execute();
            redirect('/views/appointments/index.php?date=' . ($_POST['date'] ?? date('Y-m-d')) . '&success=updated');
        } elseif ($_POST['action'] === 'delete') {
            $appointmentId = (int)$_POST['appointment_id'];
            $stmt = $db->prepare("DELETE FROM appointments WHERE id = ? AND clinic_id = ?");
            $stmt->bind_param("ii", $appointmentId, $clinicId);
            $stmt->execute();
            redirect('/views/appointments/index.php?date=' . ($_POST['date'] ?? date('Y-m-d')) . '&success=deleted');
        }
    }
}

// Get date filter and view mode
$date = $_GET['date'] ?? date('Y-m-d');
$view = $_GET['view'] ?? 'list';

$sql = "SELECT a.*, p.first_name, p.last_name, u.name as doctor_name 
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        JOIN users u ON a.doctor_id = u.id 
        WHERE a.clinic_id = ? AND a.date = ?
        ORDER BY a.time";
$stmt = $db->prepare($sql);
$stmt->bind_param("is", $clinicId, $date);
$appointments = safe_stmt_fetch_all($stmt);
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= $pageTitle ?></h2>
        <div class="table-actions">
            <!-- Added view toggle buttons -->
            <div style="display: flex; gap: 8px; background: var(--gray-100); padding: 4px; border-radius: 10px;">
                <a href="?date=<?= $date ?>&view=list" class="btn <?= $view === 'list' ? 'btn-primary' : 'btn-secondary' ?>" style="padding: 8px 16px; font-size: 13px;">List</a>
                <a href="?date=<?= $date ?>&view=calendar" class="btn <?= $view === 'calendar' ? 'btn-primary' : 'btn-secondary' ?>" style="padding: 8px 16px; font-size: 13px;">Calendar</a>
            </div>
            <input type="date" value="<?= $date ?>" onchange="window.location='?date='+this.value+'&view=<?= $view ?>'" class="form-control" style="width: 200px;">
            <a href="/views/appointments/create.php" class="btn btn-primary">+ <?= lang('appointments.add') ?></a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success" style="margin: 20px 24px;">
            <?= $_GET['success'] === 'deleted' ? 'Appointment deleted successfully!' : 'Appointment updated successfully!' ?>
        </div>
    <?php endif; ?>
    
    <?php if ($view === 'calendar'): ?>
        <!-- Added calendar view -->
        <div style="padding: 24px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px;">
                <?php
                $timeSlots = [];
                for ($hour = 8; $hour <= 18; $hour++) {
                    $timeSlots[] = sprintf("%02d:00", $hour);
                    $timeSlots[] = sprintf("%02d:30", $hour);
                }
                
                foreach ($timeSlots as $slot):
                    $slotAppointments = array_filter($appointments, function($apt) use ($slot) {
                        return substr($apt['time'], 0, 5) === $slot;
                    });
                ?>
                    <div style="background: <?= !empty($slotAppointments) ? 'var(--primary-light)' : 'var(--gray-50)' ?>; padding: 16px; border-radius: 12px; border: 2px solid <?= !empty($slotAppointments) ? 'var(--primary)' : 'var(--gray-200)' ?>;">
                        <div style="font-weight: 700; color: var(--primary); margin-bottom: 8px;"><?= $slot ?></div>
                        <?php if (!empty($slotAppointments)): ?>
                            <?php foreach ($slotAppointments as $apt): ?>
                                <div style="background: var(--white); padding: 12px; border-radius: 8px; margin-bottom: 8px;">
                                    <div style="font-weight: 600; margin-bottom: 4px;"><?= htmlspecialchars($apt['first_name'] . ' ' . $apt['last_name']) ?></div>
                                    <div style="font-size: 13px; color: var(--gray-600);"><?= htmlspecialchars($apt['service']) ?></div>
                                    <div style="margin-top: 8px;"><?= getStatusBadge($apt['status']) ?></div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="color: var(--gray-400); font-size: 13px;">Available</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php else: ?>
        <!-- List view -->
        <table>
            <thead>
                <tr>
                    <th><?= lang('appointments.time') ?></th>
                    <th><?= lang('appointments.patient') ?></th>
                    <th><?= lang('appointments.doctor') ?></th>
                    <th><?= lang('appointments.service') ?></th>
                    <th><?= lang('appointments.duration') ?></th>
                    <th><?= lang('appointments.status') ?></th>
                    <th><?= lang('common.actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($appointments)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">
                            <?= lang('common.no_data') ?>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($appointments as $apt): ?>
                        <tr>
                            <td><?= date('H:i', strtotime($apt['time'])) ?></td>
                            <td><?= htmlspecialchars($apt['first_name'] . ' ' . $apt['last_name']) ?></td>
                            <td>Dr. <?= htmlspecialchars($apt['doctor_name']) ?></td>
                            <td><?= htmlspecialchars($apt['service']) ?></td>
                            <td><?= $apt['duration'] ?> min</td>
                            <td>
                                <!-- Added status update dropdown -->
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="appointment_id" value="<?= $apt['id'] ?>">
                                    <input type="hidden" name="date" value="<?= $date ?>">
                                    <select name="status" onchange="this.form.submit()" style="border: none; background: transparent; cursor: pointer; font-weight: 600; color: inherit;">
                                        <option value="scheduled" <?= $apt['status'] === 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
                                        <option value="confirmed" <?= $apt['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                                        <option value="completed" <?= $apt['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                                        <option value="cancelled" <?= $apt['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                        <option value="no_show" <?= $apt['status'] === 'no_show' ? 'selected' : '' ?>>No Show</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <div style="display: flex; gap: 12px; align-items: center;">
                                    <a href="/views/appointments/edit.php?id=<?= $apt['id'] ?>" class="btn-link"><?= lang('common.edit') ?></a>
                                    <!-- Added delete button -->
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this appointment?')">
                                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="appointment_id" value="<?= $apt['id'] ?>">
                                        <input type="hidden" name="date" value="<?= $date ?>">
                                        <button type="submit" class="btn-link" style="color: var(--danger); background: none; border: none; cursor: pointer; padding: 0; font: inherit;">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
