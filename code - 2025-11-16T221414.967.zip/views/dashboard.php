<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/../lib/Lang.php';

if (!Auth::check()) {
    redirect('/login.php');
}

if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    redirect('/views/dashboard.php');
}

$pageTitle = lang('menu.dashboard', 'Dashboard');
$breadcrumb = lang('menu.dashboard', 'Dashboard');

include __DIR__ . '/layout/header.php';

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

// Redirect to onboarding if clinic profile incomplete
$stmtOnb = $db->prepare("SELECT address, phone, contact_phone, business_number, contact_person FROM clinics WHERE id = ? LIMIT 1");
$stmtOnb->bind_param("i", $clinicId);
$clinicOnb = safe_stmt_fetch_assoc($stmtOnb);
// accept either phone or contact_phone
$hasPhone = !empty($clinicOnb['contact_phone']) || !empty($clinicOnb['phone']);
if ($clinicOnb && (empty($clinicOnb['address']) || !$hasPhone || empty($clinicOnb['business_number']) || empty($clinicOnb['contact_person']))) {
    redirect('/views/onboarding.php');
}

$stmt = $db->prepare("SELECT COUNT(*) as count FROM appointments WHERE clinic_id = ? AND date = CURDATE()");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$todayAppointments = $row['count'] ?? 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM appointments WHERE clinic_id = ? AND date = DATE_SUB(CURDATE(), INTERVAL 1 DAY)");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$yesterdayAppointments = $row['count'] ?? 0;
$appointmentsTrend = $yesterdayAppointments > 0 ? (($todayAppointments - $yesterdayAppointments) / $yesterdayAppointments) * 100 : 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM patients WHERE clinic_id = ? AND MONTH(created_at) = MONTH(CURDATE())");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$patientsMonth = $row['count'] ?? 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM patients WHERE clinic_id = ? AND MONTH(created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$patientsLastMonth = $row['count'] ?? 0;
$patientsTrend = $patientsLastMonth > 0 ? (($patientsMonth - $patientsLastMonth) / $patientsLastMonth) * 100 : 0;

$stmt = $db->prepare("SELECT SUM(total) as revenue FROM invoices WHERE clinic_id = ? AND MONTH(date) = MONTH(CURDATE()) AND payment_status = 'paid'");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$monthlyRevenue = $row['revenue'] ?? 0;

$stmt = $db->prepare("SELECT SUM(total) as revenue FROM invoices WHERE clinic_id = ? AND MONTH(date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND payment_status = 'paid'");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$lastMonthRevenue = $row['revenue'] ?? 0;
$revenueTrend = $lastMonthRevenue > 0 ? (($monthlyRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100 : 0;

$stmt = $db->prepare("SELECT SUM(total - paid_amount) as total FROM invoices WHERE clinic_id = ? AND payment_status != 'paid'");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$unpaidInvoices = $row['total'] ?? 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM patients WHERE clinic_id = ? AND DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$newPatients = $row['count'] ?? 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM appointments WHERE clinic_id = ? AND status = 'no_show' AND MONTH(date) = MONTH(CURDATE())");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$missedAppointments = $row['count'] ?? 0;

$stmt = $db->prepare("SELECT COUNT(*) as count FROM treatments WHERE clinic_id = ? AND date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$treatmentsWeek = $row['count'] ?? 0;

// Get recent activity
$stmt = $db->prepare("SELECT al.*, u.name as user_name FROM activity_logs al LEFT JOIN users u ON al.user_id = u.id WHERE al.clinic_id = ? ORDER BY al.created_at DESC LIMIT 10");
$stmt->bind_param("i", $clinicId);
$recentActivity = safe_stmt_fetch_all($stmt);

// Get today's appointments
$stmt = $db->prepare("SELECT a.*, p.first_name, p.last_name, u.name as doctor_name FROM appointments a JOIN patients p ON a.patient_id = p.id JOIN users u ON a.doctor_id = u.id WHERE a.clinic_id = ? AND a.date = CURDATE() ORDER BY a.time");
$stmt->bind_param("i", $clinicId);
$todayAppointmentsList = safe_stmt_fetch_all($stmt);

// Get upcoming appointments (next 7 days)
$stmt = $db->prepare("SELECT a.*, p.first_name, p.last_name, u.name as doctor_name FROM appointments a JOIN patients p ON a.patient_id = p.id JOIN users u ON a.doctor_id = u.id WHERE a.clinic_id = ? AND a.date > CURDATE() AND a.date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY a.date, a.time LIMIT 5");
$stmt->bind_param("i", $clinicId);
$upcomingAppointments = safe_stmt_fetch_all($stmt);

// Check low inventory
$stmt = $db->prepare("SELECT * FROM inventory WHERE clinic_id = ? AND quantity <= min_quantity LIMIT 5");
$stmt->bind_param("i", $clinicId);
$lowInventory = safe_stmt_fetch_all($stmt);

// Get revenue chart data (last 7 days)
$revenueChartData = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $stmt = $db->prepare("SELECT COALESCE(SUM(total), 0) as revenue FROM invoices WHERE clinic_id = ? AND DATE(date) = ? AND payment_status = 'paid'");
    $stmt->bind_param("is", $clinicId, $date);
    $row = safe_stmt_fetch_assoc($stmt);
    $revenue = $row['revenue'] ?? 0;
    $revenueChartData[] = ['date' => date('M d', strtotime($date)), 'revenue' => $revenue];
}

$user = Auth::user();
if (!$user) {
    redirect('/login.php');
}
?>

<!-- Modern 2025 dashboard design with glassmorphism and animations -->
<div class="modern-dashboard">
    <!-- Welcome Header with Gradient -->
    <div class="dashboard-welcome">
        <div class="welcome-content">
            <h1 class="welcome-title">
                <?= htmlspecialchars(lang('dashboard.welcome', 'Welcome')) ?>, <?= htmlspecialchars($user['name']) ?>! 👋
            </h1>
            <p class="welcome-subtitle">
                <?= date('l, F j, Y') ?> • <?= htmlspecialchars(lang('dashboard.welcome_subtitle', 'Dashboard Overview')) ?>
            </p>
        </div>
        <div class="welcome-actions">
            <a href="/views/appointments/create.php" class="btn-gradient">
                <span>📅</span> <?= lang('appointments.add', 'New Appointment') ?>
            </a>
        </div>
    </div>
    
    <!-- Enhanced Stats Grid with Trends -->
    <div class="stats-grid-modern">
        <div class="stat-card-modern stat-primary">
            <div class="stat-header">
                <div class="stat-icon-modern">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </div>
                <span class="stat-trend <?= $appointmentsTrend >= 0 ? 'trend-up' : 'trend-down' ?>">
                    <?= $appointmentsTrend >= 0 ? '↑' : '↓' ?> <?= abs(round($appointmentsTrend, 1)) ?>%
                </span>
            </div>
            <div class="stat-value-modern"><?= $todayAppointments ?></div>
            <div class="stat-label-modern"><?= lang('dashboard.today_appointments', "Today's Appointments") ?></div>
        </div>
        
        <div class="stat-card-modern stat-success">
            <div class="stat-header">
                <div class="stat-icon-modern">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <span class="stat-trend <?= $patientsTrend >= 0 ? 'trend-up' : 'trend-down' ?>">
                    <?= $patientsTrend >= 0 ? '↑' : '↓' ?> <?= abs(round($patientsTrend, 1)) ?>%
                </span>
            </div>
            <div class="stat-value-modern"><?= $patientsMonth ?></div>
            <div class="stat-label-modern"><?= lang('dashboard.patients_month', 'Patients This Month') ?></div>
        </div>
        
        <div class="stat-card-modern stat-info">
            <div class="stat-header">
                <div class="stat-icon-modern">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                </div>
                <span class="stat-trend <?= $revenueTrend >= 0 ? 'trend-up' : 'trend-down' ?>">
                    <?= $revenueTrend >= 0 ? '↑' : '↓' ?> <?= abs(round($revenueTrend, 1)) ?>%
                </span>
            </div>
            <div class="stat-value-modern"><?= formatMoney($monthlyRevenue) ?></div>
            <div class="stat-label-modern"><?= lang('dashboard.monthly_revenue', 'Monthly Revenue') ?></div>
        </div>
        
        <div class="stat-card-modern stat-warning">
            <div class="stat-header">
                <div class="stat-icon-modern">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                </div>
            </div>
            <div class="stat-value-modern"><?= formatMoney($unpaidInvoices) ?></div>
            <div class="stat-label-modern"><?= lang('dashboard.unpaid_invoices', 'Unpaid Invoices') ?></div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="quick-actions-modern">
        <a href="/views/patients/create.php" class="action-card-modern">
            <div class="action-icon-modern action-blue">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="8.5" cy="7" r="4"></circle>
                    <line x1="20" y1="8" x2="20" y2="14"></line>
                    <line x1="23" y1="11" x2="17" y2="11"></line>
                </svg>
            </div>
            <span><?= lang('patients.add', 'Add Patient') ?></span>
        </a>
        
        <a href="/views/appointments/create.php" class="action-card-modern">
            <div class="action-icon-modern action-green">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                    <line x1="12" y1="14" x2="12" y2="18"></line>
                    <line x1="10" y1="16" x2="14" y2="16"></line>
                </svg>
            </div>
            <span><?= lang('appointments.add', 'New Appointment') ?></span>
        </a>
        
        <a href="/views/billing/create.php" class="action-card-modern">
            <div class="action-icon-modern action-purple">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                    <line x1="1" y1="10" x2="23" y2="10"></line>
                </svg>
            </div>
            <span><?= lang('billing.create_invoice', 'Create Invoice') ?></span>
        </a>
        
        <a href="/views/inventory/index.php" class="action-card-modern">
            <div class="action-icon-modern action-orange">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                    <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                    <line x1="12" y1="14" x2="12" y2="18"></line>
                    <line x1="10" y1="16" x2="14" y2="16"></line>
                </svg>
            </div>
            <span><?= lang('inventory.title', 'Inventory') ?></span>
        </a>
    </div>
    
    <!-- Main Content Grid -->
    <div class="dashboard-content-grid">
        <!-- Today's Appointments -->
        <div class="dashboard-card-modern">
            <div class="card-header-modern">
                    <h2 class="card-title-modern">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                    <?= lang('dashboard.today_appointments', "Today's Appointments") ?>
                </h2>
                    <a href="/views/appointments/index.php" class="card-link-modern">
                    <?= lang('common.view', 'View') ?> →
                </a>
            </div>
            
            <div class="appointments-list-modern">
                <?php if (empty($todayAppointmentsList)): ?>
                    <div class="empty-state-modern">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                        <p><?= lang('common.no_data', 'No appointments today') ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($todayAppointmentsList as $apt): ?>
                        <div class="appointment-item-modern">
                            <div class="appointment-time-modern"><?= date('H:i', strtotime($apt['time'])) ?></div>
                            <div class="appointment-details-modern">
                                <div class="appointment-patient-modern">
                                    <?= htmlspecialchars($apt['first_name'] . ' ' . $apt['last_name']) ?>
                                </div>
                                <div class="appointment-meta-modern">
                                    <span class="appointment-service-modern"><?= htmlspecialchars($apt['service']) ?></span>
                                    <span class="appointment-doctor-modern">Dr. <?= htmlspecialchars($apt['doctor_name']) ?></span>
                                </div>
                            </div>
                            <div class="appointment-status-modern">
                                <?= getStatusBadge($apt['status']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Upcoming Appointments -->
        <div class="dashboard-card-modern">
            <div class="card-header-modern">
                    <h2 class="card-title-modern">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <?= lang('dashboard.upcoming_appointments', 'Upcoming Appointments') ?>
                </h2>
                <a href="/views/appointments/index.php" class="card-link-modern">
                    View All →
                </a>
            </div>
            
            <div class="upcoming-list-modern">
                <?php if (empty($upcomingAppointments)): ?>
                    <div class="empty-state-modern">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        <p><?= lang('common.no_data', 'No upcoming appointments') ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($upcomingAppointments as $apt): ?>
                        <div class="upcoming-item-modern">
                            <div class="upcoming-date-modern">
                                <div class="date-day"><?= date('d', strtotime($apt['date'])) ?></div>
                                <div class="date-month"><?= date('M', strtotime($apt['date'])) ?></div>
                            </div>
                            <div class="upcoming-details-modern">
                                <div class="upcoming-patient-modern">
                                    <?= htmlspecialchars($apt['first_name'] . ' ' . $apt['last_name']) ?>
                                </div>
                                <div class="upcoming-meta-modern">
                                    <?= date('H:i', strtotime($apt['time'])) ?> • <?= htmlspecialchars($apt['service']) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Revenue Chart -->
        <div class="dashboard-card-modern card-full-width">
            <div class="card-header-modern">
                    <h2 class="card-title-modern">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="20" x2="18" y2="10"></line>
                        <line x1="12" y1="20" x2="12" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="14"></line>
                    </svg>
                    <?= lang('dashboard.revenue_overview', 'Revenue Overview') ?>
                </h2>
                <span class="card-subtitle-modern"><?= lang('dashboard.last_7_days', 'Last 7 Days') ?></span>
            </div>
            
            <div class="chart-container-modern">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="dashboard-card-modern">
            <div class="card-header-modern">
                    <h2 class="card-title-modern">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                    </svg>
                    <?= lang('dashboard.recent_activity', 'Recent Activity') ?>
                </h2>
            </div>
            
            <div class="activity-list-modern">
                <?php if (empty($recentActivity)): ?>
                    <div class="empty-state-modern">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                        </svg>
                        <p><?= lang('common.no_data', 'No data') ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($recentActivity as $activity): ?>
                        <div class="activity-item-modern">
                            <div class="activity-icon-modern">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                            </div>
                            <div class="activity-content-modern">
                                <div class="activity-text-modern">
                                    <strong><?= htmlspecialchars($activity['user_name']) ?></strong>
                                    <?= htmlspecialchars($activity['action']) ?>
                                </div>
                                <div class="activity-time-modern"><?= timeAgo($activity['created_at']) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Low Inventory Alert -->
    <?php if (!empty($lowInventory)): ?>
    <div class="alert-card-modern alert-warning">
        <div class="alert-icon-modern">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                <line x1="12" y1="9" x2="12" y2="13"></line>
                <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
        </div>
        <div class="alert-content-modern">
            <h3 class="alert-title-modern">Low Stock</h3>
            <p class="alert-message-modern">Some items are running low on stock.</p>
            <ul class="alert-list-modern">
                <?php foreach ($lowInventory as $item): ?>
                    <li><?= htmlspecialchars($item['name']) ?> (<?= $item['quantity'] ?> <?= htmlspecialchars($item['unit']) ?>)</li>
                <?php endforeach; ?>
            </ul>
            <a href="/views/inventory/index.php" class="alert-action-modern">
                View Inventory →
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Added Chart.js for revenue visualization -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Revenue Chart
const ctx = document.getElementById('revenueChart');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($revenueChartData, 'date')) ?>,
            datasets: [{
                label: 'Revenue',
                data: <?= json_encode(array_column($revenueChartData, 'revenue')) ?>,
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: 'rgb(59, 130, 246)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    borderRadius: 8,
                    titleFont: {
                        size: 14,
                        weight: '600'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function(context) {
                            return '<?= CURRENCY_SYMBOL ?>' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        callback: function(value) {
                            return '<?= CURRENCY_SYMBOL ?>' + value;
                        },
                        font: {
                            size: 12
                        },
                        color: '#6b7280'
                    }
                },
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        font: {
                            size: 12
                        },
                        color: '#6b7280'
                    }
                }
            }
        }
    });
}
</script>

<?php include __DIR__ . '/layout/footer.php'; ?>
