<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (isset($_GET['lang'])) {
    Lang::setLang($_GET['lang']);
    redirect($_SERVER['PHP_SELF']);
}

if (!Auth::check()) {
    redirect('/login.php');
}

$pageTitle = lang('menu.reports', 'Reports & Analytics');
$breadcrumb = lang('menu.reports', 'Reports & Analytics');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

// Date range filter
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-t');

// Financial Statistics
$financial = ['total_revenue' => 0, 'collected_revenue' => 0, 'outstanding_revenue' => 0, 'total_invoices' => 0];
$patients = ['total_patients' => 0, 'new_patients' => 0, 'active_patients' => 0];
$appointments = ['total_appointments' => 0, 'completed' => 0, 'cancelled' => 0, 'no_shows' => 0];
$topProcedures = [];
$monthlyRevenue = [];
$doctorPerformance = [];

try {
    $stmt = $db->prepare("SELECT 
        COALESCE(SUM(total), 0) as total_revenue,
        COALESCE(SUM(paid_amount), 0) as collected_revenue,
        COALESCE(SUM(total - paid_amount), 0) as outstanding_revenue,
        COUNT(*) as total_invoices
    FROM invoices 
    WHERE clinic_id = ? AND date BETWEEN ? AND ?");
    $stmt->bind_param("iss", $clinicId, $startDate, $endDate);
    $financial = safe_stmt_fetch_assoc($stmt);

    // Patient Statistics
    $stmt = $db->prepare("SELECT 
        COUNT(*) as total_patients,
        SUM(CASE WHEN created_at BETWEEN ? AND ? THEN 1 ELSE 0 END) as new_patients,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_patients
    FROM patients WHERE clinic_id = ?");
    $stmt->bind_param("ssi", $startDate, $endDate, $clinicId);
    $patients = safe_stmt_fetch_assoc($stmt);

    // Appointment Statistics
    $stmt = $db->prepare("SELECT 
        COUNT(*) as total_appointments,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
        SUM(CASE WHEN status = 'no_show' THEN 1 ELSE 0 END) as no_shows
    FROM appointments 
    WHERE clinic_id = ? AND date BETWEEN ? AND ?");
    $stmt->bind_param("iss", $clinicId, $startDate, $endDate);
    $appointments = safe_stmt_fetch_assoc($stmt);

    // Treatment Revenue by Procedure
    $stmt = $db->prepare("SELECT 
        procedure,
        COUNT(*) as count,
        SUM(price) as revenue
    FROM treatments 
    WHERE clinic_id = ? AND date BETWEEN ? AND ?
    GROUP BY procedure
    ORDER BY revenue DESC
    LIMIT 10");
    $stmt->bind_param("iss", $clinicId, $startDate, $endDate);
    $topProcedures = safe_stmt_fetch_all($stmt);

    // Monthly Revenue Trend (last 6 months)
    $stmt = $db->prepare("SELECT 
        DATE_FORMAT(date, '%Y-%m') as month,
        COALESCE(SUM(total), 0) as revenue,
        COALESCE(SUM(paid_amount), 0) as collected
    FROM invoices 
    WHERE clinic_id = ? AND date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(date, '%Y-%m')
    ORDER BY month");
    $stmt->bind_param("i", $clinicId);
    $monthlyRevenue = safe_stmt_fetch_all($stmt);

    // Doctor Performance
    $stmt = $db->prepare("SELECT 
        u.name as doctor_name,
        COUNT(DISTINCT a.id) as appointments,
        COUNT(DISTINCT t.id) as treatments,
        COALESCE(SUM(t.price), 0) as revenue
    FROM users u
    LEFT JOIN appointments a ON u.id = a.doctor_id AND a.date BETWEEN ? AND ?
    LEFT JOIN treatments t ON u.id = t.doctor_id AND t.date BETWEEN ? AND ?
    WHERE u.clinic_id = ? AND u.role = 'doctor'
    GROUP BY u.id, u.name
    ORDER BY revenue DESC");
    $stmt->bind_param("ssssi", $startDate, $endDate, $startDate, $endDate, $clinicId);
    $doctorPerformance = safe_stmt_fetch_all($stmt);
    
} catch (Exception $e) {
    error_log("Reports error: " . $e->getMessage());
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('menu.reports', 'Reports & Analytics') ?></h2>
        <div class="table-actions">
            <form method="GET" style="display: flex; gap: 12px; align-items: center;">
                <input type="date" name="start_date" value="<?= htmlspecialchars($startDate) ?>" class="form-control" style="width: auto;">
                <span>to</span>
                <input type="date" name="end_date" value="<?= htmlspecialchars($endDate) ?>" class="form-control" style="width: auto;">
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>
    </div>
    
    <div style="padding: 32px;">
        <!-- Financial Overview -->
        <div style="margin-bottom: 48px;">
            <h3 style="margin-bottom: 24px; font-size: 20px; font-weight: 700;"><?= lang('menu.reports', 'Reports & Analytics') ?></h3>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">💰</div>
                    <div class="stat-content">
                        <div class="stat-label"><?= lang('billing.total', 'Total Revenue') ?></div>
                        <div class="stat-value"><?= formatMoney($financial['total_revenue'] ?? 0) ?></div>
                        <div class="stat-change"><?= $financial['total_invoices'] ?? 0 ?> <?= lang('billing.invoices', 'invoices') ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">✅</div>
                    <div class="stat-content">
                        <div class="stat-label"><?= lang('billing.collected', 'Collected') ?></div>
                        <div class="stat-value"><?= formatMoney($financial['collected_revenue'] ?? 0) ?></div>
                        <div class="stat-change positive">
                            <?= $financial['total_revenue'] > 0 ? round(($financial['collected_revenue'] / $financial['total_revenue']) * 100, 1) : 0 ?>% collection rate
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">⏳</div>
                    <div class="stat-content">
                        <div class="stat-label"><?= lang('billing.outstanding', 'Outstanding') ?></div>
                        <div class="stat-value"><?= formatMoney($financial['outstanding_revenue'] ?? 0) ?></div>
                        <div class="stat-change">Pending payments</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Patient & Appointment Stats -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 32px; margin-bottom: 48px;">
            <div class="card">
                <div class="card-header">
                    <h3>Patient Statistics</h3>
                </div>
                <div style="padding: 24px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: #6b7280;">Total Patients</span>
                        <strong style="font-size: 24px; color: #0ea5e9;"><?= $patients['total_patients'] ?? 0 ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: #6b7280;">New Patients</span>
                        <strong style="font-size: 24px; color: #10b981;"><?= $patients['new_patients'] ?? 0 ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6b7280;">Active Patients</span>
                        <strong style="font-size: 24px; color: #8b5cf6;"><?= $patients['active_patients'] ?? 0 ?></strong>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3>Appointment Statistics</h3>
                </div>
                <div style="padding: 24px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: #6b7280;">Total Appointments</span>
                        <strong style="font-size: 24px; color: #0ea5e9;"><?= $appointments['total_appointments'] ?? 0 ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: #6b7280;">Completed</span>
                        <strong style="font-size: 24px; color: #10b981;"><?= $appointments['completed'] ?? 0 ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: #6b7280;">Cancelled</span>
                        <strong style="font-size: 24px; color: #f59e0b;"><?= $appointments['cancelled'] ?? 0 ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6b7280;">No Shows</span>
                        <strong style="font-size: 24px; color: #ef4444;"><?= $appointments['no_shows'] ?? 0 ?></strong>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Top Procedures -->
        <div class="card" style="margin-bottom: 48px;">
            <div class="card-header">
                <h3>Top Procedures by Revenue</h3>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Procedure</th>
                            <th>Count</th>
                            <th>Revenue</th>
                            <th>Avg Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($topProcedures)): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 40px;">No data available</td></tr>
                        <?php else: ?>
                            <?php foreach ($topProcedures as $proc): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($proc['procedure']) ?></strong></td>
                                    <td><?= $proc['count'] ?></td>
                                    <td><?= formatMoney($proc['revenue']) ?></td>
                                    <td><?= formatMoney($proc['revenue'] / $proc['count']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Monthly Revenue Trend -->
        <div class="card" style="margin-bottom: 48px;">
            <div class="card-header">
                <h3>Revenue Trend (Last 6 Months)</h3>
            </div>
            <div style="padding: 32px;">
                <div style="display: flex; align-items: flex-end; gap: 16px; height: 300px;">
                    <?php 
                    $maxRevenue = !empty($monthlyRevenue) ? max(array_column($monthlyRevenue, 'revenue')) : 1;
                    foreach ($monthlyRevenue as $month): 
                        $height = ($month['revenue'] / $maxRevenue) * 100;
                    ?>
                        <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                            <div style="width: 100%; background: linear-gradient(180deg, #0ea5e9 0%, #0284c7 100%); border-radius: 8px 8px 0 0; position: relative; height: <?= $height ?>%; min-height: 20px; display: flex; align-items: flex-start; justify-content: center; padding-top: 8px;">
                                <span style="font-size: 12px; font-weight: 600; color: white;"><?= formatMoney($month['revenue']) ?></span>
                            </div>
                            <div style="margin-top: 12px; font-size: 12px; color: #6b7280; font-weight: 500;">
                                <?= date('M', strtotime($month['month'] . '-01')) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Doctor Performance -->
        <div class="card">
            <div class="card-header">
                <h3>Doctor Performance</h3>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Doctor</th>
                            <th>Appointments</th>
                            <th>Treatments</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($doctorPerformance)): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 40px;">No data available</td></tr>
                        <?php else: ?>
                            <?php foreach ($doctorPerformance as $doctor): ?>
                                <tr>
                                    <td><strong>Dr. <?= htmlspecialchars($doctor['doctor_name']) ?></strong></td>
                                    <td><?= $doctor['appointments'] ?></td>
                                    <td><?= $doctor['treatments'] ?></td>
                                    <td><?= formatMoney($doctor['revenue']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
