<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

$invoiceId = (int)($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT i.*, p.first_name, p.last_name, p.phone, p.address FROM invoices i JOIN patients p ON i.patient_id = p.id WHERE i.id = ? AND i.clinic_id = ?");
$stmt->bind_param("ii", $invoiceId, $clinicId);
$invoice = safe_stmt_fetch_assoc($stmt);

if (!$invoice) {
    redirect('/views/billing/index.php');
}

$pageTitle = lang('billing.invoice') . ' ' . $invoice['invoice_no'];
$breadcrumb = lang('billing.invoice');

// Get invoice items
$stmt = $db->prepare("SELECT * FROM invoice_items WHERE invoice_id = ?");
$stmt->bind_param("i", $invoiceId);
$items = safe_stmt_fetch_all($stmt);

$clinic = Auth::clinic();

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('billing.invoice') ?> <?= htmlspecialchars($invoice['invoice_no']) ?></h2>
        <div class="table-actions">
            <a href="/views/billing/print.php?id=<?= $invoice['id'] ?>" class="btn btn-primary" target="_blank"><?= lang('billing.print') ?></a>
            <a href="/views/billing/pdf.php?id=<?= $invoice['id'] ?>&download=1" class="btn btn-secondary" target="_blank" rel="noopener">Download PDF</a>
        </div>
    </div>
    
    <div style="padding: 32px;">
        <!-- Invoice Header -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 32px; margin-bottom: 32px;">
            <div>
                <h3 style="margin-bottom: 12px;"><?= htmlspecialchars($clinic['name']) ?></h3>
                <div style="color: #6b7280; line-height: 1.6;">
                    <?= htmlspecialchars($clinic['address'] ?? '') ?><br>
                    <?= htmlspecialchars($clinic['phone'] ?? '') ?><br>
                    <?= htmlspecialchars($clinic['email'] ?? '') ?>
                </div>
            </div>
            <div style="text-align: right;">
                <div style="margin-bottom: 8px;">
                    <strong>Invoice No:</strong> <?= htmlspecialchars($invoice['invoice_no']) ?>
                </div>
                <div style="margin-bottom: 8px;">
                    <strong>Date:</strong> <?= formatDate($invoice['date']) ?>
                </div>
                <div>
                    <strong>Status:</strong> <?= getStatusBadge($invoice['payment_status']) ?>
                </div>
            </div>
        </div>
        
        <!-- Patient Info -->
        <div style="background: #f9fafb; padding: 16px; border-radius: 8px; margin-bottom: 32px;">
            <h4 style="margin-bottom: 8px;">Bill To:</h4>
            <div style="line-height: 1.6;">
                <strong><?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></strong><br>
                <?= htmlspecialchars($invoice['phone']) ?><br>
                <?= htmlspecialchars($invoice['address'] ?? '') ?>
            </div>
        </div>
        
        <!-- Items Table -->
        <table style="margin-bottom: 32px;">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align: right;">Quantity</th>
                    <th style="text-align: right;">Unit Price</th>
                    <th style="text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['description']) ?></td>
                        <td style="text-align: right;"><?= $item['quantity'] ?></td>
                        <td style="text-align: right;"><?= formatMoney($item['unit_price']) ?></td>
                        <td style="text-align: right;"><?= formatMoney($item['line_total']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Totals -->
        <div style="max-width: 400px; margin-left: auto;">
            <div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
                <span>Subtotal:</span>
                <strong><?= formatMoney($invoice['subtotal']) ?></strong>
            </div>
            <?php $taxPercent = ($invoice['subtotal'] > 0) ? ($invoice['tax'] / $invoice['subtotal'] * 100) : 0; ?>
            <div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
                <span>Tax (<?= number_format($taxPercent, 2) ?>%):</span>
                <strong><?= formatMoney($invoice['tax']) ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 2px solid #1f2937; font-size: 18px;">
                <span>Total:</span>
                <strong><?= formatMoney($invoice['total']) ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; padding: 12px 0; color: #10b981;">
                <span>Paid:</span>
                <strong><?= formatMoney($invoice['paid_amount']) ?></strong>
            </div>
            <?php if ($invoice['total'] > $invoice['paid_amount']): ?>
                <div style="display: flex; justify-content: space-between; padding: 12px 0; color: #ef4444; font-size: 18px;">
                    <span>Balance Due:</span>
                    <strong><?= formatMoney($invoice['total'] - $invoice['paid_amount']) ?></strong>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Added payment recording functionality -->
        <?php if ($invoice['payment_status'] !== 'paid'): ?>
        <div style="margin-top: 32px; padding: 24px; background: #f9fafb; border-radius: 8px;">
            <h3 style="margin-bottom: 16px;">Record Payment</h3>
            <form method="post" action="/views/billing/record-payment.php">
                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                <input type="hidden" name="invoice_id" value="<?= $invoice['id'] ?>">
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
                    <div class="form-group">
                        <label>Amount *</label>
                        <input type="number" name="amount" class="form-control" step="0.01" min="0.01" max="<?= $invoice['total'] - $invoice['paid_amount'] ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method *</label>
                        <select name="payment_method" class="form-control" required>
                            <option value="cash">Cash</option>
                            <option value="card">Card</option>
                            <option value="transfer">Bank Transfer</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Date *</label>
                        <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary" style="margin-top: 16px;">Record Payment</button>
            </form>
        </div>
        <?php endif; ?>
        
        <?php if ($invoice['payment_method']): ?>
            <div style="margin-top: 32px; padding-top: 32px; border-top: 1px solid #e5e7eb;">
                <strong>Payment Method:</strong> <?= ucfirst($invoice['payment_method']) ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
