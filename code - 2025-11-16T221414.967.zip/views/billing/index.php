<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$pageTitle = 'Invoices';
$breadcrumb = 'Invoices';

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        redirect('/views/billing/index.php?error=csrf');
        exit;
    }

    $invoiceId = (int)$_POST['invoice_id'];
    $stmt = $db->prepare("DELETE FROM invoices WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("ii", $invoiceId, $clinicId);
    $stmt->execute();
    redirect('/views/billing/index.php?success=deleted');
}

$filter = $_GET['filter'] ?? 'all';

$sql = "SELECT i.*, p.first_name, p.last_name 
        FROM invoices i 
        JOIN patients p ON i.patient_id = p.id 
        WHERE i.clinic_id = ?";

if ($filter === 'unpaid') {
    $sql .= " AND i.payment_status = 'unpaid'";
} elseif ($filter === 'paid') {
    $sql .= " AND i.payment_status = 'paid'";
} elseif ($filter === 'partial') {
    $sql .= " AND i.payment_status = 'partial'";
}

$sql .= " ORDER BY i.date DESC";

$stmt = $db->prepare($sql);
$stmt->bind_param("i", $clinicId);
$invoices = safe_stmt_fetch_all($stmt);

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2>Invoices</h2>
        <div class="table-actions">
            <a href="/views/billing/create.php" class="btn btn-primary">+ Create Invoice</a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success" style="margin: 20px 24px;">
            <?= $_GET['success'] === 'deleted' ? 'Invoice deleted successfully!' : 'Action completed successfully!' ?>
        </div>
    <?php endif; ?>
    
    <div style="padding: 16px 24px; border-bottom: 1px solid var(--gray-200); display: flex; gap: 12px;">
        <a href="?filter=all" class="btn <?= $filter === 'all' ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <a href="?filter=unpaid" class="btn <?= $filter === 'unpaid' ? 'btn-primary' : 'btn-secondary' ?>">Unpaid</a>
        <a href="?filter=partial" class="btn <?= $filter === 'partial' ? 'btn-primary' : 'btn-secondary' ?>">Partial</a>
        <a href="?filter=paid" class="btn <?= $filter === 'paid' ? 'btn-primary' : 'btn-secondary' ?>">Paid</a>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Invoice No</th>
                <th>Date</th>
                <th>Patient</th>
                <th>Total</th>
                <th>Paid Amount</th>
                <th>Payment Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($invoices)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        No data available
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($invoices as $invoice): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($invoice['invoice_no']) ?></strong></td>
                        <td><?= formatDate($invoice['date']) ?></td>
                        <td><?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></td>
                        <td><strong><?= formatMoney($invoice['total']) ?></strong></td>
                        <td><?= formatMoney($invoice['paid_amount']) ?></td>
                        <td><?= getStatusBadge($invoice['payment_status']) ?></td>
                        <td>
                            <div style="display: flex; gap: 12px; align-items: center;">
                                <a href="/views/billing/view.php?id=<?= $invoice['id'] ?>" class="btn-link">View</a>
                                <a href="/views/billing/print.php?id=<?= $invoice['id'] ?>" class="btn-link" target="_blank">Print</a>
                                <!-- Added delete button -->
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this invoice?')">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="invoice_id" value="<?= $invoice['id'] ?>">
                                    <button type="submit" class="btn-link" style="color: var(--danger); background: none; border: none; cursor: pointer; padding: 0; font: inherit;">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
