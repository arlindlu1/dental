<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('billing.create_invoice');
$breadcrumb = lang('billing.create_invoice');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$stmt = $db->prepare("SELECT id, first_name, last_name FROM patients WHERE clinic_id = ? ORDER BY first_name");
$stmt->bind_param("i", $clinicId);
$patients = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT * FROM procedures WHERE clinic_id IS NULL OR clinic_id = ? ORDER BY name_" . Lang::current());
$stmt->bind_param("i", $clinicId);
$procedures = safe_stmt_fetch_all($stmt);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $patientId = (int)$_POST['patient_id'];
    $date = $_POST['date'];
    $items = $_POST['items'] ?? [];
    $taxRate = (float)($_POST['tax_rate'] ?? 20);
    $paymentMethod = $_POST['payment_method'] ?? null;
    $paidAmount = (float)($_POST['paid_amount'] ?? 0);
    
    $subtotal = 0;
    foreach ($items as $item) {
        if (!empty($item['description'])) {
            $subtotal += (float)$item['quantity'] * (float)$item['unit_price'];
        }
    }
    
    $tax = $subtotal * ($taxRate / 100);
    $total = $subtotal + $tax;
    
    $paymentStatus = 'unpaid';
    if ($paidAmount >= $total) {
        $paymentStatus = 'paid';
    } elseif ($paidAmount > 0) {
        $paymentStatus = 'partial';
    }
    
    $invoiceNo = generateInvoiceNumber($clinicId);
    
    $stmt = $db->prepare("INSERT INTO invoices (clinic_id, invoice_no, patient_id, date, subtotal, tax, total, paid_amount, payment_status, payment_method, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    // Types: i (clinic), s (invoice_no), i (patient), s (date), d (subtotal), d (tax), d (total), d (paid_amount), s (payment_status), s (payment_method), i (created_by)
    $stmt->bind_param("isisddddssi", $clinicId, $invoiceNo, $patientId, $date, $subtotal, $tax, $total, $paidAmount, $paymentStatus, $paymentMethod, $userId);

    if ($stmt->execute()) {
        // Use Database helper to retrieve last insert id
        $invoiceId = $db->lastInsertId();
        
        // Insert items
        foreach ($items as $item) {
            if (!empty($item['description'])) {
                $lineTotal = (float)$item['quantity'] * (float)$item['unit_price'];
                $itemStmt = $db->prepare("INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?)");
                $itemStmt->bind_param("isidd", $invoiceId, $item['description'], $item['quantity'], $item['unit_price'], $lineTotal);
                $itemStmt->execute();
            }
        }
        
        Auth::logActivity('create_invoice', 'invoice', $invoiceId, "Created invoice: $invoiceNo");
        redirect('/views/billing/view.php?id=' . $invoiceId);
    } else {
        $error = 'Failed to create invoice';
    }
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('billing.create_invoice') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post" id="invoiceForm">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 32px;">
                <div class="form-group">
                    <label><?= lang('billing.patient') ?> *</label>
                    <select name="patient_id" class="form-control" required>
                        <option value="">Select patient</option>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?= $patient['id'] ?>"><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('billing.date') ?> *</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
            </div>
            
            <h3 style="margin-bottom: 16px;"><?= lang('billing.items') ?></h3>
            <div id="items">
                <!-- Updated item row to include procedure selection with auto-price -->
                <div class="invoice-item" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 12px; margin-bottom: 12px; align-items: start;">
                    <div>
                        <select name="items[0][procedure]" class="form-control procedure-select" onchange="updatePrice(this, 0)" required>
                            <option value="">Select procedure</option>
                            <?php foreach ($procedures as $proc): ?>
                                <option value="<?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?>" data-price="<?= $proc['price'] ?>">
                                    <?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?> - <?= formatMoney($proc['price']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="items[0][description]" class="item-description">
                    </div>
                    <input type="number" name="items[0][quantity]" placeholder="Qty" class="form-control item-quantity" value="1" min="1" onchange="calculateLineTotal(0)" required>
                    <input type="number" name="items[0][unit_price]" placeholder="Price" class="form-control item-price" step="0.01" min="0" onchange="calculateLineTotal(0)" required readonly>
                    <input type="text" class="form-control item-total" readonly placeholder="Total" style="background: #f9fafb; font-weight: 600;">
                    <button type="button" onclick="removeItem(this)" class="btn btn-danger" style="padding: 10px 16px;">×</button>
                </div>
            </div>
            
            <button type="button" onclick="addItem()" class="btn btn-secondary" style="margin-bottom: 32px;">
                + Add Item
            </button>
            
            <!-- Added total calculation display with manual tax rate input -->
            <div style="background: #f9fafb; padding: 24px; border-radius: 12px; margin-bottom: 24px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-weight: 500;">Subtotal:</span>
                    <span id="subtotal-display" style="font-weight: 600;">€0.00</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; align-items: center;">
                    <span style="font-weight: 500;">Tax:</span>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <input type="number" name="tax_rate" id="tax_rate" class="form-control" value="20" min="0" max="100" step="0.01" style="width: 80px; padding: 6px 8px;" onchange="updateTotals()">
                        <span style="font-weight: 600;">%</span>
                        <span id="tax-display" style="font-weight: 600; min-width: 80px; text-align: right;">€0.00</span>
                    </div>
                </div>
                <div style="display: flex; justify-content: space-between; padding-top: 12px; border-top: 2px solid #e5e7eb;">
                    <span style="font-weight: 700; font-size: 18px;">Total:</span>
                    <span id="total-display" style="font-weight: 700; font-size: 18px; color: #3b82f6;">€0.00</span>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('billing.payment_method') ?></label>
                    <select name="payment_method" class="form-control">
                        <option value="">-</option>
                        <option value="cash"><?= lang('billing.cash') ?></option>
                        <option value="card"><?= lang('billing.card') ?></option>
                        <option value="transfer"><?= lang('billing.transfer') ?></option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('billing.paid_amount') ?></label>
                    <input type="number" name="paid_amount" class="form-control" step="0.01" min="0" value="0">
                </div>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/billing/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<script>
const procedures = <?= json_encode($procedures) ?>;
let itemCount = 1;

function updatePrice(select, index) {
    const selectedOption = select.options[select.selectedIndex];
    const price = selectedOption.getAttribute('data-price');
    const description = selectedOption.value;
    
    const row = select.closest('.invoice-item');
    row.querySelector('.item-description').value = description;
    row.querySelector('.item-price').value = price || 0;
    
    calculateLineTotal(index);
}

function calculateLineTotal(index) {
    const items = document.querySelectorAll('.invoice-item');
    if (items[index]) {
        const quantity = parseFloat(items[index].querySelector('.item-quantity').value) || 0;
        const price = parseFloat(items[index].querySelector('.item-price').value) || 0;
        const total = quantity * price;
        items[index].querySelector('.item-total').value = total.toFixed(2);
    }
    
    updateTotals();
}

function updateTotals() {
    let subtotal = 0;
    document.querySelectorAll('.invoice-item').forEach(item => {
        const total = parseFloat(item.querySelector('.item-total').value) || 0;
        subtotal += total;
    });
    
    const taxRate = parseFloat(document.getElementById('tax_rate').value) || 0;
    const tax = subtotal * (taxRate / 100);
    const total = subtotal + tax;
    
    document.getElementById('subtotal-display').textContent = formatMoney(subtotal);
    document.getElementById('tax-display').textContent = formatMoney(tax);
    document.getElementById('total-display').textContent = formatMoney(total);
}

function removeItem(button) {
    if (document.querySelectorAll('.invoice-item').length > 1) {
        button.closest('.invoice-item').remove();
        updateTotals();
    } else {
        alert('At least one item is required');
    }
}

function addItem() {
    const itemsDiv = document.getElementById('items');
    const newItem = document.createElement('div');
    newItem.className = 'invoice-item';
    newItem.style.cssText = 'display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 12px; margin-bottom: 12px; align-items: start;';
    
    let procedureOptions = '<option value="">Select procedure</option>';
    procedures.forEach(proc => {
        const name = '<?= Lang::current() ?>' === 'sq' ? proc.name_sq : proc.name_en;
        procedureOptions += `<option value="${name}" data-price="${proc.price}">${name} - ${formatMoney(proc.price)}</option>`;
    });
    
    newItem.innerHTML = `
        <div>
            <select name="items[${itemCount}][procedure]" class="form-control procedure-select" onchange="updatePrice(this, ${itemCount})" required>
                ${procedureOptions}
            </select>
            <input type="hidden" name="items[${itemCount}][description]" class="item-description">
        </div>
        <input type="number" name="items[${itemCount}][quantity]" placeholder="Qty" class="form-control item-quantity" value="1" min="1" onchange="calculateLineTotal(${itemCount})" required>
        <input type="number" name="items[${itemCount}][unit_price]" placeholder="Price" class="form-control item-price" step="0.01" min="0" onchange="calculateLineTotal(${itemCount})" required readonly>
        <input type="text" class="form-control item-total" readonly placeholder="Total" style="background: #f9fafb; font-weight: 600;">
        <button type="button" onclick="removeItem(this)" class="btn btn-danger" style="padding: 10px 16px;">×</button>
    `;
    itemsDiv.appendChild(newItem);
    itemCount++;
}

function formatMoney(amount) {
    // Format invoice amounts using Euro (EUR)
    // Use page language for locale formatting but always show EUR currency
    const locale = '<?= Lang::current() === 'sq' ? 'sq-AL' : 'en-GB' ?>';
    return new Intl.NumberFormat(locale, { style: 'currency', currency: 'EUR' }).format(amount);
}

// Initialize totals on page load
document.addEventListener('DOMContentLoaded', updateTotals);
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
