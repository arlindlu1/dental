<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/views/billing/index.php');
}

if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
    die('CSRF token validation failed');
}

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$invoiceId = (int)$_POST['invoice_id'];
$amount = (float)$_POST['amount'];
$paymentMethod = sanitize($_POST['payment_method']);
$paymentDate = $_POST['payment_date'];

// Get current invoice
$stmt = $db->prepare("SELECT * FROM invoices WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("ii", $invoiceId, $clinicId);
$invoice = safe_stmt_fetch_assoc($stmt);

if (!$invoice) {
    redirect('/views/billing/index.php');
}

// Calculate new paid amount
$newPaidAmount = $invoice['paid_amount'] + $amount;

// Determine new status
$paymentStatus = 'unpaid';
if ($newPaidAmount >= $invoice['total']) {
    $paymentStatus = 'paid';
    $newPaidAmount = $invoice['total']; // Cap at total
} elseif ($newPaidAmount > 0) {
    $paymentStatus = 'partial';
}

// Update invoice (scoped to clinic)
$stmt = $db->prepare("UPDATE invoices SET paid_amount = ?, payment_status = ?, payment_method = ? WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("dssii", $newPaidAmount, $paymentStatus, $paymentMethod, $invoiceId, $clinicId);
$stmt->execute();

// Update patient balance (scoped to clinic)
$balanceChange = -$amount;
$stmt = $db->prepare("UPDATE patients SET balance = balance + ? WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("dii", $balanceChange, $invoice['patient_id'], $clinicId);
$stmt->execute();

// Log payment
$stmt = $db->prepare("INSERT INTO payment_logs (clinic_id, invoice_id, amount, payment_method, payment_date, recorded_by) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("iidssi", $clinicId, $invoiceId, $amount, $paymentMethod, $paymentDate, $_SESSION['user_id']);
$stmt->execute();

Auth::logActivity('record_payment', 'invoice', $invoiceId, "Recorded payment of " . formatMoney($amount));

redirect('/views/billing/view.php?id=' . $invoiceId);
