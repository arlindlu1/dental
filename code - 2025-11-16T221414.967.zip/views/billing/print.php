<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    die('Unauthorized');
}

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$invoiceId = (int)($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT i.*, p.first_name, p.last_name, p.phone, p.address FROM invoices i JOIN patients p ON i.patient_id = p.id WHERE i.id = ? AND i.clinic_id = ?");
$stmt->bind_param("ii", $invoiceId, $clinicId);
$invoice = safe_stmt_fetch_assoc($stmt);

if (!$invoice) {
    die('Invoice not found');
}

$items = safe_stmt_fetch_all($db->prepare("SELECT * FROM invoice_items WHERE invoice_id = ?"));

$clinic = Auth::clinic();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Invoice <?= htmlspecialchars($invoice['invoice_no']) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
        .header h1 { margin: 0; font-size: 28px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
        .info-section h3 { margin-top: 0; font-size: 14px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f5f5f5; font-weight: 600; }
        .totals { text-align: right; margin-top: 20px; }
        .totals div { margin: 8px 0; }
        .total-row { font-size: 18px; font-weight: bold; margin-top: 12px; padding-top: 12px; border-top: 2px solid #333; }
        @media print { body { margin: 0; } .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Print Invoice</button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px;">Close</button>
    </div>
    
    <div class="header">
        <h1><?= htmlspecialchars($clinic['name']) ?></h1>
        <p><?= htmlspecialchars($clinic['address'] ?? '') ?></p>
        <p><?= htmlspecialchars($clinic['phone'] ?? '') ?> | <?= htmlspecialchars($clinic['email'] ?? '') ?></p>
        <?php if ($clinic['tax_id']): ?>
            <p>Tax ID: <?= htmlspecialchars($clinic['tax_id']) ?></p>
        <?php endif; ?>
    </div>
    
    <div class="info-grid">
        <div class="info-section">
            <h3>BILL TO:</h3>
            <p><strong><?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></strong></p>
            <p><?= htmlspecialchars($invoice['phone']) ?></p>
            <?php if ($invoice['address']): ?>
                <p><?= htmlspecialchars($invoice['address']) ?></p>
            <?php endif; ?>
        </div>
        <div class="info-section">
            <h3>INVOICE DETAILS:</h3>
            <p><strong>Invoice No:</strong> <?= htmlspecialchars($invoice['invoice_no']) ?></p>
            <p><strong>Date:</strong> <?= formatDate($invoice['date']) ?></p>
            <p><strong>Status:</strong> <?= ucfirst($invoice['payment_status']) ?></p>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th style="text-align: center;">Quantity</th>
                <th style="text-align: right;">Unit Price</th>
                <th style="text-align: right;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['description']) ?></td>
                    <td style="text-align: center;"><?= $item['quantity'] ?></td>
                    <td style="text-align: right;"><?= formatMoney($item['unit_price']) ?></td>
                    <td style="text-align: right;"><?= formatMoney($item['line_total']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <div class="totals">
        <div><strong>Subtotal:</strong> <?= formatMoney($invoice['subtotal']) ?></div>
        <div><strong>Tax:</strong> <?= formatMoney($invoice['tax']) ?></div>
        <div class="total-row"><strong>Total:</strong> <?= formatMoney($invoice['total']) ?></div>
        <div><strong>Paid:</strong> <?= formatMoney($invoice['paid_amount']) ?></div>
        <div style="color: #ef4444;"><strong>Balance Due:</strong> <?= formatMoney($invoice['total'] - $invoice['paid_amount']) ?></div>
    </div>
    
    <?php if ($invoice['notes']): ?>
        <div style="margin-top: 40px; padding: 20px; background: #f9fafb; border-radius: 8px;">
            <h3 style="margin-top: 0;">Notes:</h3>
            <p><?= nl2br(htmlspecialchars($invoice['notes'])) ?></p>
        </div>
    <?php endif; ?>
</body>
</html>
