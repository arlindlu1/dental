<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$pageTitle = Lang::get('inventory.title');
$breadcrumb = Lang::get('inventory.title');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

// Handle add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    // Handle delete action
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $deleteId = (int)($_POST['inventory_id'] ?? 0);
        if ($deleteId) {
            $delStmt = $db->prepare("DELETE FROM inventory WHERE id = ? AND clinic_id = ?");
            $delStmt->bind_param("ii", $deleteId, $clinicId);
            $delStmt->execute();
        }
        redirect('/views/inventory/index.php');
    }
    
    $name = sanitize($_POST['name']);
    $quantity = (int)$_POST['quantity'];
    $minQuantity = (int)$_POST['min_quantity'];
    $unit = sanitize($_POST['unit']);
    $supplier = sanitize($_POST['supplier'] ?? '');
    
    if (isset($_POST['id']) && $_POST['id']) {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("UPDATE inventory SET name = ?, quantity = ?, min_quantity = ?, unit = ?, supplier = ? WHERE id = ? AND clinic_id = ?");
        $stmt->bind_param("siissii", $name, $quantity, $minQuantity, $unit, $supplier, $id, $clinicId);
    } else {
        $cost = isset($_POST['cost']) ? (float)$_POST['cost'] : 0.00;
        $stmt = $db->prepare("INSERT INTO inventory (clinic_id, name, quantity, min_quantity, unit, supplier) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isiiss", $clinicId, $name, $quantity, $minQuantity, $unit, $supplier);
    }
    
    if ($stmt->execute()) {
        // If this was an insert, register an expense if a cost was provided
        if (!isset($id)) {
            $inventoryId = $db->insert_id;
            if (isset($cost) && $cost > 0) {
                // Ensure expenses table exists (safe-create for older installs)
                $createSql = "CREATE TABLE IF NOT EXISTS expenses (
                  id INT NOT NULL AUTO_INCREMENT,
                  clinic_id INT NOT NULL,
                  inventory_id INT DEFAULT NULL,
                  amount DECIMAL(10,2) NOT NULL,
                  description VARCHAR(255),
                  date DATE NOT NULL,
                  created_by INT DEFAULT NULL,
                  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  PRIMARY KEY (id),
                  KEY clinic_id (clinic_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
                $db->query($createSql);

                $expStmt = $db->prepare("INSERT INTO expenses (clinic_id, inventory_id, amount, description, date, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                $desc = "Inventory purchase: " . $name;
                $today = date('Y-m-d');
                $expStmt->bind_param("iidssi", $clinicId, $inventoryId, $cost, $desc, $today, $_SESSION['user_id']);
                $expStmt->execute();
            }
        }

        redirect('/views/inventory/index.php');
    } else {
        // keep on page with an error (simple fallback)
        $error = 'Failed to save inventory';
    }
}

$stmt = $db->prepare("SELECT * FROM inventory WHERE clinic_id = ? ORDER BY name");
$stmt->bind_param("i", $clinicId);
$inventory = safe_stmt_fetch_all($stmt);

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= Lang::get('inventory.title') ?></h2>
        <button onclick="document.getElementById('addModal').style.display='block'" class="btn btn-primary"><?= Lang::get('inventory.add') ?></button>
    </div>
    
    <table>
        <thead>
            <tr>
                <th><?= Lang::get('inventory.name') ?></th>
                <th><?= Lang::get('inventory.quantity') ?></th>
                <th><?= Lang::get('inventory.min_quantity') ?></th>
                <th><?= Lang::get('inventory.unit') ?></th>
                <th><?= Lang::get('inventory.supplier') ?></th>
                <th><?= Lang::get('common.actions') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($inventory)): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px;">
                        <?= Lang::get('common.no_data') ?>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($inventory as $item): ?>
                    <tr style="<?= $item['quantity'] <= $item['min_quantity'] ? 'background: #fef3c7;' : '' ?>">
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= $item['min_quantity'] ?></td>
                        <td><?= htmlspecialchars($item['unit']) ?></td>
                        <td><?= htmlspecialchars($item['supplier'] ?? '-') ?></td>
                        <td>
                            <a href="#" onclick="editItem(<?= htmlspecialchars(json_encode($item)) ?>)" class="btn-link"><?= Lang::get('common.edit') ?></a>
                            <form method="POST" style="display:inline; margin-left:8px;" onsubmit="return confirm('Delete this inventory item?');">
                                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="inventory_id" value="<?= $item['id'] ?>">
                                <button type="submit" class="btn-link" style="color: var(--danger); background: none; border: none; cursor: pointer; padding: 0; font: inherit;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit Modal -->
<div id="addModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; padding: 40px;">
    <div style="background: white; max-width: 600px; margin: 0 auto; border-radius: 16px; padding: 32px;">
        <h2 id="modalTitle"><?= Lang::get('inventory.add') ?></h2>
        <form method="post" style="margin-top: 24px;">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="id" id="itemId">
            
            <div class="form-group">
                <label><?= Lang::get('inventory.name') ?> *</label>
                <input type="text" name="name" id="itemName" class="form-control" required>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= Lang::get('inventory.quantity') ?> *</label>
                    <input type="number" name="quantity" id="itemQuantity" class="form-control" min="0" required>
                </div>
                
                <div class="form-group">
                    <label><?= Lang::get('inventory.min_quantity') ?> *</label>
                    <input type="number" name="min_quantity" id="itemMinQuantity" class="form-control" min="0" required>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= Lang::get('inventory.unit') ?> *</label>
                    <input type="text" name="unit" id="itemUnit" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?= Lang::get('inventory.supplier') ?></label>
                    <input type="text" name="supplier" id="itemSupplier" class="form-control">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 12px;">
                <div class="form-group">
                    <label>Cost (per unit)</label>
                    <input type="number" name="cost" id="itemCost" class="form-control" step="0.01" min="0" placeholder="0.00">
                </div>
                <div class="form-group">
                    <label>&nbsp;</label>
                    <div style="height: 38px;"></div>
                </div>
            </div>
            
            <div style="margin-top: 24px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= Lang::get('common.save') ?></button>
                <button type="button" onclick="document.getElementById('addModal').style.display='none'" class="btn btn-secondary"><?= Lang::get('common.cancel') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function editItem(item) {
    document.getElementById('modalTitle').textContent = '<?= Lang::get('common.edit') ?>';
    document.getElementById('itemId').value = item.id;
    document.getElementById('itemName').value = item.name;
    document.getElementById('itemQuantity').value = item.quantity;
    document.getElementById('itemMinQuantity').value = item.min_quantity;
    document.getElementById('itemUnit').value = item.unit;
    document.getElementById('itemSupplier').value = item.supplier || '';
    document.getElementById('addModal').style.display = 'block';
}
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
