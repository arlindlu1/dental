<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('inventory.add', 'Add Item');
$breadcrumb = lang('inventory.add', 'Add Item');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $name = sanitize($_POST['name']);
    $category = sanitize($_POST['category']);
    $quantity = (int)$_POST['quantity'];
    $unit = sanitize($_POST['unit']);
    $minStock = (int)$_POST['min_stock'];
    $price = (float)$_POST['price'];
    $supplier = sanitize($_POST['supplier'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    
    $stmt = $db->prepare("INSERT INTO inventory (clinic_id, name, category, quantity, unit, min_stock, price, supplier, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issisidssi", $clinicId, $name, $category, $quantity, $unit, $minStock, $price, $supplier, $notes, $userId);
    
    if ($stmt->execute()) {
        Auth::logActivity('create_inventory', 'inventory', $db->lastInsertId(), "Added inventory item: $name");
        redirect('/views/inventory/index.php');
    } else {
        $error = 'Failed to create inventory item';
    }
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('inventory.add', 'Add Item') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('inventory.name', 'Item Name') ?> *</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.category', 'Category') ?> *</label>
                    <select name="category" class="form-control" required>
                        <option value="">Select category</option>
                        <option value="materials">Materials</option>
                        <option value="equipment">Equipment</option>
                        <option value="medications">Medications</option>
                        <option value="supplies">Supplies</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.quantity', 'Quantity') ?> *</label>
                    <input type="number" name="quantity" class="form-control" min="0" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.unit', 'Unit') ?> *</label>
                    <select name="unit" class="form-control" required>
                        <option value="">Select unit</option>
                        <option value="pcs">Pieces</option>
                        <option value="box">Box</option>
                        <option value="bottle">Bottle</option>
                        <option value="pack">Pack</option>
                        <option value="kg">Kilogram</option>
                        <option value="liter">Liter</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.min_stock', 'Minimum Stock') ?> *</label>
                    <input type="number" name="min_stock" class="form-control" min="0" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.price', 'Unit Price') ?> *</label>
                    <input type="number" name="price" class="form-control" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('inventory.supplier', 'Supplier') ?></label>
                    <input type="text" name="supplier" class="form-control">
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px;">
                <label><?= lang('inventory.notes', 'Notes') ?></label>
                <textarea name="notes" class="form-control" rows="3"></textarea>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/inventory/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
