<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('treatments.title', 'Treatments');
$breadcrumb = lang('treatments.title', 'Treatments');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        redirect('/views/treatments/index.php?error=csrf');
        exit;
    }

    $treatmentId = (int)$_POST['treatment_id'];
    $stmt = $db->prepare("DELETE FROM treatments WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("ii", $treatmentId, $clinicId);
    $stmt->execute();
    redirect('/views/treatments/index.php?success=deleted');
}

$patientId = $_GET['patient_id'] ?? null;

$sql = "SELECT t.*, p.first_name, p.last_name, u.name as doctor_name 
        FROM treatments t 
        JOIN patients p ON t.patient_id = p.id 
        JOIN users u ON t.doctor_id = u.id 
        WHERE t.clinic_id = ?";

$params = [$clinicId];
$types = "i";

if ($patientId) {
    $sql .= " AND t.patient_id = ?";
    $params[] = (int)$patientId;
    $types .= "i";
}

$sql .= " ORDER BY t.date DESC, t.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->bind_param($types, ...$params);
$treatments = safe_stmt_fetch_all($stmt);

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('treatments.title', 'Treatments') ?></h2>
        <div class="table-actions">
            <a href="/views/treatments/create.php<?= $patientId ? '?patient_id=' . $patientId : '' ?>" class="btn btn-primary">+ <?= lang('treatments.add', 'Add Treatment') ?></a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success" style="margin: 20px 24px;">
            <?= $_GET['success'] === 'deleted' ? 'Treatment deleted successfully!' : 'Action completed successfully!' ?>
        </div>
    <?php endif; ?>
    
    <table>
        <thead>
            <tr>
                <th><?= lang('treatments.date', 'Date') ?></th>
                <th><?= lang('treatments.patient', 'Patient') ?></th>
                <th><?= lang('treatments.doctor', 'Doctor') ?></th>
                <th><?= lang('treatments.procedure', 'Procedure') ?></th>
                <th><?= lang('treatments.tooth', 'Tooth') ?></th>
                <th><?= lang('treatments.price', 'Price') ?></th>
                <th><?= lang('common.actions') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($treatments)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <?= lang('common.no_data') ?>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($treatments as $treatment): ?>
                    <tr>
                        <td><?= formatDate($treatment['date']) ?></td>
                        <td><?= htmlspecialchars($treatment['first_name'] . ' ' . $treatment['last_name']) ?></td>
                        <td>Dr. <?= htmlspecialchars($treatment['doctor_name']) ?></td>
                        <td><?= htmlspecialchars($treatment['procedure']) ?></td>
                        <td><?= htmlspecialchars($treatment['tooth_number'] ?? '-') ?></td>
                        <td><strong><?= formatMoney($treatment['price']) ?></strong></td>
                        <td>
                            <div style="display: flex; gap: 12px; align-items: center;">
                                <a href="/views/treatments/view.php?id=<?= $treatment['id'] ?>" class="btn-link"><?= lang('common.view') ?></a>
                                <!-- Added delete button -->
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this treatment?')">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="treatment_id" value="<?= $treatment['id'] ?>">
                                    <button type="submit" class="btn-link" style="color: var(--danger); background: none; border: none; cursor: pointer; padding: 0; font: inherit;">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
