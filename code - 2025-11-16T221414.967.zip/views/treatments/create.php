<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$pageTitle = lang('treatments.add', 'Add Treatment');
$breadcrumb = lang('treatments.add', 'Add Treatment');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$userId = $_SESSION['user_id'];

$preselectedPatientId = $_GET['patient_id'] ?? null;

$stmt = $db->prepare("SELECT id, first_name, last_name FROM patients WHERE clinic_id = ? ORDER BY first_name");
$stmt->bind_param("i", $clinicId);
$patients = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT id, name FROM users WHERE clinic_id = ? AND role IN ('doctor', 'admin') ORDER BY name");
$stmt->bind_param("i", $clinicId);
$doctors = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT id, name_sq, name_en, price, duration FROM procedures WHERE clinic_id IS NULL OR clinic_id = ? ORDER BY name_" . Lang::current());
$stmt->bind_param("i", $clinicId);
$procedures = safe_stmt_fetch_all($stmt);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $patientId = (int)$_POST['patient_id'];
    $doctorId = (int)$_POST['doctor_id'];
    $date = $_POST['date'];
    $procedure = sanitize($_POST['procedure']);
    $toothNumber = sanitize($_POST['tooth_number'] ?? '');
    $price = (float)$_POST['price'];
    $notes = sanitize($_POST['notes'] ?? '');
    
    $stmt = $db->prepare("INSERT INTO treatments (clinic_id, patient_id, doctor_id, date, procedure, tooth_number, price, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisssds", $clinicId, $patientId, $doctorId, $date, $procedure, $toothNumber, $price, $notes);
    
    if ($stmt->execute()) {
        $treatmentId = $db->lastInsertId();
        Auth::logActivity('create_treatment', 'treatment', $treatmentId, "Created treatment for patient ID: $patientId");
        
        if ($toothNumber) {
            $stmt = $db->prepare("INSERT INTO patient_tooth_records (patient_id, clinic_id, tooth_number, status, notes, doctor_id, date) VALUES (?, ?, ?, 'filling', ?, ?, ?) ON DUPLICATE KEY UPDATE status = 'filling', notes = ?, date = ?");
            $stmt->bind_param("iississ", $patientId, $clinicId, $toothNumber, $procedure, $doctorId, $date, $procedure, $date);
            $stmt->execute();
        }
        
        redirect('/views/treatments/index.php');
    } else {
        $error = 'Failed to create treatment';
    }
}

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('treatments.add', 'Add Treatment') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= lang('treatments.patient', 'Patient') ?> *</label>
                    <select name="patient_id" class="form-control" required>
                        <option value="">Select patient</option>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?= $patient['id'] ?>" <?= $preselectedPatientId == $patient['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('treatments.doctor', 'Doctor') ?> *</label>
                    <select name="doctor_id" class="form-control" required>
                        <option value="">Select doctor</option>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= $doctor['id'] ?>" <?= $doctor['id'] == $userId ? 'selected' : '' ?>>
                                Dr. <?= htmlspecialchars($doctor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('treatments.date', 'Date') ?> *</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= lang('treatments.procedure', 'Procedure') ?> *</label>
                    <select name="procedure" class="form-control" required onchange="updatePrice(this)">
                        <option value="">Select procedure</option>
                        <?php foreach ($procedures as $proc): ?>
                            <option value="<?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?>" data-price="<?= $proc['price'] ?>">
                                <?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?> - <?= formatMoney($proc['price']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?= lang('treatments.tooth', 'Tooth Number') ?></label>
                    <input type="text" name="tooth_number" class="form-control" placeholder="e.g., 11, 21, 36">
                </div>
                
                <div class="form-group">
                    <label><?= lang('treatments.price', 'Price') ?> *</label>
                    <input type="number" name="price" id="price" class="form-control" step="0.01" min="0" required>
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 20px;">
                <label><?= lang('treatments.notes', 'Notes') ?></label>
                <textarea name="notes" class="form-control" rows="4"></textarea>
            </div>
            
            <div style="margin-top: 32px; display: flex; gap: 12px;">
                <button type="submit" class="btn btn-primary"><?= lang('common.save') ?></button>
                <a href="/views/treatments/index.php" class="btn btn-secondary"><?= lang('common.cancel') ?></a>
            </div>
        </form>
    </div>
</div>

<script>
function updatePrice(select) {
    const selectedOption = select.options[select.selectedIndex];
    const price = selectedOption.getAttribute('data-price');
    if (price) {
        document.getElementById('price').value = price;
    }
}
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
