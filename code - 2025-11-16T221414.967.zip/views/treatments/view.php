<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$lang = new Lang();
$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];

$treatmentId = (int)($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT t.*, p.first_name, p.last_name, u.name as doctor_name FROM treatments t JOIN patients p ON t.patient_id = p.id JOIN users u ON t.doctor_id = u.id WHERE t.id = ? AND t.clinic_id = ?");
$stmt->bind_param("ii", $treatmentId, $clinicId);
$treatment = safe_stmt_fetch_assoc($stmt);

if (!$treatment) {
    redirect('/views/treatments/index.php');
}

$pageTitle = lang('treatments.view', 'Treatment Details');
$breadcrumb = lang('treatments.view', 'Treatment Details');

include __DIR__ . '/../layout/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><?= lang('treatments.view', 'Treatment Details') ?></h2>
    </div>
    
    <div style="padding: 32px;">
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px;">
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Patient</div>
                <div style="font-weight: 500;"><?= htmlspecialchars($treatment['first_name'] . ' ' . $treatment['last_name']) ?></div>
            </div>
            
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Doctor</div>
                <div style="font-weight: 500;">Dr. <?= htmlspecialchars($treatment['doctor_name']) ?></div>
            </div>
            
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Date</div>
                <div style="font-weight: 500;"><?= formatDate($treatment['date']) ?></div>
            </div>
            
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Procedure</div>
                <div style="font-weight: 500;"><?= htmlspecialchars($treatment['procedure']) ?></div>
            </div>
            
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Tooth Number</div>
                <div style="font-weight: 500;"><?= htmlspecialchars($treatment['tooth_number'] ?? '-') ?></div>
            </div>
            
            <div>
                <div style="color: #6b7280; font-size: 14px; margin-bottom: 4px;">Price</div>
                <div style="font-weight: 500; font-size: 18px; color: #10b981;"><?= formatMoney($treatment['price']) ?></div>
            </div>
        </div>
        
        <?php if ($treatment['notes']): ?>
        <div style="margin-top: 32px;">
            <div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;">Notes</div>
            <div style="background: #f9fafb; padding: 16px; border-radius: 8px; line-height: 1.6;">
                <?= nl2br(htmlspecialchars($treatment['notes'])) ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 32px;">
            <a href="/views/treatments/index.php" class="btn btn-secondary"><?= lang('common.back', 'Back') ?></a>
            <a href="/views/patients/view.php?id=<?= $treatment['patient_id'] ?>" class="btn btn-primary">View Patient</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
