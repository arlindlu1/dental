<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

$user = Auth::user();
$clinicId = (int)($_SESSION['clinic_id'] ?? 0);
if ($clinicId <= 0) {
    redirect('/login.php');
}
$db = Database::getInstance();

$stmt = $db->prepare("SELECT * FROM clinics WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $clinicId);
$clinic = safe_stmt_fetch_assoc($stmt);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid CSRF token.';
    } else {
        // Basic sanitization + length limits
        $business_number = substr(sanitize($_POST['business_number'] ?? ''), 0, 128);
        $contact_person = substr(sanitize($_POST['contact_person'] ?? ''), 0, 128);
        $contact_phone = substr(sanitize($_POST['contact_phone'] ?? ''), 0, 64);
        $address = substr(sanitize($_POST['address'] ?? ''), 0, 1000);
        $city = substr(sanitize($_POST['city'] ?? ''), 0, 128);
        $postal_code = substr(sanitize($_POST['postal_code'] ?? ''), 0, 64);
        $opening_hours = substr(sanitize($_POST['opening_hours'] ?? ''), 0, 1000);

        // Handle logo upload
        $logoPath = $clinic['logo'] ?? null;
        if (!empty($_FILES['logo']) && !empty($_FILES['logo']['name'])) {
            $upload = uploadFile($_FILES['logo'], 'clinics');
            if ($upload === false) {
                $errors[] = 'Logo upload failed.';
            } else {
                $logoPath = $upload;
            }
        }

        if (empty($errors)) {
            $stmt2 = $db->prepare("UPDATE clinics SET business_number = ?, contact_person = ?, contact_phone = ?, address = ?, city = ?, postal_code = ?, opening_hours = ?, logo = ? WHERE id = ?");
            $stmt2->bind_param("ssssssssi", $business_number, $contact_person, $contact_phone, $address, $city, $postal_code, $opening_hours, $logoPath, $clinicId);
            $stmt2->execute();
            Auth::logActivity('update_clinic_info', 'clinic', $clinicId, json_encode(['by_user' => $user['id']]));
            redirect('/views/clinic_settings.php?success=1');
        }
    }
}

include __DIR__ . '/layout/header.php';
?>
<div class="container" style="max-width:900px; margin:32px auto;">
    <div class="card">
        <h1><?= lang('settings.clinic_info', 'Clinic Information') ?></h1>
        <?php if (!empty($_GET['success'])): ?><div class="alert alert-success">Saved.</div><?php endif; ?>
        <?php if (!empty($errors)): ?><div class="alert alert-error"><?php foreach($errors as $e) echo '<div>'.htmlspecialchars($e).'</div>'; ?></div><?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <div class="form-group">
                <label>Clinic Name</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($clinic['name'] ?? '') ?>" disabled>
            </div>
            <div class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div class="form-group">
                    <label><?= lang('onboarding.business_number', 'Business Number') ?></label>
                    <input type="text" name="business_number" class="form-control" value="<?= htmlspecialchars($clinic['business_number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label><?= lang('onboarding.contact_person', 'Contact Person') ?></label>
                    <input type="text" name="contact_person" class="form-control" value="<?= htmlspecialchars($clinic['contact_person'] ?? '') ?>">
                </div>
            </div>
            <div class="form-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:12px;">
                <div class="form-group">
                    <label><?= lang('onboarding.contact_phone', 'Contact Phone') ?></label>
                    <input type="text" name="contact_phone" class="form-control" value="<?= htmlspecialchars($clinic['contact_phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" value="<?= htmlspecialchars($clinic['email'] ?? '') ?>" disabled>
                </div>
            </div>
            <div class="form-group" style="margin-top:12px;">
                <label>Address</label>
                <textarea name="address" class="form-control" rows="3"><?= htmlspecialchars($clinic['address'] ?? '') ?></textarea>
            </div>
            <div style="display:flex; gap:12px; align-items:center; margin-top:12px;">
                <?php if (!empty($clinic['logo'])): ?><img src="<?= htmlspecialchars($clinic['logo']) ?>" style="max-width:140px; border-radius:8px; border:1px solid #e5e7eb;" /><?php endif; ?>
                <div>
                    <input type="file" name="logo" accept="image/*">
                </div>
            </div>
            <div style="margin-top:18px; display:flex; gap:12px;">
                <button class="btn btn-primary" type="submit"><?= lang('common.save', 'Save') ?></button>
                <a href="/views/dashboard.php" class="btn btn-secondary">Back to dashboard</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/layout/footer.php'; ?>
