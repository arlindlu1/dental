</div>
        </div>
    </div>
    
    <footer class="footer">
        <div style="font-size: 14px; color: var(--gray-600);">
            © <?= date('Y') ?> <?= htmlspecialchars($clinic['name']) ?>. All rights reserved.
        </div>
        <div style="margin-top: 8px; font-size: 14px;">
            Made with <span style="color: var(--danger); font-size: 16px;">❤️</span> by 
            <a href="https://devsyx.com" target="_blank" style="color: var(--primary); text-decoration: none; font-weight: 700; transition: all var(--transition-fast);" onmouseover="this.style.color='var(--primary-dark)'" onmouseout="this.style.color='var(--primary)'">
                devsyx.com
            </a>
        </div>
    </footer>
    
    <script src="<?= asset('js/app.js') ?>"></script>
    <?php if (isset($extraScripts)): ?>
        <?= $extraScripts ?>
    <?php endif; ?>
</body>
</html>
