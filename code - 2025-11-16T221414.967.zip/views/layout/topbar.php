<header style="background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); border-bottom: 1px solid var(--gray-200); padding: 16px 32px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; box-shadow: var(--shadow-sm);">
<?php
// Ensure $user is defined to avoid runtime errors when rendering the topbar
if (!isset($user) || !$user) {
    $user = ['name' => '', 'role' => 'user'];
}
?>
    <div style="display: flex; align-items: center; gap: 24px;">
        <button onclick="toggleSidebar()" style="display: none; background: var(--gray-100); border: none; padding: 10px 14px; border-radius: var(--radius-md); cursor: pointer; font-size: 18px; transition: all var(--transition-base);" onmouseover="this.style.background='var(--gray-200)'" onmouseout="this.style.background='var(--gray-100)'">
            ☰
        </button>
        <div style="font-size: 14px; color: var(--gray-600); font-weight: 500;">
            <?= $breadcrumb ?? lang('menu.dashboard') ?>
        </div>
    </div>
    
    <div style="display: flex; align-items: center; gap: 20px;">
        <div style="font-size: 13px; color: var(--gray-600); font-weight: 500; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 16px;">📅</span>
            <?= date('l, d F Y') ?>
        </div>
        
        <div style="display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: var(--radius-md);">
            <a href="?lang=sq" style="padding: 6px 12px; border-radius: var(--radius-sm); text-decoration: none; font-weight: 600; font-size: 12px; transition: all var(--transition-fast); <?= Lang::current() === 'sq' ? 'background: var(--primary); color: white;' : 'color: var(--gray-600);' ?>">SQ</a>
            <a href="?lang=en" style="padding: 6px 12px; border-radius: var(--radius-sm); text-decoration: none; font-weight: 600; font-size: 12px; transition: all var(--transition-fast); <?= Lang::current() === 'en' ? 'background: var(--primary); color: white;' : 'color: var(--gray-600);' ?>">EN</a>
        </div>
        
        <div style="position: relative;">
            <button onclick="toggleUserMenu()" style="display: flex; align-items: center; gap: 12px; background: var(--white); border: 2px solid var(--gray-200); padding: 8px 16px; border-radius: var(--radius-full); cursor: pointer; transition: all var(--transition-base); font-weight: 600; font-size: 14px; color: var(--gray-700);" onmouseover="this.style.borderColor='var(--primary)'; this.style.boxShadow='0 0 0 4px var(--primary-light)'" onmouseout="this.style.borderColor='var(--gray-200)'; this.style.boxShadow='none'">
                <div style="width: 36px; height: 36px; border-radius: 50%; background: var(--primary-gradient); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 14px;">
                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                </div>
                <span><?= htmlspecialchars(explode(' ', $user['name'])[0]) ?></span>
                <span style="font-size: 12px;">▼</span>
            </button>
            
            <div id="userMenu" style="display: none; position: absolute; top: calc(100% + 8px); right: 0; background: white; border-radius: var(--radius-lg); box-shadow: var(--shadow-xl); min-width: 220px; overflow: hidden; border: 1px solid var(--gray-200); z-index: 100;">
                <div style="padding: 16px; border-bottom: 1px solid var(--gray-100); background: var(--gray-50);">
                    <div style="font-weight: 700; color: var(--gray-900); margin-bottom: 2px;"><?= htmlspecialchars($user['name']) ?></div>
                    <div style="font-size: 12px; color: var(--gray-600); text-transform: uppercase; letter-spacing: 0.05em;"><?= ucfirst($user['role']) ?></div>
                </div>
                <a href="/views/settings/profile.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; text-decoration: none; color: var(--gray-700); font-weight: 500; transition: all var(--transition-fast);" onmouseover="this.style.background='var(--primary-light)'; this.style.color='var(--primary-dark)'" onmouseout="this.style.background='transparent'; this.style.color='var(--gray-700)'">
                    <span style="font-size: 18px;">👤</span>
                    <span><?= lang('settings.profile', 'Profile') ?></span>
                </a>
                <a href="/logout.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; text-decoration: none; color: var(--danger); font-weight: 500; transition: all var(--transition-fast); border-top: 1px solid var(--gray-100);" onmouseover="this.style.background='#fee2e2'" onmouseout="this.style.background='transparent'">
                    <span style="font-size: 18px;">🚪</span>
                    <span><?= lang('auth.logout') ?></span>
                </a>
            </div>
        </div>
    </div>
</header>

<script>
function toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
}

// Close user menu when clicking outside
document.addEventListener('click', function(event) {
    const menu = document.getElementById('userMenu');
    const button = event.target.closest('button[onclick="toggleUserMenu()"]');
    if (!button && !menu.contains(event.target)) {
        menu.style.display = 'none';
    }
});
</script>
