<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Helpers.php';
require_once __DIR__ . '/../../lib/Lang.php';

// Language switch from query param (applies site-wide)
if (isset($_GET['lang']) && in_array($_GET['lang'], ['sq', 'en'])) {
    $_SESSION['lang'] = $_GET['lang'];
    // Redirect to the same page without query string to apply language immediately
    $redirect = strtok($_SERVER['REQUEST_URI'], '?');
    header('Location: ' . $redirect);
    exit;
}

Auth::requireLogin();

$user = Auth::user();
$clinic = Auth::clinic();
?>
<!DOCTYPE html>
<html lang="<?php echo Lang::current(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Dashboard'; ?> - dentisti.pro</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/sidebar.php'; ?>
        
        <div class="main-content">
            <?php include __DIR__ . '/topbar.php'; ?>
            
            <div class="content-wrapper">
