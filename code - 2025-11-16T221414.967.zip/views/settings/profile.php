<?php
$require_config = __DIR__ . '/../../config/config.php';
if (file_exists($require_config)) {
    require_once $require_config;
} else {
    // Fallback: try relative include
    require_once __DIR__ . '/../../../config/config.php';
}

require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Helpers.php';
require_once __DIR__ . '/../../lib/Language.php';

Auth::requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$clinicId = $_SESSION['clinic_id'];
$lang = Language::getInstance();

// Get user info (scoped to clinic)
$stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND clinic_id = ?");
$stmt->bind_param("ii", $userId, $clinicId);
$stmt->execute();
$user = safe_stmt_fetch_assoc($stmt);

if (!$user) {
    $error = $lang->get('user_not_found') ?: 'User not found';
    include __DIR__ . '/../layout/header.php';
    echo '<div class="alert alert-error">' . htmlspecialchars($error) . '</div>';
    include __DIR__ . '/../layout/footer.php';
    exit;
}

// Get clinic info
$stmt = $db->prepare("SELECT c.*, p.name_en as plan_name, p.max_users, p.max_patients 
                      FROM clinics c 
                      LEFT JOIN plans p ON c.plan_id = p.id 
                      WHERE c.id = ?");
$stmt->bind_param("i", $clinicId);
$stmt->execute();
$clinic = safe_stmt_fetch_assoc($stmt);

if (!$clinic) {
    $error = $lang->get('clinic_not_found') ?: 'Clinic not found';
    include __DIR__ . '/../layout/header.php';
    echo '<div class="alert alert-error">' . htmlspecialchars($error) . '</div>';
    include __DIR__ . '/../layout/footer.php';
    exit;
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        $error = $lang->get('invalid_request') ?: 'Invalid request';
    } else {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']) ?: null;
        
        $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ? AND clinic_id = ?");
        $stmt->bind_param("sssii", $name, $email, $phone, $userId, $clinicId);
        
        if ($stmt->execute()) {
            $success = $lang->get('profile_updated_successfully');
            // Refresh user data (scoped)
            $stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND clinic_id = ?");
            $stmt->bind_param("ii", $userId, $clinicId);
            $user = safe_stmt_fetch_assoc($stmt);
        } else {
            $error = $lang->get('error_updating_profile');
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        $error = $lang->get('invalid_request') ?: 'Invalid request';
    } else {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        if ($newPassword !== $confirmPassword) {
            $error = $lang->get('passwords_do_not_match');
        } elseif (strlen($newPassword) < 6) {
            $error = $lang->get('password_too_short');
        } else {
            // Verify current password
            if (password_verify($currentPassword, $user['password'])) {
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ? AND clinic_id = ?");
                $stmt->bind_param("sii", $hashedPassword, $userId, $clinicId);
                
                if ($stmt->execute()) {
                    $success = $lang->get('password_changed_successfully');
                } else {
                    $error = $lang->get('error_changing_password');
                }
            } else {
                $error = $lang->get('current_password_incorrect');
            }
        }
    }
}

$pageTitle = $lang->get('my_profile');
include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><?php echo $lang->get('my_profile'); ?></h1>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if (isset($error)): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
<?php endif; ?>

<div class="grid-2">
    <!-- Profile Information -->
    <div class="card">
        <div class="card-header">
            <h2><?php echo $lang->get('profile_information'); ?></h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <!-- Using single 'name' field instead of first_name/last_name -->
                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                <div class="form-group">
                    <label><?php echo $lang->get('name', 'Name'); ?></label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?php echo $lang->get('email'); ?></label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?php echo $lang->get('phone'); ?></label>
                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                </div>
                
                <button type="submit" name="update_profile" class="btn btn-primary">
                    <?php echo $lang->get('update_profile'); ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Change Password -->
    <div class="card">
        <div class="card-header">
            <h2><?php echo $lang->get('change_password'); ?></h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                <div class="form-group">
                    <label><?php echo $lang->get('current_password'); ?></label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?php echo $lang->get('new_password'); ?></label>
                    <input type="password" name="new_password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label><?php echo $lang->get('confirm_password'); ?></label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                
                <button type="submit" name="change_password" class="btn btn-primary">
                    <?php echo $lang->get('change_password'); ?>
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Subscription Information -->
<div class="card" style="margin-top: 24px;">
    <div class="card-header">
        <h2><?php echo $lang->get('subscription_information'); ?></h2>
    </div>
    <div class="card-body">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label"><?php echo $lang->get('current_plan'); ?></div>
                <div class="stat-value"><?php echo htmlspecialchars($clinic['plan_name']); ?></div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label"><?php echo $lang->get('subscription_status'); ?></div>
                <div class="stat-value">
                    <?php echo getStatusBadge($clinic['subscription_status'] ?? 'active'); ?>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label"><?php echo $lang->get('plan_limits'); ?></div>
                <div class="stat-value" style="font-size: 14px;">
                    <?php echo $clinic['max_users']; ?> <?php echo $lang->get('users'); ?> / 
                    <?php echo $clinic['max_patients']; ?> <?php echo $lang->get('patients'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
