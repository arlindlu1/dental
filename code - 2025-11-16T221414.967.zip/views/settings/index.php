<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Lang.php';
require_once __DIR__ . '/../../lib/Helpers.php';

if (!Auth::check()) {
    redirect('/login.php');
}

if (!Auth::hasRole('admin')) {
    redirect('/views/dashboard.php');
}

$pageTitle = Lang::get('settings.title');
$breadcrumb = Lang::get('settings.title');

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$clinic = Auth::clinic();

$stmt = $db->prepare("SELECT p.* FROM plans p JOIN clinics c ON c.plan_id = p.id WHERE c.id = ?");
$stmt->bind_param("i", $clinicId);
$plan = safe_stmt_fetch_assoc($stmt);

$stmt = $db->prepare("SELECT COUNT(*) as user_count FROM users WHERE clinic_id = ?");
$stmt->bind_param("i", $clinicId);
$row = safe_stmt_fetch_assoc($stmt);
$userCount = $row['user_count'] ?? 0;

$success = '';
$error = '';

// Handle clinic info update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_clinic'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $name = sanitize($_POST['name']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $taxId = sanitize($_POST['tax_id'] ?? '');
    
    $stmt = $db->prepare("UPDATE clinics SET name = ?, phone = ?, email = ?, address = ?, tax_id = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $name, $phone, $email, $address, $taxId, $clinicId);
    
    if ($stmt->execute()) {
        $success = 'Clinic information updated successfully';
        $clinic = Auth::clinic(); // Refresh
    } else {
        $error = 'Failed to update clinic information';
    }
}

// Handle add procedure
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_procedure'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $nameSq = sanitize($_POST['name_sq']);
    $nameEn = sanitize($_POST['name_en']);
    $code = sanitize($_POST['code'] ?? '');
    $price = (float)$_POST['price'];
    $duration = (int)($_POST['duration'] ?? 30);
    
    // Check if code column exists, if not run migration
    $result = $db->query("SHOW COLUMNS FROM procedures LIKE 'code'");
    if ($result->num_rows == 0) {
        $db->query("ALTER TABLE procedures ADD COLUMN code VARCHAR(50) NULL AFTER name_en");
    }
    
    $stmt = $db->prepare("INSERT INTO procedures (clinic_id, name_sq, name_en, code, price, duration) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssdi", $clinicId, $nameSq, $nameEn, $code, $price, $duration);
    
    if ($stmt->execute()) {
        redirect('/views/settings/index.php?success=procedure_added');
    } else {
        $error = 'Failed to add procedure: ' . $stmt->error;
    }
}

// Handle edit procedure
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_procedure'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $procedureId = (int)$_POST['procedure_id'];
    $nameSq = sanitize($_POST['name_sq']);
    $nameEn = sanitize($_POST['name_en']);
    $code = sanitize($_POST['code'] ?? '');
    $price = (float)$_POST['price'];
    $duration = (int)($_POST['duration'] ?? 30);
    
    $stmt = $db->prepare("UPDATE procedures SET name_sq = ?, name_en = ?, code = ?, price = ?, duration = ? WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("sssdiii", $nameSq, $nameEn, $code, $price, $duration, $procedureId, $clinicId);
    
    if ($stmt->execute()) {
        redirect('/views/settings/index.php?success=procedure_updated');
    }
}

// Handle delete procedure
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_procedure'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $procedureId = (int)$_POST['delete_procedure'];
    
    $stmt = $db->prepare("DELETE FROM procedures WHERE id = ? AND clinic_id = ?");
    $stmt->bind_param("ii", $procedureId, $clinicId);
    
    if ($stmt->execute()) {
        redirect('/views/settings/index.php?success=procedure_deleted');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    // Check if clinic can add more users based on plan
    if ($userCount >= $plan['max_users']) {
        $error = 'You have reached the maximum number of users for your plan. Please upgrade to add more users.';
    } else {
        $name = sanitize($_POST['name']);
        $email = sanitize($_POST['email']);
        $role = sanitize($_POST['role']);
        $phone = sanitize($_POST['phone'] ?? '');
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        // Check if email already exists
        $checkStmt = $db->prepare("SELECT id FROM users WHERE email = ? AND clinic_id = ?");
        $checkStmt->bind_param("si", $email, $clinicId);
        $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) {
            $error = 'This email is already registered in your clinic';
        } else {
            $stmt = $db->prepare("INSERT INTO users (clinic_id, email, password, name, role, phone, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmt->bind_param("isssss", $clinicId, $email, $password, $name, $role, $phone);
            
            if ($stmt->execute()) {
                redirect('/views/settings/index.php?success=user_added');
            } else {
                $error = 'Failed to add user';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    if (!isset($_POST['csrf_token']) || !Auth::verifyCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    $userId = (int)$_POST['delete_user'];
    
    // Don't allow deleting yourself
    if ($userId === $_SESSION['user_id']) {
        $error = 'You cannot delete your own account';
    } else {
        $stmt = $db->prepare("DELETE FROM users WHERE id = ? AND clinic_id = ?");
        $stmt->bind_param("ii", $userId, $clinicId);
        
        if ($stmt->execute()) {
            redirect('/views/settings/index.php?success=user_deleted');
        }
    }
}

$stmt = $db->prepare("SELECT * FROM users WHERE clinic_id = ? ORDER BY name");
$stmt->bind_param("i", $clinicId);
$users = safe_stmt_fetch_all($stmt);

$stmt = $db->prepare("SELECT * FROM procedures WHERE clinic_id = ? ORDER BY name_sq");
$stmt->bind_param("i", $clinicId);
$procedures = safe_stmt_fetch_all($stmt);

include __DIR__ . '/../layout/header.php';
?>

<div class="dashboard-grid" style="grid-template-columns: 1fr;">
    <?php if ($success || isset($_GET['success'])): ?>
        <div style="padding: 12px; background: #c6f6d5; color: #2f855a; border-radius: 8px; margin-bottom: 20px;">
            <?php 
            if (isset($_GET['success'])) {
                if ($_GET['success'] === 'user_added') echo 'User added successfully';
                elseif ($_GET['success'] === 'user_deleted') echo 'User deleted successfully';
                elseif ($_GET['success'] === 'procedure_added') echo 'Procedure added successfully';
                elseif ($_GET['success'] === 'procedure_updated') echo 'Procedure updated successfully';
                elseif ($_GET['success'] === 'procedure_deleted') echo 'Procedure deleted successfully';
            } else {
                echo $success;
            }
            ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div style="padding: 12px; background: #fed7d7; color: #c53030; border-radius: 8px; margin-bottom: 20px;">
            <?= $error ?>
        </div>
    <?php endif; ?>
    
    <!-- Clinic Information -->
    <div class="dashboard-section">
        <div class="section-header">
            <h2><?= Lang::get('settings.clinic_info') ?></h2>
        </div>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="update_clinic" value="1">
            
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <div class="form-group">
                    <label><?= Lang::get('patients.first_name', 'Clinic Name') ?> *</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($clinic['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label><?= Lang::get('patients.phone') ?></label>
                    <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($clinic['phone'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label><?= Lang::get('patients.email') ?></label>
                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($clinic['email'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label>Tax ID</label>
                    <input type="text" name="tax_id" class="form-control" value="<?= htmlspecialchars($clinic['tax_id'] ?? '') ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label><?= Lang::get('patients.address') ?></label>
                <textarea name="address" class="form-control"><?= htmlspecialchars($clinic['address'] ?? '') ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary"><?= Lang::get('common.save') ?></button>
        </form>
    </div>
    
    <!-- Users -->
    <div class="dashboard-section">
        <div class="section-header">
            <div>
                <h2><?= Lang::get('settings.users') ?></h2>
                <p style="color: #6b7280; font-size: 14px; margin-top: 4px;">
                    <?= $userCount ?> / <?= $plan['max_users'] ?> users 
                    <?php if ($plan['max_users'] == 999): ?>
                        (Unlimited)
                    <?php endif; ?>
                </p>
            </div>
            <?php if ($userCount < $plan['max_users']): ?>
                <button onclick="openModal('addUserModal')" class="btn btn-primary">Add User</button>
            <?php else: ?>
                <button class="btn btn-secondary" disabled title="Upgrade your plan to add more users">
                    Upgrade Plan to Add More
                </button>
            <?php endif; ?>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?= htmlspecialchars($u['name']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><span class="badge badge-info"><?= ucfirst($u['role']) ?></span></td>
                        <td><?= htmlspecialchars($u['phone'] ?? '-') ?></td>
                        <td><?= getStatusBadge($u['is_active'] ? 'active' : 'inactive') ?></td>
                        <td><?= $u['last_login'] ? timeAgo($u['last_login']) : '-' ?></td>
                        <td>
                            <?php if ($u['id'] !== $_SESSION['user_id']): ?>
                                <form method="post" style="display: inline;" onsubmit="return confirm('Delete this user?')">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="delete_user" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn-link" style="color: #ef4444;">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Procedures -->
    <div class="dashboard-section">
        <div class="section-header">
            <h2>Procedures & Pricing</h2>
            <button onclick="openModal('addProcedureModal')" class="btn btn-primary">Add Procedure</button>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Procedure Name</th>
                    <th>Code</th>
                    <th>Price</th>
                    <th>Duration (min)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($procedures)): ?>
                    <tr><td colspan="5" style="text-align: center; padding: 40px; color: #6b7280;">No procedures added yet</td></tr>
                <?php else: ?>
                    <?php foreach ($procedures as $proc): ?>
                        <tr>
                            <!-- Display bilingual names -->
                            <td><?= htmlspecialchars(Lang::current() === 'sq' ? $proc['name_sq'] : $proc['name_en']) ?></td>
                            <td><?= htmlspecialchars($proc['code'] ?? '-') ?></td>
                            <td><?= formatMoney($proc['price']) ?></td>
                            <td><?= $proc['duration'] ?? '-' ?></td>
                            <td>
                                <button onclick="editProcedure(<?= $proc['id'] ?>, '<?= htmlspecialchars($proc['name_sq']) ?>', '<?= htmlspecialchars($proc['name_en']) ?>', '<?= htmlspecialchars($proc['code'] ?? '') ?>', <?= $proc['price'] ?>, <?= $proc['duration'] ?? 0 ?>)" class="btn-link">Edit</button>
                                <form method="post" style="display: inline;" onsubmit="return confirm('Delete this procedure?')">
                                    <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                    <input type="hidden" name="delete_procedure" value="<?= $proc['id'] ?>">
                                    <button type="submit" class="btn-link" style="color: #ef4444;">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Procedure Modal -->
<div id="addProcedureModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('addProcedureModal')">&times;</span>
        <h2>Add Procedure</h2>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="add_procedure" value="1">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Name (Albanian) *</label>
                    <input type="text" name="name_sq" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Name (English) *</label>
                    <input type="text" name="name_en" class="form-control" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>Procedure Code</label>
                <input type="text" name="code" class="form-control" placeholder="e.g., D0120">
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Price *</label>
                    <input type="number" name="price" class="form-control" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>Duration (minutes)</label>
                    <input type="number" name="duration" class="form-control" value="30">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Add Procedure</button>
        </form>
    </div>
</div>

<!-- Edit Procedure Modal -->
<div id="editProcedureModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('editProcedureModal')">&times;</span>
        <h2>Edit Procedure</h2>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="edit_procedure" value="1">
            <input type="hidden" name="procedure_id" id="edit_procedure_id">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Name (Albanian) *</label>
                    <input type="text" name="name_sq" id="edit_name_sq" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Name (English) *</label>
                    <input type="text" name="name_en" id="edit_name_en" class="form-control" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>Procedure Code</label>
                <input type="text" name="code" id="edit_code" class="form-control">
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Price *</label>
                    <input type="number" name="price" id="edit_price" class="form-control" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>Duration (minutes)</label>
                    <input type="number" name="duration" id="edit_duration" class="form-control">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Update Procedure</button>
        </form>
    </div>
</div>

<!-- Add User Modal -->
<div id="addUserModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('addUserModal')">&times;</span>
        <h2>Add New User</h2>
        
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <input type="hidden" name="add_user" value="1">
            
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" name="phone" class="form-control">
            </div>
            
            <div class="form-group">
                <label>Role *</label>
                <select name="role" class="form-control" required>
                    <option value="reception">Reception</option>
                    <option value="doctor">Doctor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Password *</label>
                <input type="password" name="password" class="form-control" required minlength="6">
                <small style="color: #6b7280;">Minimum 6 characters</small>
            </div>
            
            <button type="submit" class="btn btn-primary">Add User</button>
        </form>
    </div>
</div>

<script>
function editProcedure(id, nameSq, nameEn, code, price, duration) {
    document.getElementById('edit_procedure_id').value = id;
    document.getElementById('edit_name_sq').value = nameSq;
    document.getElementById('edit_name_en').value = nameEn;
    document.getElementById('edit_code').value = code;
    document.getElementById('edit_price').value = price;
    document.getElementById('edit_duration').value = duration;
    openModal('editProcedureModal');
}

function openModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
