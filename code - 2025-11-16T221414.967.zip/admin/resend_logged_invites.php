<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/../lib/Mailer.php';
require_once __DIR__ . '/_admin_guard.php';

if (!Auth::checkAdmin()) redirect('/admin/login.php');

$logFile = __DIR__ . '/../storage/logs/invites.log';
$lines = [];
// safe read with shared lock
if (file_exists($logFile)) {
    $fp = @fopen($logFile, 'r');
    if ($fp) {
        if (flock($fp, LOCK_SH)) {
            $contents = stream_get_contents($fp);
            flock($fp, LOCK_UN);
            $lines = array_filter(explode("\n", $contents));
        }
        fclose($fp);
    }
}

$results = [];
$maxProcess = 200; // safety: limit lines processed in one run
$csrf = Auth::generateCSRFToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!Auth::verifyCSRFToken($token)) {
        http_response_code(400);
        die('Invalid CSRF token');
    }

    // re-read file under lock to ensure current contents
    $lines = [];
    if (file_exists($logFile)) {
        $fp = @fopen($logFile, 'r');
        if ($fp) {
            if (flock($fp, LOCK_SH)) {
                $contents = stream_get_contents($fp);
                flock($fp, LOCK_UN);
                $lines = array_filter(explode("\n", $contents));
            }
            fclose($fp);
        }
    }

    $toAppend = [];
    $processed = 0;
    foreach ($lines as $ln) {
        if ($processed >= $maxProcess) break;
        if (strpos($ln, 'sent=1') !== false) continue; // skip already-sent
        // parse for email and invite_url
        preg_match('/email=([^ ]+)/', $ln, $memail);
        preg_match('/invite_url=([^ ]+)/', $ln, $murl);
        $email = $memail[1] ?? null;
        $inviteUrl = $murl[1] ?? null;
        if (!$email || !$inviteUrl) continue;
        $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
        $inviteUrl = filter_var(trim($inviteUrl), FILTER_SANITIZE_URL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) continue;

        $sent = false;
        try {
            $sent = Mailer::sendInvite($email, $inviteUrl, '');
        } catch (Throwable $e) {
            $sent = false;
        }

        $results[] = [$email, $inviteUrl, $sent];
        $entry = date('c') . " - resent email=" . $email . " invite_url=" . $inviteUrl . " sent=" . ($sent ? '1' : '0') . "\n";
        $toAppend[] = $entry;

        if (!$sent) {
            enqueue_email(['type' => 'invite', 'to' => $email, 'invite_url' => $inviteUrl, 'clinic_name' => '']);
        }

        $processed++;
    }

    if (!empty($toAppend)) {
        $fp = @fopen($logFile, 'a');
        if ($fp) {
            if (flock($fp, LOCK_EX)) {
                foreach ($toAppend as $ent) {
                    fwrite($fp, $ent);
                }
                fflush($fp);
                flock($fp, LOCK_UN);
            }
            fclose($fp);
        }
    }
}

include __DIR__ . '/layout/sidebar.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Resend Logged Invites - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
<div class="app-container">
    <div class="main-content">
        <header class="topbar"><h1>Resend Logged Invites</h1></header>
        <div class="content-wrapper">
            <p>This will attempt to resend any invites recorded in <code><?= htmlspecialchars('storage/logs/invites.log') ?></code> that were not marked as sent. The run will process up to <?= $maxProcess ?> entries to avoid long blocking operations.</p>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                <button class="btn btn-primary" type="submit">Attempt Resend</button>
            </form>
            <?php if (!empty($results)): ?>
                <div style="margin-top:12px;">
                    <h3>Results (showing processed entries)</h3>
                    <ul>
                        <?php foreach ($results as $r): ?>
                            <li><?= htmlspecialchars($r[0]) ?> - <?= $r[2] ? 'Sent' : 'Queued/Failed' ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div style="margin-top:12px;"><a class="btn btn-secondary" href="/admin/invites.php">Back to Invites</a></div>
        </div>
    </div>
</div>
</body>
</html>
