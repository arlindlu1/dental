<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$admin = Auth::admin();
$db = Database::getInstance();

// Get platform statistics
// Use safe query helpers to avoid runtime errors when DB returns false
$totalClinics = safe_query_count($db, "SELECT COUNT(*) as count FROM clinics");
$activeClinics = safe_query_count($db, "SELECT COUNT(*) as count FROM clinics WHERE status = 'active'");
$totalUsers = safe_query_count($db, "SELECT COUNT(*) as count FROM users");
$totalPatients = safe_query_count($db, "SELECT COUNT(*) as count FROM patients");

// Get recent clinics with prepared statements
$stmt = $db->prepare("SELECT c.*, p.name as plan_name FROM clinics c JOIN plans p ON c.plan_id = p.id ORDER BY c.created_at DESC LIMIT 10");
$recentClinics = safe_stmt_fetch_all($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* Small, focused dashboard UI improvements */
        .topbar { display:flex; justify-content:space-between; align-items:center; gap:16px; padding:20px 24px; background:#fff; border-bottom:1px solid #eef2f7; }
        .topbar h1 { margin:0; font-size:20px; color:#111827; }
        .topbar-subtitle { margin:0; color:#6b7280; font-size:13px }
        .user-menu { display:flex; align-items:center; gap:12px }
        .user-avatar { background:#4f46e5; color:#fff; width:40px; height:40px; display:flex; align-items:center; justify-content:center; border-radius:8px; font-weight:700 }
        .content-wrapper { padding:24px }
        .stats-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:16px }
        .stat-card { display:flex; gap:12px; align-items:center; background:linear-gradient(180deg, #ffffff 0%, #fbfbff 100%); padding:16px; border-radius:12px; box-shadow:0 1px 2px rgba(16,24,40,0.04); border:1px solid #eef2f7 }
        .stat-icon { width:56px; height:56px; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#fff; flex-shrink:0 }
        .stat-label { color:#6b7280; font-size:13px }
        .stat-value { font-size:20px; font-weight:700; color:#111827 }
        .stat-change { font-size:12px; color:#10b981 }
        .card { background:#fff; border:1px solid #eef2f7; border-radius:12px; padding:16px }
        .card-header { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:12px }
        .table-container table { width:100%; border-collapse:collapse }
        .table-container th, .table-container td { padding:10px 12px; text-align:left; border-bottom:1px solid #f3f4f6 }
        .badge-info { background:#eef2ff; color:#3730a3; padding:6px 10px; border-radius:999px; font-weight:600; font-size:12px }
        .quick-actions { display:flex; gap:8px; flex-wrap:wrap }
        .btn-quick { background:#6366f1; color:#fff; padding:8px 12px; border-radius:8px; text-decoration:none; font-size:13px }
        @media (max-width:700px) { .topbar { flex-direction:column; align-items:flex-start } .card-header { flex-direction:column; align-items:flex-start } }
    </style>
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1><?= lang('admin.platform') ?></h1>
                    <p class="topbar-subtitle"><?= lang('admin.subtitle') ?></p>
                </div>
                <div class="topbar-right">
                    <div class="quick-actions">
                        <a href="/admin/clinics.php?action=create" class="btn-quick"><?= lang('admin.new_clinic') ?></a>
                        <a href="/admin/plans.php" class="btn-quick" style="background:#06b6d4"><?= lang('menu.plans') ?? 'Plans' ?></a>
                        <a href="/admin/reports.php" class="btn-quick" style="background:#10b981"><?= lang('menu.reports') ?? 'Reports' ?></a>
                    </div>
                    <div style="display:flex; align-items:center; gap:8px; margin-left:12px;">
                        <a href="?lang=sq" style="padding:6px 10px; border-radius:8px; text-decoration:none; font-weight:700; font-size:12px; <?= Lang::current() === 'sq' ? 'background:#111827;color:#fff;' : 'background:transparent;color:#374151;' ?>">SQ</a>
                        <a href="?lang=en" style="padding:6px 10px; border-radius:8px; text-decoration:none; font-weight:700; font-size:12px; <?= Lang::current() === 'en' ? 'background:#111827;color:#fff;' : 'background:transparent;color:#374151;' ?>">EN</a>
                    </div>
                    <div style="width:16px"></div>
                    <div class="user-menu">
                        <div class="user-avatar"><?= strtoupper(substr($admin['name'], 0, 1)) ?></div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($admin['name']) ?></div>
                            <div class="user-role"><?= lang('admin.super_admin') ?></div>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content-wrapper">
                <div class="stats-grid" aria-live="polite">
                    <div class="stat-card" role="region" aria-label="Total Clinics">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Clinics</div>
                            <div class="stat-value"><?= $totalClinics ?></div>
                            <div class="stat-change positive">+12% from last month</div>
                        </div>
                    </div>
                    
                    <div class="stat-card" role="region" aria-label="Active Clinics">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Active Clinics</div>
                            <div class="stat-value"><?= $activeClinics ?></div>
                            <div class="stat-change positive">+8% from last month</div>
                        </div>
                    </div>
                    
                    <div class="stat-card" role="region" aria-label="Total Users">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Users</div>
                            <div class="stat-value"><?= $totalUsers ?></div>
                            <div class="stat-change positive">+15% from last month</div>
                        </div>
                    </div>
                    
                    <div class="stat-card" role="region" aria-label="Total Patients">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Patients</div>
                            <div class="stat-value"><?= $totalPatients ?></div>
                            <div class="stat-change positive">+23% from last month</div>
                        </div>
                    </div>
                </div>
                
                <div class="card" style="margin-top: 32px;">
                    <div class="card-header">
                        <h2>Recent Clinics</h2>
                        <a href="/admin/clinics.php" class="btn btn-primary">View All Clinics</a>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Clinic Name</th>
                                    <th>Owner Email</th>
                                    <th>Plan</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentClinics as $clinic): ?>
                                    <tr>
                                        <td><strong><?= htmlspecialchars($clinic['name']) ?></strong></td>
                                        <td><?= htmlspecialchars($clinic['owner_email']) ?></td>
                                        <td><span class="badge badge-info"><?= htmlspecialchars($clinic['plan_name']) ?></span></td>
                                        <td><?= getStatusBadge($clinic['status']) ?></td>
                                        <td><?= formatDate($clinic['created_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer style="text-align: center; padding: 20px; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 40px;">
        <?= sprintf(lang('admin.made_by'), '<a href="https://devsyx.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">devsyx.com</a>') ?>
    </footer>
    
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
