<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Language.php';
require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();
$db = Database::getInstance();
$lang = Language::getInstance();

// Get all clinics with subscription info
$stmt = $db->prepare("SELECT c.*, p.name_en as plan_name, p.price as plan_price,
                    COUNT(DISTINCT u.id) as user_count,
                    COUNT(DISTINCT pt.id) as patient_count
                    FROM clinics c
                    LEFT JOIN plans p ON c.plan_id = p.id
                    LEFT JOIN users u ON c.id = u.clinic_id
                    LEFT JOIN patients pt ON c.id = pt.clinic_id
                    GROUP BY c.id
                    ORDER BY c.created_at DESC");
$clinics = safe_stmt_fetch_all($stmt);

// Get all plans
$stmt2 = $db->prepare("SELECT * FROM plans ORDER BY price ASC");
$plans = safe_stmt_fetch_all($stmt2);

// Handle plan change
// Handle plan change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_plan'])) {
    // Verify CSRF token
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        header("Location: subscriptions.php?error=csrf");
        exit;
    }

    $clinicId = (int)($_POST['clinic_id'] ?? 0);
    $newPlanId = (int)($_POST['plan_id'] ?? 0);
    
    $stmt = $db->prepare("UPDATE clinics SET plan_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $newPlanId, $clinicId);
    
    if ($stmt->execute()) {
        Auth::logActivity('change_plan', 'clinic', $clinicId, json_encode(['new_plan_id' => $newPlanId]));
        $success = "Plan updated successfully";
        header("Location: subscriptions.php?success=1");
        exit;
    }
}

$pageTitle = 'Subscription Management';
include __DIR__ . '/layout/header.php';
include __DIR__ . '/layout/sidebar.php';
?>

<div class="main-content">
    <div class="page-header">
        <h1>Subscription Management</h1>
        <p class="text-gray-600">Manage clinic subscriptions and plans</p>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">Plan updated successfully</div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Clinic Name</th>
                            <th>Current Plan</th>
                            <th>Status</th>
                            <th>Users</th>
                            <th>Patients</th>
                            <th>Subscription End</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clinics as $clinic): ?>
                            <tr>
                                <td>
                                    <div class="font-medium"><?php echo htmlspecialchars($clinic['name']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($clinic['email']); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-primary">
                                        <?php echo htmlspecialchars($clinic['plan_name']); ?>
                                    </span>
                                    <div class="text-sm text-gray-500">$<?php echo number_format($clinic['plan_price'], 2); ?>/mo</div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $clinic['subscription_status'] === 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($clinic['subscription_status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $clinic['user_count']; ?></td>
                                <td><?php echo $clinic['patient_count']; ?></td>
                                <td><?php echo $clinic['subscription_end_date'] ? date('M d, Y', strtotime($clinic['subscription_end_date'])) : 'N/A'; ?></td>
                                <td>
                                    <button onclick="openChangePlanModal(<?php echo $clinic['id']; ?>, <?php echo $clinic['plan_id']; ?>)" 
                                            class="btn btn-sm btn-primary">
                                        Change Plan
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Change Plan Modal -->
<div id="changePlanModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Change Subscription Plan</h2>
            <button onclick="closeModal('changePlanModal')" class="close-btn">&times;</button>
        </div>
        <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
            <div class="modal-body">
                <input type="hidden" name="clinic_id" id="modal_clinic_id">
                
                <div class="form-group">
                    <label>Select New Plan</label>
                    <select name="plan_id" id="modal_plan_id" class="form-control" required>
                        <?php foreach ($plans as $plan): ?>
                            <option value="<?php echo $plan['id']; ?>">
                                <?php echo htmlspecialchars($plan['name_en']); ?> - 
                                $<?php echo number_format($plan['price'], 2); ?>/mo
                                (<?php echo $plan['max_users']; ?> users, <?php echo $plan['max_patients']; ?> patients)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('changePlanModal')" class="btn btn-secondary">Cancel</button>
                    <button type="submit" name="change_plan" class="btn btn-primary">Update Plan</button>
            </div>
        </form>
    </div>
</div>

<script>
function openChangePlanModal(clinicId, currentPlanId) {
    document.getElementById('modal_clinic_id').value = clinicId;
    document.getElementById('modal_plan_id').value = currentPlanId;
    document.getElementById('changePlanModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}
</script>

<?php include __DIR__ . '/layout/footer.php'; ?>
