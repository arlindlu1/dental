<?php
/**
 * Admin guard: capture fatal errors and uncaught exceptions and log them.
 * Include this at the top of admin entry pages (after loading config).
 */

// Register shutdown handler to catch fatal errors
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
        $msg = sprintf("[%s] Fatal Error: %s in %s on line %d\n", date('c'), $err['message'], $err['file'], $err['line']);
        @file_put_contents(__DIR__ . '/../storage/logs/errors.log', $msg, FILE_APPEND | LOCK_EX);
        error_log($msg);
        if (defined('APP_ENV') && APP_ENV === 'production') {
            http_response_code(500);
            echo 'An internal server error occurred.';
        } else {
            echo '<pre>' . htmlspecialchars($msg) . '</pre>';
        }
        exit;
    }
});

set_exception_handler(function ($e) {
    $msg = sprintf("[%s] Uncaught Exception: %s in %s on line %d\nStack trace:\n%s\n", date('c'), $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString());
    @file_put_contents(__DIR__ . '/../storage/logs/errors.log', $msg, FILE_APPEND | LOCK_EX);
    error_log($msg);
    if (defined('APP_ENV') && APP_ENV === 'production') {
        http_response_code(500);
        echo 'An internal server error occurred.';
    } else {
        echo '<pre>' . htmlspecialchars($msg) . '</pre>';
    }
    exit;
});

// Ensure sessions are started for admin pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
