<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/_admin_guard.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

$admin = Auth::admin();
Auth::requireAdmin();
$db = Database::getInstance();

// Date range filter
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-t');
// CSRF token for export form
$csrfToken = Auth::generateCSRFToken();

// Platform Statistics
$totalClinics = safe_query_count($db, "SELECT COUNT(*) as count FROM clinics");
$activeClinics = safe_query_count($db, "SELECT COUNT(*) as count FROM clinics WHERE status = 'active'");
$totalUsers = safe_query_count($db, "SELECT COUNT(*) as count FROM users");
$totalPatients = safe_query_count($db, "SELECT COUNT(*) as count FROM patients");

// Revenue by Clinic
$stmt = $db->prepare("SELECT 
    c.name as clinic_name,
    COUNT(DISTINCT i.id) as invoices,
    COALESCE(SUM(i.total), 0) as revenue,
    COALESCE(SUM(i.paid_amount), 0) as collected
FROM clinics c
LEFT JOIN invoices i ON c.id = i.clinic_id AND i.date BETWEEN ? AND ?
WHERE c.status = 'active'
GROUP BY c.id, c.name
ORDER BY revenue DESC
LIMIT 10");
$stmt->bind_param("ss", $startDate, $endDate);
$clinicRevenue = safe_stmt_fetch_all($stmt);

// Growth Metrics
$stmt = $db->prepare("SELECT 
    DATE_FORMAT(created_at, '%Y-%m') as month,
    COUNT(*) as new_clinics
FROM clinics 
WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
GROUP BY DATE_FORMAT(created_at, '%Y-%m')
ORDER BY month");
$clinicGrowth = safe_stmt_fetch_all($stmt);

// Plan Distribution
 $stmt = $db->prepare("SELECT 
    p.name as plan_name,
    COUNT(c.id) as clinic_count
FROM plans p
LEFT JOIN clinics c ON p.id = c.plan_id
GROUP BY p.id, p.name
ORDER BY clinic_count DESC");
 $planStats = safe_stmt_fetch_all($stmt);

// PDF Export handler for selected date range (POSTed for security)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_pdf'])) {
    // Verify CSRF
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        redirect('/admin/reports.php?start_date=' . urlencode($startDate) . '&end_date=' . urlencode($endDate) . '&error=csrf');
        exit;
    }

    // If vendor/autoload is not available, redirect back with error
    if (!defined('HAS_VENDOR') || !HAS_VENDOR) {
        redirect('/admin/reports.php?start_date=' . urlencode($startDate) . '&end_date=' . urlencode($endDate) . '&error=pdf_unavailable');
    }

    // Validate dates
    $s = trim($_POST['start_date'] ?? $startDate);
    $e = trim($_POST['end_date'] ?? $endDate);
    $sDate = DateTime::createFromFormat('Y-m-d', $s);
    $eDate = DateTime::createFromFormat('Y-m-d', $e);
    if (!$sDate || !$eDate) {
        redirect('/admin/reports.php?start_date=' . urlencode($startDate) . '&end_date=' . urlencode($endDate) . '&error=invalid_date');
        exit;
    }
    $startDate = $sDate->format('Y-m-d');
    $endDate = $eDate->format('Y-m-d');

    // Re-run queries for the requested date range to ensure accurate data
    $stmt = $db->prepare("SELECT 
        c.name as clinic_name,
        COUNT(DISTINCT i.id) as invoices,
        COALESCE(SUM(i.total), 0) as revenue,
        COALESCE(SUM(i.paid_amount), 0) as collected
    FROM clinics c
    LEFT JOIN invoices i ON c.id = i.clinic_id AND i.date BETWEEN ? AND ?
    WHERE c.status = 'active'
    GROUP BY c.id, c.name
    ORDER BY revenue DESC
    LIMIT 10");
    $stmt->bind_param("ss", $startDate, $endDate);
    $clinicRevenue = safe_stmt_fetch_all($stmt);

    // Invoice summary for the period
    $stmt = $db->prepare("SELECT 
        COUNT(*) as invoices_count,
        COALESCE(SUM(total), 0) as total_revenue,
        COALESCE(SUM(paid_amount), 0) as total_collected
    FROM invoices
    WHERE date BETWEEN ? AND ?");
    $stmt->bind_param("ss", $startDate, $endDate);
    $invSummaryRes = safe_stmt_fetch_all($stmt);
    $invSummary = !empty($invSummaryRes) ? $invSummaryRes[0] : ['invoices_count' => 0, 'total_revenue' => 0, 'total_collected' => 0];

    // Growth (last 6 months remains same, but keep for PDF)
    $stmt = $db->prepare("SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        COUNT(*) as new_clinics
    FROM clinics 
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month");
    $clinicGrowth = safe_stmt_fetch_all($stmt);

    // Plan distribution
    $stmt = $db->prepare("SELECT 
        p.name as plan_name,
        COUNT(c.id) as clinic_count
    FROM plans p
    LEFT JOIN clinics c ON p.id = c.plan_id
    GROUP BY p.id, p.name
    ORDER BY clinic_count DESC");
    $planStats = safe_stmt_fetch_all($stmt);

    // Build HTML for PDF with header/footer and summary
    $html = '<!doctype html><html><head><meta charset="utf-8"><style>';
    $html .= '@page { margin: 100px 50px; }';
    $html .= 'header { position: fixed; top: -80px; left: 0; right:0; height: 60px; text-align: center; }';
    $html .= 'footer { position: fixed; bottom: -60px; left: 0; right:0; height: 40px; font-size:12px; text-align:center; color: #666; }';
    $html .= 'table { border-collapse: collapse; width: 100%; }';
    $html .= 'th, td { border: 1px solid #ddd; padding: 8px; }';
    $html .= 'th { background: #f3f4f6; }';
    $html .= '</style></head><body>';
    $html .= '<header><div style="display:flex;align-items:center;justify-content:center;gap:12px;">';
    if (defined('APP_NAME')) {
        $html .= '<div style="font-weight:700;font-size:18px;">' . htmlspecialchars(APP_NAME) . ' - Platform Reports</div>';
    } else {
        $html .= '<div style="font-weight:700;font-size:18px;">Platform Reports</div>';
    }
    $html .= '</div></header>';
    $html .= '<footer>Generated on ' . date('Y-m-d H:i:s') . ' - Page {PAGE_NUM} of {PAGE_COUNT}</footer>';
    $html .= '<main><h2 style="font-family: Arial, Helvetica, sans-serif;">Overview</h2>';
    $html .= '<p>Period: ' . htmlspecialchars($startDate) . ' to ' . htmlspecialchars($endDate) . '</p>';

    // Invoices summary
    $html .= '<h3>Invoices Summary</h3>';
    $html .= '<table><tr><th>Total Invoices</th><th>Total Revenue</th><th>Total Collected</th></tr>';
    $html .= '<tr><td>' . htmlspecialchars($invSummary['invoices_count']) . '</td><td>' . htmlspecialchars(number_format($invSummary['total_revenue'], 2)) . '</td><td>' . htmlspecialchars(number_format($invSummary['total_collected'], 2)) . '</td></tr></table>';

    // Revenue table
    $html .= '<h2>Top Clinics by Revenue</h2>';
    $html .= '<table border="1" cellpadding="6" cellspacing="0" width="100%"><thead><tr><th>Clinic</th><th>Invoices</th><th>Revenue</th><th>Collected</th></tr></thead><tbody>';
    foreach ($clinicRevenue as $c) {
        $html .= '<tr>' .
            '<td>' . htmlspecialchars($c['clinic_name']) . '</td>' .
            '<td>' . htmlspecialchars($c['invoices']) . '</td>' .
            '<td>' . htmlspecialchars(number_format($c['revenue'], 2)) . '</td>' .
            '<td>' . htmlspecialchars(number_format($c['collected'], 2)) . '</td>' .
        '</tr>';
    }
    $html .= '</tbody></table>';

    // Growth
    $html .= '<h2 style="margin-top:18px;">Clinic Growth (Last 6 Months)</h2>';
    $html .= '<table border="1" cellpadding="6" cellspacing="0" width="100%"><thead><tr><th>Month</th><th>New Clinics</th></tr></thead><tbody>';
    foreach ($clinicGrowth as $m) {
        $html .= '<tr><td>' . htmlspecialchars($m['month']) . '</td><td>' . htmlspecialchars($m['new_clinics']) . '</td></tr>';
    }
    $html .= '</tbody></table>';

    // Plan distribution
    $html .= '<h3 style="margin-top:18px;">Plan Distribution</h3>';
    $html .= '<table><thead><tr><th>Plan</th><th>Clinic Count</th></tr></thead><tbody>';
    foreach ($planStats as $p) {
        $html .= '<tr><td>' . htmlspecialchars($p['plan_name']) . '</td><td>' . htmlspecialchars($p['clinic_count']) . '</td></tr>';
    }
    $html .= '</tbody></table>';

    $html .= '</main></body></html>';

    // Log export action for audit (if available)
    try {
        Auth::logActivity('export_reports', 'reports', null, json_encode([
            'start_date' => $startDate,
            'end_date' => $endDate,
            'admin_id' => $admin['id'] ?? null,
        ]));
    } catch (Exception $logEx) {
        // ignore logging failures
    }

    // Render PDF using Dompdf
    try {
        $dompdf = new \Dompdf\Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $filename = 'platform_reports_' . date('Ymd_His') . '.pdf';
        $dompdf->stream($filename, array('Attachment' => 1));
        exit;
    } catch (Exception $ex) {
        // fallback: redirect back with error
        redirect('/admin/reports.php?start_date=' . urlencode($startDate) . '&end_date=' . urlencode($endDate) . '&error=pdf_failed');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Platform Reports - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1>Platform Reports & Analytics</h1>
                    <p class="topbar-subtitle">Monitor platform performance and growth</p>
                </div>
                <div class="topbar-right">
                    <form method="GET" style="display: flex; gap: 12px; align-items: center;">
                        <input type="date" name="start_date" value="<?= htmlspecialchars($startDate) ?>" class="form-control" style="width: auto;">
                        <span>to</span>
                        <input type="date" name="end_date" value="<?= htmlspecialchars($endDate) ?>" class="form-control" style="width: auto;">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <form method="POST" style="display:inline; margin-left:6px;">
                            <input type="hidden" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
                            <input type="hidden" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <button type="submit" name="export_pdf" class="btn btn-secondary">Export PDF</button>
                        </form>
                    </form>
                </div>
            </header>
            
            <div class="content-wrapper">
                <!-- Platform Overview -->
                <div class="stats-grid" style="margin-bottom: 48px;">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">🏥</div>
                        <div class="stat-content">
                            <div class="stat-label">Total Clinics</div>
                            <div class="stat-value"><?= $totalClinics ?></div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">✅</div>
                        <div class="stat-content">
                            <div class="stat-label">Active Clinics</div>
                            <div class="stat-value"><?= $activeClinics ?></div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">👥</div>
                        <div class="stat-content">
                            <div class="stat-label">Total Users</div>
                            <div class="stat-value"><?= $totalUsers ?></div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">🦷</div>
                        <div class="stat-content">
                            <div class="stat-label">Total Patients</div>
                            <div class="stat-value"><?= $totalPatients ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Revenue by Clinic -->
                <div class="card" style="margin-bottom: 32px;">
                    <div class="card-header">
                        <h2>Top Clinics by Revenue</h2>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Clinic Name</th>
                                    <th>Invoices</th>
                                    <th>Total Revenue</th>
                                    <th>Collected</th>
                                    <th>Collection Rate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($clinicRevenue)): ?>
                                    <tr><td colspan="5" style="text-align: center; padding: 40px;">No data available</td></tr>
                                <?php else: ?>
                                    <?php foreach ($clinicRevenue as $clinic): ?>
                                        <tr>
                                            <td><strong><?= htmlspecialchars($clinic['clinic_name']) ?></strong></td>
                                            <td><?= $clinic['invoices'] ?></td>
                                            <td><?= formatMoney($clinic['revenue']) ?></td>
                                            <td><?= formatMoney($clinic['collected']) ?></td>
                                            <td>
                                                <span class="badge badge-success">
                                                    <?= $clinic['revenue'] > 0 ? round(($clinic['collected'] / $clinic['revenue']) * 100, 1) : 0 ?>%
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Growth Chart -->
                <div class="card" style="margin-bottom: 32px;">
                    <div class="card-header">
                        <h2>Clinic Growth (Last 6 Months)</h2>
                    </div>
                    <div style="padding: 32px;">
                        <div style="display: flex; align-items: flex-end; gap: 16px; height: 300px;">
                            <?php 
                            $maxGrowth = !empty($clinicGrowth) ? max(array_column($clinicGrowth, 'new_clinics')) : 1;
                            foreach ($clinicGrowth as $month): 
                                $height = ($month['new_clinics'] / $maxGrowth) * 100;
                            ?>
                                <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                                    <div style="width: 100%; background: linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%); border-radius: 8px 8px 0 0; height: <?= $height ?>%; min-height: 20px; display: flex; align-items: flex-start; justify-content: center; padding-top: 8px;">
                                        <span style="font-size: 12px; font-weight: 600; color: white;"><?= $month['new_clinics'] ?></span>
                                    </div>
                                    <div style="margin-top: 12px; font-size: 12px; color: #6b7280; font-weight: 500;">
                                        <?= date('M', strtotime($month['month'] . '-01')) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Plan Distribution -->
                <div class="card">
                    <div class="card-header">
                        <h2>Plan Distribution</h2>
                    </div>
                    <div style="padding: 32px;">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 24px;">
                            <?php foreach ($planStats as $plan): ?>
                                <div style="text-align: center; padding: 24px; background: #f9fafb; border-radius: 12px;">
                                    <div style="font-size: 36px; font-weight: 700; color: #0ea5e9; margin-bottom: 8px;">
                                        <?= $plan['clinic_count'] ?>
                                    </div>
                                    <div style="font-size: 14px; color: #6b7280; font-weight: 500;">
                                        <?= htmlspecialchars($plan['plan_name']) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Added devsyx.com branding footer -->
    <footer style="text-align: center; padding: 20px; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 40px;">
        Made with ❤️ by <a href="https://devsyx.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">devsyx.com</a>
    </footer>
    
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
