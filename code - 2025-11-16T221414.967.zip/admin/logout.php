<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/_admin_guard.php';
// Ensure only admin can access logout
Auth::requireAdmin();
unset($_SESSION['super_admin_id']);
unset($_SESSION['super_admin_name']);
session_destroy();
header('Location: /admin/login.php');
exit;
