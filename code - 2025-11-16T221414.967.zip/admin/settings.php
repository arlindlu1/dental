<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$admin = Auth::admin();
$db = Database::getInstance();

// Handle admin settings update (super-admin profile)
// NOTE: This updates the global super_admins table. Only accessible to authenticated admins via the admin guard.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        redirect('/admin/settings.php?error=csrf');
        exit;
    }

    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $name = sanitize($_POST['name']);
        $email = sanitize($_POST['email']);
        
        $stmt = $db->prepare("UPDATE super_admins SET name = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $email, $admin['id']);
        $stmt->execute();
        
        if (!empty($_POST['new_password'])) {
            if (strlen($_POST['new_password']) < 8) {
                redirect('/admin/settings.php?error=password_short');
                exit;
            }
            $hashedPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE super_admins SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $admin['id']);
            $stmt->execute();
        }
        
        redirect('/admin/settings.php?success=updated');
    }
}

// Refresh admin data
$admin = Auth::admin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1>Admin Settings</h1>
                    <p class="topbar-subtitle">Manage your admin account settings</p>
                </div>
                <div class="topbar-right">
                    <div class="user-menu">
                        <div class="user-avatar"><?= strtoupper(substr($admin['name'], 0, 1)) ?></div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($admin['name']) ?></div>
                            <div class="user-role">Super Admin</div>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content-wrapper">
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">Settings updated successfully!</div>
                <?php endif; ?>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-error">
                        <?php if ($_GET['error'] === 'password_short'): ?>
                            Password must be at least 8 characters long!
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <h2>Profile Settings</h2>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                        <input type="hidden" name="action" value="update_profile">
                        <div class="form-group">
                            <label>Full Name *</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($admin['name']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email Address *</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin['email']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current password">
                            <small class="form-text">Password must be at least 8 characters long</small>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                                <polyline points="7 3 7 8 15 8"></polyline>
                            </svg>
                            Save Changes
                        </button>
                    </form>
                </div>
                
                <div class="card">
                    <h2>Platform Information</h2>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                        <div style="padding: 20px; background: var(--gray-50); border-radius: 12px;">
                            <div style="font-size: 13px; color: var(--gray-600); margin-bottom: 8px;">Platform Version</div>
                            <div style="font-size: 20px; font-weight: 700; color: var(--gray-900);">v1.0.0</div>
                        </div>
                        <div style="padding: 20px; background: var(--gray-50); border-radius: 12px;">
                            <div style="font-size: 13px; color: var(--gray-600); margin-bottom: 8px;">PHP Version</div>
                            <div style="font-size: 20px; font-weight: 700; color: var(--gray-900);"><?= phpversion() ?></div>
                        </div>
                        <div style="padding: 20px; background: var(--gray-50); border-radius: 12px;">
                            <div style="font-size: 13px; color: var(--gray-600); margin-bottom: 8px;">Database</div>
                            <div style="font-size: 20px; font-weight: 700; color: var(--gray-900);">MySQL</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer style="text-align: center; padding: 20px; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 40px;">
        Made with ❤️ by <a href="https://devsyx.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">devsyx.com</a>
    </footer>
    
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
