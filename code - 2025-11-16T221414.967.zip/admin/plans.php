<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$admin = Auth::admin();
$db = Database::getInstance();

// Handle plan actions (admin-only)
// NOTE: This updates global product plans. Changes here affect all clinics; protected by admin guard above.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        redirect('/admin/plans.php?error=csrf');
        exit;
    }

    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'update') {
            // Validate and sanitize inputs
            $name = sanitize($_POST['name'] ?? '');
            $price_monthly = floatval($_POST['price_monthly'] ?? 0);
            $price_yearly = floatval($_POST['price_yearly'] ?? 0);
            $max_users = (int)($_POST['max_users'] ?? 0);
            $max_patients = (int)($_POST['max_patients'] ?? 0);
            $plan_id = (int)($_POST['plan_id'] ?? 0);

            $stmt = $db->prepare("UPDATE plans SET name = ?, price_monthly = ?, price_yearly = ?, max_users = ?, max_patients = ? WHERE id = ?");
            $stmt->bind_param("sddiii", $name, $price_monthly, $price_yearly, $max_users, $max_patients, $plan_id);
            $stmt->execute();
            Auth::logActivity('update_plan', 'plan', $plan_id, json_encode(['name' => $name]));
            redirect('/admin/plans.php?success=updated');
        }
    }
}

// Get all plans
$stmt = $db->prepare("SELECT * FROM plans ORDER BY price_monthly ASC");
$plans = safe_stmt_fetch_all($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Plans - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1>Subscription Plans</h1>
                    <p class="topbar-subtitle">Manage pricing and features for clinic subscriptions</p>
                </div>
                <div class="topbar-right">
                    <div class="user-menu">
                        <div class="user-avatar"><?= strtoupper(substr($admin['name'], 0, 1)) ?></div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($admin['name']) ?></div>
                            <div class="user-role">Super Admin</div>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content-wrapper">
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">Plan updated successfully!</div>
                <?php endif; ?>
                
                <div class="stats-grid">
                    <?php foreach ($plans as $plan): ?>
                        <div class="stat-card">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                                    <path d="M2 17l10 5 10-5"></path>
                                    <path d="M2 12l10 5 10-5"></path>
                                </svg>
                            </div>
                            <div class="stat-content">
                                <div class="stat-label"><?= htmlspecialchars($plan['name']) ?></div>
                                <div class="stat-value">$<?= number_format($plan['price_monthly'], 0) ?></div>
                                <div style="margin-top: 16px; font-size: 13px; color: var(--gray-600);">
                                    <div style="margin-bottom: 6px;"><strong>Max Users:</strong> <?= $plan['max_users'] ?></div>
                                    <div style="margin-bottom: 6px;"><strong>Max Patients:</strong> <?= $plan['max_patients'] ?></div>
                                    <div><strong>Yearly:</strong> $<?= number_format($plan['price_yearly'], 0) ?></div>
                                </div>
                                <button class="btn btn-secondary" style="margin-top: 20px; width: 100%;" onclick="editPlan(<?= htmlspecialchars(json_encode($plan)) ?>)">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                    Edit Plan
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Plan Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Plan</h2>
                <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
            </div>
            <form method="POST" id="editForm">
                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="plan_id" id="edit_plan_id">
                <div class="form-group">
                    <label>Plan Name *</label>
                    <input type="text" name="name" id="edit_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Monthly Price ($) *</label>
                    <input type="number" step="0.01" name="price_monthly" id="edit_price_monthly" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Yearly Price ($) *</label>
                    <input type="number" step="0.01" name="price_yearly" id="edit_price_yearly" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Max Users *</label>
                    <input type="number" name="max_users" id="edit_max_users" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Max Patients *</label>
                    <input type="number" name="max_patients" id="edit_max_patients" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Plan</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="<?= asset('js/app.js') ?>"></script>
    <script>
    function editPlan(plan) {
        document.getElementById('edit_plan_id').value = plan.id;
        document.getElementById('edit_name').value = plan.name;
        document.getElementById('edit_price_monthly').value = plan.price_monthly;
        document.getElementById('edit_price_yearly').value = plan.price_yearly;
        document.getElementById('edit_max_users').value = plan.max_users;
        document.getElementById('edit_max_patients').value = plan.max_patients;
        openModal('editModal');
    }
    </script>
    
    <!-- Added devsyx.com branding footer -->
    <footer style="text-align: center; padding: 20px; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 40px;">
        Made with ❤️ by <a href="https://devsyx.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">devsyx.com</a>
    </footer>
</body>
</html>
