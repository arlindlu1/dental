<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/../lib/Mailer.php';

require_once __DIR__ . '/_admin_guard.php';
// Enforce admin requirement for this page (redirects to admin login if missing)
Auth::requireAdmin();

$admin = Auth::admin();
$db = Database::getInstance();

// Handle clinic actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Verify CSRF token for all POST actions
        if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            redirect('/admin/clinics.php?error=csrf');
            exit;
        }

        if (isset($_POST['action'])) {
            if ($_POST['action'] === 'create') {
            $name = sanitize($_POST['name']);
            $email = sanitize($_POST['owner_email']);
            $planId = (int)($_POST['plan_id'] ?? 0);
            
            // Check if email already exists
            $checkStmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $checkStmt->bind_param("s", $email);
            $existing = safe_stmt_fetch_assoc($checkStmt);
            if ($existing) {
                redirect('/admin/clinics.php?error=email_exists');
                exit;
            }
            
            $stmt = $db->prepare("INSERT INTO clinics (name, slug, owner_email, plan_id, status, language) VALUES (?, ?, ?, ?, ?, ?)");
            $slug = strtolower(str_replace(' ', '-', $name));
            $status = 'trial';
            $lang = 'sq';
            $stmt->bind_param("sssiss", $name, $slug, $email, $planId, $status, $lang);
            $stmt->execute();

            $clinicId = $db->lastInsertId();

            // Create an owner user record for the clinic (inactive until invite accepted)
            $ownerName = '';
            if (strpos($email, '@') !== false) {
                $ownerName = ucfirst(explode('@', $email)[0]);
            } else {
                $ownerName = 'Owner';
            }
            // Default owner password (set even if invite email will be sent)
            $defaultPlain = 'admin123';
            $hashedPassword = password_hash($defaultPlain, PASSWORD_DEFAULT);
            $isActive = 1; // owner account created active by default with default password
            $stmtUser = $db->prepare("INSERT INTO users (clinic_id, email, password, name, role, is_active) VALUES (?, ?, ?, ?, 'admin', ?)");
            $stmtUser->bind_param("isssi", $clinicId, $email, $hashedPassword, $ownerName, $isActive);
            $stmtUser->execute();
            $ownerUserId = $db->lastInsertId();
            Auth::logActivity('create_clinic_owner', 'user', $ownerUserId, json_encode(['email' => $email, 'clinic_id' => $clinicId]));

            // No invite email: create the owner user with a default password and mark active.
            // Admins will communicate credentials to the clinic owner manually if desired.
            // NOTE: default password is `admin123` (hashed above when creating the user).

            // Log admin action (created clinic)
            Auth::logActivity('create_clinic', 'clinic', $clinicId, json_encode(['owner_email' => $email]));

            redirect('/admin/clinics.php?success=created');
        } elseif ($_POST['action'] === 'delete') {
            $clinicId = (int)($_POST['clinic_id'] ?? 0);
            $confirmName = trim((string)($_POST['confirm_name'] ?? ''));

            // Fetch clinic name for confirmation
            $check = $db->prepare("SELECT name FROM clinics WHERE id = ? LIMIT 1");
            $check->bind_param("i", $clinicId);
            $row = safe_stmt_fetch_assoc($check);
            $clinicName = $row['name'] ?? '';

            if ($confirmName === '' || $confirmName !== $clinicName) {
                // require exact clinic name typed to confirm deletion
                redirect('/admin/clinics.php?error=confirm_name_mismatch');
                exit;
            }

            $stmt = $db->prepare("DELETE FROM clinics WHERE id = ?");
            $stmt->bind_param("i", $clinicId);
            $stmt->execute();
            Auth::logActivity('delete_clinic', 'clinic', $clinicId, 'Deleted clinic and associated data');
            redirect('/admin/clinics.php?success=deleted');
        } elseif ($_POST['action'] === 'update_status') {
            $status = sanitize($_POST['status']);
            $clinicId = (int)($_POST['clinic_id'] ?? 0);
            $stmt = $db->prepare("UPDATE clinics SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $status, $clinicId);
            $stmt->execute();
            Auth::logActivity('update_clinic_status', 'clinic', $clinicId, $status);
            redirect('/admin/clinics.php?success=updated');
        } elseif ($_POST['action'] === 'change_plan') {
            $planId = (int)($_POST['plan_id'] ?? 0);
            $clinicId = (int)($_POST['clinic_id'] ?? 0);
            $stmt = $db->prepare("UPDATE clinics SET plan_id = ? WHERE id = ?");
            $stmt->bind_param("ii", $planId, $clinicId);
            $stmt->execute();
            Auth::logActivity('change_clinic_plan', 'clinic', $clinicId, json_encode(['new_plan_id' => $planId]));
            redirect('/admin/clinics.php?success=plan_updated');
        }
    }
    } catch (Exception $e) {
        // Log and redirect with an error rather than letting a 500 show
        $msg = sprintf("[%s] Clinics POST handler exception: %s in %s on line %d\nStack: %s\n", date('c'), $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString());
        @file_put_contents(__DIR__ . '/../storage/logs/errors.log', $msg, FILE_APPEND | LOCK_EX);
        redirect('/admin/clinics.php?error=server');
        exit;
    }
}

// Get all clinics with prepared statements
$stmt = $db->prepare("SELECT c.*, p.name as plan_name FROM clinics c JOIN plans p ON c.plan_id = p.id ORDER BY c.created_at DESC");
$clinics = safe_stmt_fetch_all($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Clinics - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1>Manage Clinics</h1>
                    <p class="topbar-subtitle">Create and manage dental clinic accounts</p>
                </div>
                <div class="topbar-right">
                    <button class="btn btn-primary" onclick="openModal('createModal')">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                            <line x1="12" y1="5" x2="12" y2="19"></line>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                        Add Clinic
                    </button>
                </div>
            </header>
            
            <div class="content-wrapper">
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">
                        <?php if ($_GET['success'] === 'created'): ?>
                                    Clinic created successfully!
                                                    <!-- Invite emails disabled: owner account is created with default password 'admin123' -->
                                <?php elseif ($_GET['success'] === 'updated'): ?>
                            Clinic status updated successfully!
                        <?php elseif ($_GET['success'] === 'deleted'): ?>
                            Clinic deleted successfully!
                        <?php elseif ($_GET['success'] === 'plan_updated'): ?>
                            Clinic plan updated successfully!
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-error">
                        <?php if ($_GET['error'] === 'email_exists'): ?>
                            This email is already registered!
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Clinic Name</th>
                                    <th>Owner Email</th>
                                    <th>Plan</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($clinics as $clinic): ?>
                                    <tr>
                                        <td><strong><?= htmlspecialchars($clinic['name']) ?></strong></td>
                                        <td><?= htmlspecialchars($clinic['owner_email']) ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                                            <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                                <input type="hidden" name="action" value="change_plan">
                                                <input type="hidden" name="clinic_id" value="<?= $clinic['id'] ?>">
                                                <select name="plan_id" onchange="this.form.submit()" class="form-select-inline">
                                                    <?php
                                                    $stmt_plans = $db->prepare("SELECT * FROM plans WHERE is_active = 1 ORDER BY price_monthly ASC");
                                                    $allPlans = safe_stmt_fetch_all($stmt_plans);
                                                    foreach ($allPlans as $p):
                                                    ?>
                                                        <option value="<?= $p['id'] ?>" <?= $clinic['plan_id'] == $p['id'] ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($p['name']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </form>
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="clinic_id" value="<?= $clinic['id'] ?>">
                                                <select name="status" onchange="this.form.submit()" class="form-select-inline">
                                                    <option value="active" <?= $clinic['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                                                    <option value="trial" <?= $clinic['status'] === 'trial' ? 'selected' : '' ?>>Trial</option>
                                                    <option value="suspended" <?= $clinic['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                                                </select>
                                            </form>
                                        </td>
                                        <td><?= formatDate($clinic['created_at']) ?></td>
                                        <td>
                                            <button class="btn-icon btn-danger" onclick="deleteClinic(<?= (int)$clinic['id'] ?>, <?= json_encode($clinic['name']) ?>)" title="Delete">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <polyline points="3 6 5 6 21 6"></polyline>
                                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Add footer with branding -->
            <footer style="text-align: center; padding: 20px; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 40px;">
                Made with ❤️ by <a href="https://devsyx.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">devsyx.com</a>
            </footer>
        </div>
    </div>
    
    <!-- Create Clinic Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Clinic</h2>
                <button class="modal-close" onclick="closeModal('createModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Clinic Name *</label>
                    <input type="text" name="name" class="form-control" required placeholder="Enter clinic name">
                </div>
                <div class="form-group">
                    <label>Owner Email *</label>
                    <input type="email" name="owner_email" class="form-control" required placeholder="owner@example.com">
                    <small class="form-text">This will be used for login. An invite link will be emailed to the owner (or shown once if email isn't configured).</small>
                </div>
                <div class="form-group">
                    <label>Subscription Plan *</label>
                    <select name="plan_id" class="form-control" required>
                        <option value="">Select a plan</option>
                        <?php
                        $stmt_plans2 = $db->prepare("SELECT * FROM plans WHERE is_active = 1 ORDER BY price_monthly ASC");
                        $plans = safe_stmt_fetch_all($stmt_plans2);
                        foreach ($plans as $plan):
                        ?>
                            <option value="<?= $plan['id'] ?>"><?= htmlspecialchars($plan['name']) ?> - $<?= $plan['price_monthly'] ?>/month</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Clinic</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="clinic_id" id="delete_clinic_id">
        <input type="hidden" name="confirm_name" id="delete_confirm_name">
    </form>
    
    <script src="<?= asset('js/app.js') ?>"></script>
    <script>
    function deleteClinic(id, name) {
        var promptMsg = 'To confirm deletion, type the clinic name exactly: "' + name + '"';
        var typed = prompt(promptMsg + '\n\nThis will permanently delete the clinic and all associated data.');
        if (typed === null) return; // cancelled
        if (typed.trim() !== name) {
            alert('Clinic name did not match. Deletion cancelled.');
            return;
        }
        document.getElementById('delete_clinic_id').value = id;
        document.getElementById('delete_confirm_name').value = typed.trim();
        document.getElementById('deleteForm').submit();
    }
    </script>
</body>
</html>
