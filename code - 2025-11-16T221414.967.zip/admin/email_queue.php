<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

// Manual resend via POST (CSRF-protected)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend_index'])) {
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        redirect('/admin/email_queue.php?error=csrf');
        exit;
    }

    $idx = (int)$_POST['resend_index'];
    $queue = read_email_queue();
    if (isset($queue[$idx])) {
        $item = $queue[$idx];
        $sent = false;
        try {
            if ($item['type'] === 'invite') {
                $sent = Mailer::sendInvite($item['to'] ?? '', $item['invite_url'] ?? '', $item['clinic_name'] ?? '');
            }
        } catch (Exception $e) {
            $sent = false;
        }
        if ($sent) {
            unset($queue[$idx]);
            write_email_queue(array_values($queue));
            $msg = 'Sent';
        } else {
            $queue[$idx]['attempts'] = ($queue[$idx]['attempts'] ?? 0) + 1;
            $queue[$idx]['last_attempt'] = date('c');
            write_email_queue(array_values($queue));
            $msg = 'Failed';
        }
        header('Location: /admin/email_queue.php?msg=' . urlencode($msg));
        exit;
    }
}

$queue = read_email_queue();
include __DIR__ . '/layout/sidebar.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Email Queue - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
<div class="app-container">
    <div class="main-content">
        <header class="topbar"><h1>Email Queue</h1></header>
        <div class="content-wrapper">
            <?php if (empty($queue)): ?>
                <div class="alert">Queue is empty.</div>
            <?php else: ?>
                <div class="card">
                    <table style="width:100%; font-family:monospace;">
                        <thead><tr><th>#</th><th>Type</th><th>To</th><th>Info</th><th>Attempts</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php foreach ($queue as $i => $it): ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= htmlspecialchars($it['type'] ?? '') ?></td>
                                <td><?= htmlspecialchars($it['to'] ?? '') ?></td>
                                <td><?= htmlspecialchars(json_encode($it)) ?></td>
                                <td><?= htmlspecialchars($it['attempts'] ?? 0) ?></td>
                                <td>
                                    <form method="POST" style="display:inline; margin:0;">
                                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                        <input type="hidden" name="resend_index" value="<?= $i ?>">
                                        <button type="submit" class="btn btn-sm">Resend</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            <div style="margin-top:12px;"><a class="btn btn-secondary" href="/admin/invites.php">Back to Invites</a></div>
        </div>
    </div>
</div>
</body>
</html>
