<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$logFile = __DIR__ . '/../storage/logs/invites.log';
$lines = [];
if (file_exists($logFile)) {
    $content = @file_get_contents($logFile);
    if ($content !== false) {
        $lines = array_filter(explode("\n", $content));
        $lines = array_reverse($lines);
    }
}

include __DIR__ . '/layout/sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Invite Log - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <div class="main-content">
            <header class="topbar">
                <h1>Invite Log</h1>
            </header>
            <div class="content-wrapper">
                <?php if (empty($lines)): ?>
                    <div class="alert">No invite logs found.</div>
                <?php else: ?>
                    <div class="card">
                        <div style="max-height:500px; overflow:auto; font-family:monospace; white-space:pre;">
                            <?php foreach ($lines as $ln): ?>
                                <?= htmlspecialchars($ln) ?>
                                <br/>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <div style="margin-top:16px;">
                    <a class="btn btn-secondary" href="/admin/invites.php">Back to Invites</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
