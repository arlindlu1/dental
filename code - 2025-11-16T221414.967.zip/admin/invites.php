<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';
require_once __DIR__ . '/../lib/Mailer.php';
require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        redirect('/admin/invites.php?error=csrf');
        exit;
    }

    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'revoke') {
            $id = (int)($_POST['invite_id'] ?? 0);
            // Fetch invite to ensure it exists and to retrieve clinic_id
            $check = $db->prepare("SELECT clinic_id FROM invites WHERE id = ? LIMIT 1");
            $check->bind_param("i", $id);
            $inviteRow = safe_stmt_fetch_assoc($check);
            if ($inviteRow) {
                $clinicId = (int)$inviteRow['clinic_id'];
                $stmt = $db->prepare("UPDATE invites SET used = 1 WHERE id = ? AND clinic_id = ?");
                $stmt->bind_param("ii", $id, $clinicId);
                $stmt->execute();
                Auth::logActivity('revoke_invite', 'invite', $id, 'Revoked invite');
            }
            redirect('/admin/invites.php?success=revoked');
        } elseif ($_POST['action'] === 'resend') {
            $id = (int)($_POST['invite_id'] ?? 0);
            // Regenerate token and extend expiry
            try {
                $newToken = bin2hex(random_bytes(16));
            } catch (Exception $e) {
                $newToken = bin2hex(openssl_random_pseudo_bytes(16));
            }
            $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
            // Fetch invite details first
            $stmt2 = $db->prepare("SELECT email, clinic_id FROM invites WHERE id = ? LIMIT 1");
            $stmt2->bind_param("i", $id);
            $invite = safe_stmt_fetch_assoc($stmt2);
            if ($invite) {
                $inviteClinicId = (int)($invite['clinic_id'] ?? 0);
                $stmt = $db->prepare("UPDATE invites SET token = ?, expires_at = ?, used = 0 WHERE id = ? AND clinic_id = ?");
                $stmt->bind_param("ssii", $newToken, $expiresAt, $id, $inviteClinicId);
                $stmt->execute();
            }
            if ($invite) {
                $inviteUrl = (rtrim(APP_URL, '/')) . '/invite.php?token=' . urlencode($newToken);
                $sent = false;
                try {
                    $sent = Mailer::sendInvite($invite['email'], $inviteUrl, '');
                } catch (Exception $e) {
                    $sent = false;
                }
                // Log invite to local file for manual retrieval if SMTP fails
                $inviteLog = __DIR__ . '/../storage/logs/invites.log';
                $logEntry = date('c') . " - invite_id={$id} clinic_id={$invite['clinic_id']} email=" . ($invite['email'] ?? '') . " invite_url={$inviteUrl} sent=" . ($sent ? '1' : '0') . "\n";
                @file_put_contents($inviteLog, $logEntry, FILE_APPEND | LOCK_EX);
                if (!$sent) {
                    enqueue_email([
                        'type' => 'invite',
                        'to' => $invite['email'] ?? '',
                        'invite_url' => $inviteUrl,
                        'clinic_id' => $invite['clinic_id'] ?? null,
                        'clinic_name' => '',
                    ]);
                }
            }

            Auth::logActivity('resend_invite', 'invite', $id, json_encode(['email' => $invite['email'] ?? '']));
            redirect('/admin/invites.php?success=resend');
        }
    }
}

$stmt = $db->prepare("SELECT i.*, c.name as clinic_name FROM invites i LEFT JOIN clinics c ON i.clinic_id = c.id ORDER BY i.created_at DESC");
$invites = safe_stmt_fetch_all($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invites - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        <div class="main-content">
            <header class="topbar">
                <h1>Invites</h1>
            </header>
            <div class="content-wrapper">
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">Action completed.</div>
                <?php endif; ?>
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-error">An error occurred.</div>
                <?php endif; ?>

                <div class="card">
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Email</th>
                                    <th>Clinic</th>
                                    <th>Expires</th>
                                    <th>Used</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($invites as $inv): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($inv['email']) ?></td>
                                        <td><?= htmlspecialchars($inv['clinic_name'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($inv['expires_at']) ?></td>
                                        <td><?= $inv['used'] ? 'Yes' : 'No' ?></td>
                                        <td><?= formatDate($inv['created_at']) ?></td>
                                        <td>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                                <input type="hidden" name="action" value="resend">
                                                <input type="hidden" name="invite_id" value="<?= $inv['id'] ?>">
                                                <button type="submit" class="btn btn-sm">Resend</button>
                                            </form>
                                            <form method="POST" style="display:inline; margin-left:6px;">
                                                <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                                                <input type="hidden" name="action" value="revoke">
                                                <input type="hidden" name="invite_id" value="<?= $inv['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Revoke this invite?')">Revoke</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
