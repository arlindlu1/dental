<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/Helpers.php';

require_once __DIR__ . '/_admin_guard.php';

Auth::requireAdmin();

$admin = Auth::admin();
$db = Database::getInstance();

// Handle content update (admin-only action)
// NOTE: This updates global landing page content and is intentionally a global write
// protected by the admin guard above. Keep CSRF verification in place.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_content') {
        if (!Auth::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            redirect('/admin/landing.php?error=csrf');
        }

        foreach ($_POST['content'] as $key => $values) {
            $stmt = $db->prepare("UPDATE landing_content SET value_sq = ?, value_en = ? WHERE `key` = ?");
            $stmt->bind_param("sss", $values['sq'], $values['en'], $key);
            $stmt->execute();
        }

        // Log admin activity
        Auth::logActivity('update_landing', 'landing_content', null, 'Updated landing page content');

        redirect('/admin/landing.php?success=updated');
    }
}

// Get landing content
$content = [];
$stmt = $db->prepare("SELECT * FROM landing_content");
$rows = safe_stmt_fetch_all($stmt);
foreach ($rows as $row) {
    $content[$row['key']] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page Content - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
    <div class="app-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <div class="main-content">
            <header class="topbar">
                <div class="topbar-left">
                    <h1>Landing Page Content</h1>
                </div>
            </header>
            
            <div class="content-wrapper">
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">Content updated successfully!</div>
                <?php endif; ?>
                
                <div class="card">
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= Auth::generateCSRFToken() ?>">
                        <input type="hidden" name="action" value="update_content">
                        
                        <?php foreach ($content as $key => $item): ?>
                            <div class="form-group" style="border-bottom: 1px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px;">
                                <h3 style="margin-bottom: 16px;"><?= ucwords(str_replace('_', ' ', $key)) ?></h3>
                                <div class="form-group">
                                    <label>Albanian (SQ)</label>
                                    <textarea name="content[<?= $key ?>][sq]" class="form-control" rows="2" required><?= htmlspecialchars($item['value_sq']) ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>English (EN)</label>
                                    <textarea name="content[<?= $key ?>][en]" class="form-control" rows="2" required><?= htmlspecialchars($item['value_en']) ?></textarea>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <button type="submit" class="btn btn-primary">Update Content</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
