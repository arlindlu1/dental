<aside class="sidebar">
    <div class="sidebar-header">
        <h2>Super Admin</h2>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section">
            <a href="/admin/dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
                <span class="nav-icon">📊</span>
                <span class="nav-text">Dashboard</span>
            </a>
            <!-- Added Reports menu item -->
            <a href="/admin/reports.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : '' ?>">
                <span class="nav-icon">📈</span>
                <span class="nav-text">Reports</span>
            </a>
            <a href="/admin/clinics.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'clinics.php' ? 'active' : '' ?>">
                <span class="nav-icon">🏥</span>
                <span class="nav-text">Clinics</span>
            </a>
            <a href="/views/clinic_settings.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'clinic_settings.php' ? 'active' : '' ?>">
                <span class="nav-icon">📝</span>
                <span class="nav-text"><?= isset($lang) ? (lang('settings.clinic_info','Clinic Settings')) : 'Clinic Settings' ?></span>
            </a>
            <a href="/admin/plans.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'plans.php' ? 'active' : '' ?>">
                <span class="nav-icon">💎</span>
                <span class="nav-text">Plans</span>
            </a>
            <a href="/admin/settings.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : '' ?>">
                <span class="nav-icon">⚙️</span>
                <span class="nav-text">Settings</span>
            </a>
            <a href="/admin/landing.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) === 'landing.php' ? 'active' : '' ?>">
                <span class="nav-icon">🌐</span>
                <span class="nav-text">Landing Page</span>
            </a>
            <a href="/admin/logout.php" class="nav-item">
                <span class="nav-icon">🚪</span>
                <span class="nav-text">Logout</span>
            </a>
        </div>
    </nav>
</aside>
