<?php
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../config/config.php';

if (!defined('HAS_VENDOR') || !HAS_VENDOR) {
    http_response_code(503);
    echo 'Service unavailable: dependencies missing. Run `composer install` in project root.';
    exit;
}

\Stripe\Stripe::setApiKey(getenv('STRIPE_SECRET_KEY'));

$endpoint_secret = getenv('STRIPE_WEBHOOK_SECRET');

$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
$event = null;

try {
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, $endpoint_secret
    );
} catch(\UnexpectedValueException $e) {
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    http_response_code(400);
    exit();
}

$db = Database::getInstance();

// Handle the event
switch ($event->type) {
    case 'checkout.session.completed':
        $session = $event->data->object;
        
        // Get clinic ID from metadata
        $clinicId = $session->metadata->clinic_id;
        $planId = $session->metadata->plan_id;
        $subscriptionId = $session->subscription;
        
        // Update clinic subscription
        $stmt = $db->prepare("UPDATE clinics SET 
            plan_id = ?, 
            stripe_subscription_id = ?, 
            subscription_status = 'active',
            subscription_end_date = DATE_ADD(NOW(), INTERVAL 1 MONTH)
            WHERE id = ?");
        $stmt->bind_param("isi", $planId, $subscriptionId, $clinicId);
        $stmt->execute();
        break;
        
    case 'customer.subscription.updated':
        $subscription = $event->data->object;
        
        // Update subscription status
        $stmt = $db->prepare("UPDATE clinics SET 
            subscription_status = ?
            WHERE stripe_subscription_id = ?");
        $status = $subscription->status;
        $subscriptionId = $subscription->id;
        $stmt->bind_param("ss", $status, $subscriptionId);
        $stmt->execute();
        break;
        
    case 'customer.subscription.deleted':
        $subscription = $event->data->object;
        
        // Cancel subscription
        $stmt = $db->prepare("UPDATE clinics SET 
            subscription_status = 'canceled'
            WHERE stripe_subscription_id = ?");
        $subscriptionId = $subscription->id;
        $stmt->bind_param("s", $subscriptionId);
        $stmt->execute();
        break;
        
    default:
        echo 'Received unknown event type ' . $event->type;
}

http_response_code(200);
