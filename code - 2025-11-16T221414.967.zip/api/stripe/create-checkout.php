<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Helpers.php';

Auth::requireLogin();

// Ensure vendor and Stripe are available
if (!defined('HAS_VENDOR') || !HAS_VENDOR) {
    http_response_code(503);
    echo 'Service unavailable: dependencies missing. Run `composer install` in project root.';
    exit;
}

require_once __DIR__ . '/../../vendor/autoload.php';
\Stripe\Stripe::setApiKey(getenv('STRIPE_SECRET_KEY'));

$db = Database::getInstance();
$clinicId = $_SESSION['clinic_id'];
$planId = isset($_GET['plan_id']) ? (int)$_GET['plan_id'] : null;

if (!$planId) {
    die('Plan ID is required');
}

// Get plan details
$stmt = $db->prepare("SELECT * FROM plans WHERE id = ?");
$stmt->bind_param("i", $planId);
$plan = safe_stmt_fetch_assoc($stmt);

if (!$plan) {
    die('Plan not found');
}

// Get clinic details
$stmt = $db->prepare("SELECT * FROM clinics WHERE id = ?");
$stmt->bind_param("i", $clinicId);
$clinic = safe_stmt_fetch_assoc($stmt);

try {
    // Create or retrieve Stripe customer
    if ($clinic['stripe_customer_id']) {
        $customerId = $clinic['stripe_customer_id'];
    } else {
        $customer = \Stripe\Customer::create([
            'email' => $clinic['email'],
            'name' => $clinic['name'],
            'metadata' => [
                'clinic_id' => $clinicId
            ]
        ]);
        $customerId = $customer->id;
        
        // Save customer ID for the authenticated clinic only (scoped by clinic id)
        $stmt = $db->prepare("UPDATE clinics SET stripe_customer_id = ? WHERE id = ?");
        $stmt->bind_param("si", $customerId, $clinicId);
        $stmt->execute();
    }
    
    // Create checkout session
    $session = \Stripe\Checkout\Session::create([
        'customer' => $customerId,
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => $plan['name_en'],
                    'description' => "Max {$plan['max_users']} users, {$plan['max_patients']} patients",
                ],
                'unit_amount' => $plan['price'] * 100, // Convert to cents
                'recurring' => [
                    'interval' => 'month'
                ]
            ],
            'quantity' => 1,
        ]],
        'mode' => 'subscription',
        'success_url' => rtrim(APP_URL, '/') . '/views/settings/profile.php?success=1',
        'cancel_url' => rtrim(APP_URL, '/') . '/views/settings/profile.php?canceled=1',
        'metadata' => [
            'clinic_id' => $clinicId,
            'plan_id' => $planId
        ]
    ]);
    
    // Redirect to checkout
    header('Location: ' . $session->url);
    exit;
    
} catch (Exception $e) {
    die('Error creating checkout session: ' . $e->getMessage());
}
