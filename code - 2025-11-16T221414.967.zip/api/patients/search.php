<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/Database.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/Helpers.php';

header('Content-Type: application/json');

if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$query = $_GET['q'] ?? '';
$clinicId = $_SESSION['clinic_id'];

if (strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

$db = Database::getInstance();
$searchParam = "%$query%";

$stmt = $db->prepare("SELECT id, first_name, last_name, phone FROM patients WHERE clinic_id = ? AND (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ?) LIMIT 10");
$stmt->bind_param("isss", $clinicId, $searchParam, $searchParam, $searchParam);
$results = safe_stmt_fetch_all($stmt);

echo json_encode($results);
