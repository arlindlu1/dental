<?php
/**
 * Configuration Template
 * This file will be copied and populated by the installer
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'dental_saas');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application Configuration
define('APP_NAME', 'dentisti.pro');
define('APP_URL', 'https://dentisti.pro');
define('APP_TIMEZONE', 'Europe/Tirane');

// Security
define('SESSION_LIFETIME', 7200); // 2 hours

// Paths
define('UPLOAD_PATH', __DIR__ . '/../public/uploads/');
define('MAX_UPLOAD_SIZE', 5242880); // 5MB

// Default Language
define('DEFAULT_LANG', 'sq');

// Mailer (invite delivery)
// Set MAIL_ENABLED to true and configure SMTP or use PHP mail() in production.
define('MAIL_ENABLED', false);
define('MAIL_METHOD', 'mail'); // 'mail' or 'smtp' (smtp not implemented in sample)
define('MAIL_FROM', 'noreply@example.com');
define('MAIL_FROM_NAME', APP_NAME);
// SMTP settings (optional; shown for completeness if you later add an SMTP mailer)
define('SMTP_HOST', 'smtp.example.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'smtp_user');
define('SMTP_PASS', 'smtp_pass');
// SMTP encryption: 'tls' or 'ssl'
define('SMTP_ENCRYPTION', 'tls');
