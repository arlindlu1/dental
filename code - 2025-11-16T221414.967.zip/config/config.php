<?php
/**
 * Application Configuration
 */

// Load .env file if present (simple parser)
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') === false) continue;
        [$k, $v] = explode('=', $line, 2);
        $k = trim($k);
        $v = trim($v);
        if (!getenv($k)) putenv("$k=$v");
        if (!isset($_ENV[$k])) $_ENV[$k] = $v;
        if (!isset($_SERVER[$k])) $_SERVER[$k] = $v;
    }
}

// Environment (production|development)
define('APP_ENV', getenv('APP_ENV') ?: 'development');

// Database Configuration (from env or defaults)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'dental_saas');

// Application Settings
define('APP_NAME', getenv('APP_NAME') ?: 'dentisti.pro');
define('APP_URL', rtrim(getenv('APP_URL') ?: 'http://localhost', '\/'));
define('CURRENCY_SYMBOL', getenv('CURRENCY_SYMBOL') ?: '€');

// Session Configuration: prefer secure cookies in production when HTTPS
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);
$secureCookie = (APP_ENV === 'production' && (stripos(APP_URL, 'https://') === 0));

// Set SameSite and secure cookie params (PHP 7.3+ supports array form)
$cookieDomain = parse_url(APP_URL, PHP_URL_HOST) ?: '';
session_name('dental_sess');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => $cookieDomain,
    'secure' => $secureCookie,
    'httponly' => true,
    'samesite' => 'Lax',
]);

// Error Reporting
if (APP_ENV === 'production') {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../storage/logs/php-error.log');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Timezone
date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'Europe/Tirane');

// Default language
define('DEFAULT_LANG', getenv('DEFAULT_LANG') ?: 'sq');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    // Regenerate session id on start for additional safety (avoid fixation)
    if (empty($_SESSION['__initiated'])) {
        session_regenerate_id(true);
        $_SESSION['__initiated'] = true;
    }
}

// Security headers (will be sent on every request from this bootstrap)
if (!headers_sent()) {
    // Prevent clickjacking
    header('X-Frame-Options: DENY');
    // Prevent MIME type sniffing
    header('X-Content-Type-Options: nosniff');
    // Basic Referrer-Policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    // Disable X-Powered-By exposure
    ini_set('expose_php', '0');
    header_remove('X-Powered-By');
    // Enforce HTTPS strict transport security in production
    if (APP_ENV === 'production' && $secureCookie) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    }
    // Content Security Policy - conservative default (may need adjustments for external assets)
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none';");
}

// In production prefer HTTPS - redirect if host is not secure and APP_URL uses https
if (APP_ENV === 'production' && (stripos(APP_URL, 'https://') === 0)) {
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') == 443;
    if (!$isSecure && !headers_sent()) {
        $redirect = 'https://' . ($_SERVER['HTTP_HOST'] ?? parse_url(APP_URL, PHP_URL_HOST)) . ($_SERVER['REQUEST_URI'] ?? '/');
        header('Location: ' . $redirect, true, 301);
        exit;
    }
}

// Check for composer vendor autoload
define('HAS_VENDOR', file_exists(__DIR__ . '/../vendor/autoload.php'));
if (HAS_VENDOR) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

// Mailer configuration (read from environment/.env)
define('MAIL_ENABLED', (strtolower(getenv('MAIL_ENABLED') ?: 'false') === 'true' || getenv('MAIL_ENABLED') === '1'));
define('MAIL_METHOD', getenv('MAIL_METHOD') ?: 'mail'); // 'mail' or 'smtp'
define('MAIL_FROM', getenv('MAIL_FROM') ?: ('no-reply@' . preg_replace('/^https?:\/\//', '', APP_URL)));
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: APP_NAME);

define('SMTP_HOST', getenv('SMTP_HOST') ?: getenv('MAIL_HOST') ?: '');
define('SMTP_PORT', (int)(getenv('SMTP_PORT') ?: getenv('MAIL_PORT') ?: 0));
define('SMTP_USER', getenv('SMTP_USER') ?: getenv('MAIL_USERNAME') ?: '');
define('SMTP_PASS', getenv('SMTP_PASS') ?: getenv('MAIL_PASSWORD') ?: '');
define('SMTP_ENCRYPTION', getenv('SMTP_ENCRYPTION') ?: getenv('MAIL_ENCRYPTION') ?: '');

// Centralized error and exception handling: log to PHP error log and to storage logs
set_error_handler(function($severity, $message, $file, $line) {
    $msg = sprintf("[%s] PHP Error: %s in %s on line %d\n", date('c'), $message, $file, $line);
    error_log($msg);
    @file_put_contents(__DIR__ . '/../storage/logs/errors.log', $msg, FILE_APPEND | LOCK_EX);

    // Only convert major errors/warnings to exceptions so notices don't break execution
    $major = E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR | E_RECOVERABLE_ERROR | E_WARNING | E_USER_WARNING;
    if ($severity & $major) {
        throw new ErrorException($message, 0, $severity, $file, $line);
    }

    // For lesser severities (notices, deprecated), just log and continue
    return true;
});

set_exception_handler(function($e) {
    $msg = sprintf("[%s] Uncaught Exception: %s in %s on line %d\nStack trace:\n%s\n", date('c'), $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString());
    error_log($msg);
    @file_put_contents(__DIR__ . '/../storage/logs/errors.log', $msg, FILE_APPEND | LOCK_EX);

    // In production: show generic message, otherwise show exception message
    if (APP_ENV === 'production') {
        http_response_code(500);
        echo "An internal server error occurred.";
        exit;
    } else {
        // In non-production, re-throw to allow PHP default handler to display
        echo "<pre>" . htmlspecialchars($msg) . "</pre>";
        exit;
    }
});
