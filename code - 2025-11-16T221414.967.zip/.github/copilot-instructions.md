## Copilot / AI Assistant Instructions for dentisti.pro (PHP + Next.js)

This project is a hybrid legacy PHP multi-tenant application (server-rendered) with a modern Next.js admin/landing UI assets directory. The goal of these instructions is to help AI coding agents be productive quickly and make safe, small, discoverable changes.

- Architecture (big picture):
  - **Backend (PHP)**: Core application lives in the repository root and `admin/`, `views/`, `api/`, and `lib/`. Multi-tenant data isolation is implemented via `clinic_id` stored in session. Important files: `lib/Database.php`, `lib/Auth.php`, `lib/Helpers.php`, `install/schema.sql`, `config/config.php` (generated).
  - **Front-end assets & Next.js**: Modern UI components live under `app/`, `components/`, `assets/` and a Next.js app is included (see `package.json` scripts). However, the deployed product is primarily server-rendered PHP; Next.js is used for modern UI/dev convenience in the repository.
  - **Third-party integrations**: Stripe is integrated via `vendor/stripe` and webhook handler `api/stripe/webhook.php`. PDF generation uses `dompdf` (via Composer).

- Developer workflows & commands:
  - PHP dev (no container): ensure PHP >= 8.0 and MySQL available. Use the `install/installer.php` web installer to create `config/config.php` and the database. After installation, remove the `install/` directory.
  - Composer dependencies: run `composer install` in project root to enable vendor libs (Stripe, DomPDF). `api/stripe/webhook.php` checks a `HAS_VENDOR` constant.
  - Next.js front-end tasks: `npm run dev` (or `pnpm` if you use pnpm). Scripts available in `package.json`: `dev`, `build`, `start`, `lint`.

- Project-specific conventions & patterns:
  - Sessions carry tenancy: code uses `$_SESSION['clinic_id']` to scope queries. Any backend change must preserve clinic scoping.
  - Prepared statements: database access uses the `Database` singleton and `prepare()` / bind_param. Use these helpers and `safe_stmt_*` wrappers in `lib/Helpers.php` when adding queries.
  - CSRF handling: central CSRF helpers are in `Auth::generateCSRFToken()` and `Auth::verifyCSRFToken()` — forms may expect a `csrf_token` field.
  - File uploads: `uploadFile()` stores files under `public/uploads/<dir>` and returns a public `/uploads/...` path.
  - Redirects & assets: use `redirect()` and `asset()` helpers from `lib/Helpers.php`.
  - Activity logs: use `Auth::logActivity()` to register user actions when appropriate.

- Safety & change scope for AI edits:
  - Prefer small targeted patches (add an endpoint, fix a view, or update a helper). Avoid large refactors of tenancy or auth.
  - Always preserve multi-tenant checks (`clinic_id`) on queries. If adding a query, bind `clinic_id` (or call an admin-only flow using `super_admin_id`).
  - When modifying forms, ensure CSRF tokens remain present and validated.

- Examples (copy/paste patterns):
  - Database singleton: `Database::getInstance()->prepare($sql)` then `bind_param` and `safe_stmt_fetch_all()`.
  - Auth check guard: `if (!Auth::check()) { redirect('/login.php'); }` or JSON API: return 401 and `echo json_encode(['error' => 'Unauthorized']);`.
  - Patient search API usage: see `api/patients/search.php` (bind `clinic_id`, use `%$q%` param, limit results).

- Key files & directories to inspect for tasks:
  - `lib/Database.php`, `lib/Auth.php`, `lib/Helpers.php`
  - `admin/*.php`, `views/` (UI server-rendered pages)
  - `api/` (REST-like endpoints), especially `api/patients/` and `api/stripe/`
  - `install/` (schema + installer flow) and `install/schema.sql`
  - `config/config.sample.php` and generated `config/config.php`
  - `package.json`, `app/`, `components/` for Next.js/UI work

- Integration notes:
  - Environment: some files read env vars (Stripe keys) via `getenv()` in `api/stripe/webhook.php`. When running locally, set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` in your environment or `config/config.php`.
  - Composer required for vendor libs. `api/stripe/webhook.php` returns 503 if `HAS_VENDOR` is not set.

- Editing & testing tips:
  - To test a PHP change quickly: run a local Apache/PHP server or use built-in PHP server (for non-URL-rewrite pages) with `php -S localhost:8000 -t public/` after ensuring `config/config.php` exists and paths are correct.
  - For Next.js UI changes: `npm run dev` in project root (requires Node 18+ / matching environment).

- When to ask the human maintainer:
  - Any change that touches tenancy enforcement, session layout, authentication flow, or migrations.
  - When adding/removing vendor dependencies (Composer), or changing production deployment configuration.

If anything here is unclear or you want more/less detail (examples, env var lists, or common PR checklist), tell me which sections to expand and I'll iterate.
