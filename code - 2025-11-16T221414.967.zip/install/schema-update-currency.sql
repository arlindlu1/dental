-- Update prices to Euros in plans table
UPDATE `plans` SET 
  `price_monthly` = 29.00,
  `price_yearly` = 290.00
WHERE `name` = 'Starter';

UPDATE `plans` SET 
  `price_monthly` = 79.00,
  `price_yearly` = 790.00
WHERE `name` = 'Pro';

UPDATE `plans` SET 
  `price_monthly` = 149.00,
  `price_yearly` = 1490.00
WHERE `name` = 'Enterprise';

-- Update procedures prices to Euros
UPDATE `procedures` SET `price` = 20.00 WHERE `name_en` = 'Check-up';
UPDATE `procedures` SET `price` = 50.00 WHERE `name_en` = 'Filling';
UPDATE `procedures` SET `price` = 40.00 WHERE `name_en` = 'Extraction';
UPDATE `procedures` SET `price` = 150.00 WHERE `name_en` = 'Root Canal';
UPDATE `procedures` SET `price` = 300.00 WHERE `name_en` = 'Crown';
UPDATE `procedures` SET `price` = 800.00 WHERE `name_en` = 'Implant';
UPDATE `procedures` SET `price` = 30.00 WHERE `name_en` = 'Cleaning';
UPDATE `procedures` SET `price` = 200.00 WHERE `name_en` = 'Whitening';
