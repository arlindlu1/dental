-- Add tax_rate column to invoices table to allow manual tax editing

ALTER TABLE `invoices` ADD COLUMN `tax_rate` DECIMAL(5,2) NOT NULL DEFAULT 20.00 AFTER `subtotal`;

-- Update existing invoices to have 20% tax rate
UPDATE `invoices` SET `tax_rate` = 20.00 WHERE `tax_rate` = 0;
