-- Add tax_rate column to invoices table
ALTER TABLE `invoices` ADD COLUMN `tax_rate` decimal(5,2) NOT NULL DEFAULT 20.00 AFTER `subtotal`;

-- Update existing invoices to have explicit tax rate
UPDATE `invoices` SET `tax_rate` = 20.00 WHERE `tax_rate` = 0;
