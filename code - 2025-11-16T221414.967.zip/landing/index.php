<?php
// Start session only if not already active to avoid "Ignoring session_start()" notices
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Lang.php';

// Use static content instead
$heroTitle = Lang::current() === 'sq' ? 'Menaxhimi modern i klinikës dentare' : 'Modern dental clinic management';
$heroSubtitle = Lang::current() === 'sq' ? 'Platforma e plotë për menaxhimin e pacientëve, takimeve, faturave dhe hartave dentare në një vend të vetëm' : 'Complete platform for managing patients, appointments, invoices and dental charts in one place';
?>
<!DOCTYPE html>
<html lang="<?= Lang::current() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> - <?= Lang::current() === 'sq' ? 'Sistemi Profesional për Klinika Dentare' : 'Professional Dental Clinic Management' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        :root {
            --primary: #0ea5e9;
            --primary-dark: #0284c7;
            --secondary: #8b5cf6;
            --accent: #06b6d4;
            --dark: #0f172a;
            --dark-light: #1e293b;
            --gray: #64748b;
            --gray-light: #cbd5e1;
            --bg: #ffffff;
            --bg-alt: #f8fafc;
        }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6; 
            color: var(--dark);
            background: var(--bg);
            overflow-x: hidden;
        }
        
        .container { 
            max-width: 1280px; 
            margin: 0 auto; 
            padding: 0 24px; 
        }
        
        /* Modern 2025 header with glassmorphism */
        header { 
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border-bottom: 1px solid rgba(226, 232, 240, 0.5);
            position: sticky; 
            top: 0; 
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        header.scrolled {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.05);
        }
        
        nav { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 20px 0;
            height: 80px;
        }
        
        .logo { 
            font-size: 28px; 
            font-weight: 900; 
            color: var(--dark);
            letter-spacing: -1px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .nav-links { 
            display: flex; 
            gap: 48px; 
            align-items: center; 
        }
        
        .nav-links a { 
            text-decoration: none; 
            color: var(--gray);
            font-weight: 600;
            font-size: 15px;
            transition: all 0.2s ease;
            position: relative;
        }
        
        .nav-links a:hover { 
            color: var(--primary);
        }
        
        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: width 0.3s ease;
        }
        
        .nav-links a:hover::after {
            width: 100%;
        }
        
        .btn-login { 
            background: var(--dark);
            color: white; 
            padding: 12px 28px; 
            border-radius: 12px;
            font-weight: 700;
            transition: all 0.3s ease;
            box-shadow: 0 4px 14px rgba(15, 23, 42, 0.2);
        }
        
        .btn-login:hover {
            background: var(--dark-light);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.3);
        }
        
        /* Ultra-modern hero with animated gradient mesh */
        .hero { 
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            color: white; 
            padding: 140px 0 160px;
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(circle at 20% 50%, rgba(14, 165, 233, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 40% 20%, rgba(6, 182, 212, 0.1) 0%, transparent 50%);
            animation: gradientShift 20s ease infinite;
        }
        
        @keyframes gradientShift {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(10%, 10%) rotate(5deg); }
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
            max-width: 1000px;
            margin: 0 auto;
            text-align: center;
        }
        
        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 10px 24px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 40px;
            color: #a5f3fc;
            animation: fadeInUp 0.6s ease;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .hero h1 { 
            font-size: 80px;
            margin-bottom: 32px;
            line-height: 1.1;
            font-weight: 900;
            letter-spacing: -3px;
            animation: fadeInUp 0.6s ease 0.1s both;
            background: linear-gradient(135deg, #ffffff 0%, #e0f2fe 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero p { 
            font-size: 22px;
            margin-bottom: 56px;
            opacity: 0.95;
            line-height: 1.8;
            color: #cbd5e1;
            max-width: 750px;
            margin-left: auto;
            margin-right: auto;
            animation: fadeInUp 0.6s ease 0.2s both;
        }
        
        .hero-buttons { 
            display: flex; 
            gap: 20px; 
            justify-content: center;
            flex-wrap: wrap;
            animation: fadeInUp 0.6s ease 0.3s both;
        }
        
        .btn-primary { 
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: white; 
            padding: 20px 48px; 
            border-radius: 14px;
            text-decoration: none; 
            font-weight: 800;
            font-size: 18px;
            transition: all 0.3s ease;
            box-shadow: 0 8px 30px rgba(14, 165, 233, 0.4);
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }
        
        .btn-primary:hover::before {
            left: 100%;
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(14, 165, 233, 0.5);
        }
        
        .btn-secondary { 
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white; 
            padding: 20px 48px; 
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 14px;
            text-decoration: none; 
            font-weight: 800;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.4);
            transform: translateY(-3px);
        }
        
        /* Animated floating elements in hero */
        .hero-decoration {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(14, 165, 233, 0.1), rgba(139, 92, 246, 0.1));
            backdrop-filter: blur(40px);
            animation: float 20s ease-in-out infinite;
        }
        
        .hero-decoration:nth-child(1) {
            width: 400px;
            height: 400px;
            top: 10%;
            left: 5%;
            animation-delay: 0s;
        }
        
        .hero-decoration:nth-child(2) {
            width: 300px;
            height: 300px;
            bottom: 10%;
            right: 10%;
            animation-delay: 5s;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        
        /* Modern social proof with glassmorphism */
        .social-proof {
            background: var(--bg);
            padding: 80px 0;
            border-bottom: 1px solid rgba(226, 232, 240, 0.5);
        }
        
        .social-proof-content {
            text-align: center;
        }
        
        .social-proof p {
            color: var(--gray);
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 48px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 48px;
            max-width: 1000px;
            margin: 0 auto;
        }
        
        .stat-item {
            text-align: center;
            padding: 32px;
            background: white;
            border-radius: 20px;
            border: 1px solid rgba(226, 232, 240, 0.8);
            transition: all 0.3s ease;
        }
        
        .stat-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
            border-color: var(--primary);
        }
        
        .stat-number {
            font-size: 56px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 12px;
            letter-spacing: -2px;
        }
        
        .stat-label {
            color: var(--gray);
            font-size: 16px;
            font-weight: 600;
        }
        
        /* Bento grid features section */
        .features { 
            padding: 140px 0;
            background: linear-gradient(180deg, var(--bg) 0%, var(--bg-alt) 100%);
        }
        
        .features-header {
            text-align: center;
            max-width: 800px;
            margin: 0 auto 100px;
        }
        
        .section-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 24px;
        }
        
        .features-header h2 { 
            font-size: 56px;
            margin-bottom: 24px;
            font-weight: 900;
            letter-spacing: -2px;
            color: var(--dark);
            line-height: 1.1;
        }
        
        .features-header p {
            font-size: 22px;
            color: var(--gray);
            line-height: 1.7;
        }
        
        .features-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); 
            gap: 32px;
        }
        
        .feature-card { 
            padding: 48px; 
            border-radius: 24px;
            background: white;
            border: 1px solid rgba(226, 232, 240, 0.8);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(14, 165, 233, 0.05) 0%, rgba(139, 92, 246, 0.05) 100%);
            opacity: 0;
            transition: opacity 0.4s ease;
        }
        
        .feature-card:hover::before {
            opacity: 1;
        }
        
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.12);
            border-color: var(--primary);
        }
        
        .feature-icon { 
            font-size: 56px;
            margin-bottom: 28px;
            display: block;
            position: relative;
            z-index: 1;
        }
        
        .feature-card h3 { 
            font-size: 24px;
            margin-bottom: 16px;
            font-weight: 800;
            color: var(--dark);
            position: relative;
            z-index: 1;
        }
        
        .feature-card p { 
            color: var(--gray);
            line-height: 1.8;
            font-size: 16px;
            position: relative;
            z-index: 1;
        }
        
        /* Modern pricing cards with 3D effect */
        .pricing { 
            padding: 140px 0;
            background: var(--bg);
            position: relative;
        }
        
        .pricing-header {
            text-align: center;
            max-width: 800px;
            margin: 0 auto 100px;
        }
        
        .pricing-header h2 { 
            font-size: 56px;
            margin-bottom: 24px;
            font-weight: 900;
            letter-spacing: -2px;
            color: var(--dark);
        }
        
        .pricing-header p {
            font-size: 22px;
            color: var(--gray);
        }
        
        .pricing-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); 
            gap: 40px;
            max-width: 1200px; 
            margin: 0 auto;
        }
        
        .pricing-card { 
            background: white;
            border: 2px solid rgba(226, 232, 240, 0.8);
            border-radius: 32px;
            padding: 56px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        
        .pricing-card:hover {
            transform: translateY(-12px) scale(1.02);
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
        }
        
        .pricing-card.featured { 
            border-color: transparent;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            transform: scale(1.05);
            box-shadow: 0 20px 60px rgba(14, 165, 233, 0.3);
        }
        
        .pricing-card.featured:hover {
            transform: scale(1.05) translateY(-12px);
            box-shadow: 0 30px 80px rgba(14, 165, 233, 0.4);
        }
        
        .pricing-card.featured .plan-name,
        .pricing-card.featured .plan-price,
        .pricing-card.featured .plan-features li,
        .pricing-card.featured .plan-description {
            color: white;
        }
        
        .popular-badge {
            position: absolute;
            top: -16px;
            right: 40px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
        }
        
        .plan-name { 
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 20px;
            color: var(--dark);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .plan-price { 
            font-size: 64px;
            font-weight: 900;
            margin-bottom: 12px;
            color: var(--dark);
            letter-spacing: -3px;
        }
        
        .plan-price span { 
            font-size: 20px;
            color: var(--gray);
            font-weight: 600;
        }
        
        .pricing-card.featured .plan-price span {
            color: rgba(255, 255, 255, 0.9);
        }
        
        .plan-description {
            color: var(--gray);
            margin-bottom: 40px;
            font-size: 16px;
            font-weight: 500;
        }
        
        .plan-features { 
            list-style: none;
            margin-bottom: 48px;
        }
        
        .plan-features li { 
            padding: 16px 0;
            color: #475569;
            font-size: 16px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 16px;
            border-bottom: 1px solid rgba(226, 232, 240, 0.5);
        }
        
        .pricing-card.featured .plan-features li {
            border-bottom-color: rgba(255, 255, 255, 0.2);
        }
        
        .plan-features li:last-child {
            border-bottom: none;
        }
        
        .plan-features li::before {
            content: '✓';
            width: 24px;
            height: 24px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            font-weight: 800;
            font-size: 14px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .pricing-card.featured .plan-features li::before {
            background: white;
            color: var(--primary);
        }
        
        .btn-plan { 
            display: block;
            text-align: center;
            background: var(--dark);
            color: white; 
            padding: 18px;
            border-radius: 14px;
            text-decoration: none; 
            font-weight: 800;
            font-size: 17px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 20px rgba(15, 23, 42, 0.2);
        }
        
        .btn-plan:hover {
            background: var(--dark-light);
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(15, 23, 42, 0.3);
        }
        
        .pricing-card.featured .btn-plan {
            background: white;
            color: var(--primary);
        }
        
        .pricing-card.featured .btn-plan:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: translateY(-2px);
        }
        
        /* Gradient CTA section with animated background */
        .cta-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            padding: 120px 0;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .cta-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 30% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
            animation: pulse 10s ease infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }
        
        .cta-section .container {
            position: relative;
            z-index: 1;
        }
        
        .cta-section h2 {
            font-size: 56px;
            font-weight: 900;
            margin-bottom: 28px;
            letter-spacing: -2px;
        }
        
        .cta-section p {
            font-size: 22px;
            margin-bottom: 48px;
            opacity: 0.95;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.7;
        }
        
        .cta-section .btn-primary {
            background: white;
            color: var(--primary);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
        }
        
        .cta-section .btn-primary:hover {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
        }
        
        /* Modern contact section */
        .contact-section {
            padding: 120px 0;
            background: var(--bg-alt);
            text-align: center;
        }
        
        .contact-section .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .contact-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            margin: 0 auto 32px;
            box-shadow: 0 8px 30px rgba(14, 165, 233, 0.3);
        }
        
        .contact-section h2 {
            font-size: 48px;
            font-weight: 900;
            margin-bottom: 24px;
            color: var(--dark);
            letter-spacing: -2px;
        }
        
        .contact-section p {
            font-size: 20px;
            color: var(--gray);
            margin-bottom: 48px;
            line-height: 1.7;
        }
        
        .contact-section a {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 22px 56px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 800;
            font-size: 20px;
            box-shadow: 0 8px 30px rgba(14, 165, 233, 0.4);
            transition: all 0.3s ease;
        }
        
        .contact-section a:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(14, 165, 233, 0.5);
        }
        
        .contact-section p:last-child {
            margin-top: 40px;
            color: var(--gray);
            font-size: 16px;
        }
        
        /* Premium footer design */
        footer { 
            background: var(--dark);
            color: white; 
            padding: 100px 0 48px;
            position: relative;
        }
        
        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        }
        
        .footer-content { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 56px;
            margin-bottom: 64px;
        }
        
        .footer-section h3 { 
            margin-bottom: 24px;
            font-size: 18px;
            font-weight: 800;
            color: white;
        }
        
        .footer-section p {
            color: var(--gray-light);
            line-height: 1.8;
            font-size: 15px;
        }
        
        .footer-section a { 
            display: block;
            color: var(--gray-light);
            text-decoration: none;
            margin-bottom: 16px;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .footer-section a:hover { 
            color: white;
            transform: translateX(4px);
        }
        
        .footer-bottom { 
            text-align: center;
            padding-top: 48px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--gray);
            font-size: 15px;
        }
        
        .footer-bottom p {
            margin-bottom: 16px;
        }
        
        .footer-bottom a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            transition: color 0.2s ease;
        }
        
        .footer-bottom a:hover {
            color: var(--accent);
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .hero h1 { font-size: 48px; letter-spacing: -2px; }
            .hero p { font-size: 18px; }
            .hero-buttons { flex-direction: column; width: 100%; }
            .hero-buttons a { width: 100%; text-align: center; }
            .features-header h2,
            .pricing-header h2,
            .cta-section h2 { font-size: 36px; }
            .pricing-card.featured { transform: scale(1); }
            .pricing-card.featured:hover { transform: scale(1) translateY(-8px); }
            .nav-links { display: none; }
            .stats { grid-template-columns: 1fr; gap: 24px; }
            .features-grid,
            .pricing-grid { grid-template-columns: 1fr; }
            .hero-decoration { display: none; }
        }
        
        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body>
    <header id="header">
        <div class="container">
            <nav>
                <div class="logo">
                    <div class="logo-icon">🦷</div>
                    <?= APP_NAME ?>
                </div>
                <div class="nav-links">
                    <a href="#features"><?= Lang::current() === 'sq' ? 'Veçoritë' : 'Features' ?></a>
                    <a href="#pricing"><?= Lang::current() === 'sq' ? 'Çmimet' : 'Pricing' ?></a>
                    <a href="/login.php" class="btn-login"><?= Lang::current() === 'sq' ? 'Hyr' : 'Login' ?></a>
                    <a href="?lang=<?= Lang::current() === 'sq' ? 'en' : 'sq' ?>"><?= Lang::current() === 'sq' ? 'EN' : 'SQ' ?></a>
                </div>
            </nav>
        </div>
    </header>
    
    <section class="hero">
        <div class="hero-decoration"></div>
        <div class="hero-decoration"></div>
        <div class="container">
            <div class="hero-content">
                <div class="hero-badge">
                    ✨ <?= Lang::current() === 'sq' ? 'Platforma e re për klinika dentare' : 'New platform for dental clinics' ?>
                </div>
                <h1><?= htmlspecialchars($heroTitle) ?></h1>
                <p><?= htmlspecialchars($heroSubtitle) ?></p>
                <div class="hero-buttons">
                    <a href="/login.php" class="btn-primary"><?= Lang::current() === 'sq' ? 'Fillo Falas' : 'Start Free' ?></a>
                    <a href="#features" class="btn-secondary"><?= Lang::current() === 'sq' ? 'Shiko Veçoritë' : 'View Features' ?></a>
                </div>
            </div>
        </div>
    </section>
    
    <section class="social-proof">
        <div class="container">
            <div class="social-proof-content">
                <p><?= Lang::current() === 'sq' ? 'Besuar nga klinika dentare në të gjithë botën' : 'Trusted by dental clinics worldwide' ?></p>
                <div class="stats">
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label"><?= Lang::current() === 'sq' ? 'Klinika Aktive' : 'Active Clinics' ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50K+</div>
                        <div class="stat-label"><?= Lang::current() === 'sq' ? 'Pacientë' : 'Patients' ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">98%</div>
                        <div class="stat-label"><?= Lang::current() === 'sq' ? 'Kënaqësi' : 'Satisfaction' ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="features" id="features">
        <div class="container">
            <div class="features-header">
                <span class="section-badge"><?= Lang::current() === 'sq' ? 'Veçoritë' : 'Features' ?></span>
                <h2><?= Lang::current() === 'sq' ? 'Çdo gjë që ju nevojitet' : 'Everything you need' ?></h2>
                <p><?= Lang::current() === 'sq' ? 'Menaxhoni klinikën tuaj dentare me lehtësi dhe profesionalizëm' : 'Manage your dental clinic with ease and professionalism' ?></p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <span class="feature-icon">👥</span>
                    <h3><?= Lang::current() === 'sq' ? 'Menaxhimi i Pacientëve' : 'Patient Management' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Mbani të gjitha të dhënat e pacientëve në një vend të sigurt me historik të plotë mjekësor' : 'Keep all patient data in one secure place with complete medical history' ?></p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">🦷</span>
                    <h3><?= Lang::current() === 'sq' ? 'Harta Dentare FDI' : 'FDI Dental Chart' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Regjistroni statusin e dhëmbëve me sistemin FDI dhe ndiqni trajtimin për çdo dhëmb' : 'Record tooth status with FDI system and track treatment for each tooth' ?></p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">📅</span>
                    <h3><?= Lang::current() === 'sq' ? 'Takime & Kalendar' : 'Appointments & Calendar' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Organizoni takimet dhe menaxhoni orarin e punës me kalendar intuitiv' : 'Organize appointments and manage working hours with intuitive calendar' ?></p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">💰</span>
                    <h3><?= Lang::current() === 'sq' ? 'Faturim i Thjeshtë' : 'Simple Billing' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Krijoni fatura dhe ndiqni pagesat me lehtësi të plotë' : 'Create invoices and track payments with complete ease' ?></p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">📊</span>
                    <h3><?= Lang::current() === 'sq' ? 'Raporte & Statistika' : 'Reports & Statistics' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Analizoni performancën e klinikës me raporte të detajuara' : 'Analyze clinic performance with detailed reports' ?></p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">🔒</span>
                    <h3><?= Lang::current() === 'sq' ? 'Siguri e Plotë' : 'Complete Security' ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Të dhënat tuaja janë të sigurta me enkriptim dhe backup automatik' : 'Your data is secure with encryption and automatic backup' ?></p>
                </div>
            </div>
        </div>
    </section>
    
    <section class="pricing" id="pricing">
        <div class="container">
            <div class="pricing-header">
                <span class="section-badge"><?= Lang::current() === 'sq' ? 'Çmimet' : 'Pricing' ?></span>
                <h2><?= Lang::current() === 'sq' ? 'Zgjidhni planin tuaj' : 'Choose your plan' ?></h2>
                <p><?= Lang::current() === 'sq' ? 'Filloni me plan falas ose zgjidhni planin që i përshtatet nevojave tuaja' : 'Start with a free plan or choose the plan that fits your needs' ?></p>
            </div>
            <div class="pricing-grid">
                <div class="pricing-card">
                    <div class="plan-name">Starter</div>
                    <div class="plan-price">€29<span>/<?= Lang::current() === 'sq' ? 'muaj' : 'month' ?></span></div>
                    <p class="plan-description"><?= Lang::current() === 'sq' ? 'Perfekt për klinika të vogla' : 'Perfect for small clinics' ?></p>
                    <ul class="plan-features">
                        <li><?= Lang::current() === 'sq' ? '3 Përdorues' : '3 Users' ?></li>
                        <li><?= Lang::current() === 'sq' ? '100 Pacientë' : '100 Patients' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Harta Dentare' : 'Dental Chart' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Faturim Bazik' : 'Basic Billing' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Mbështetje Email' : 'Email Support' ?></li>
                    </ul>
                    <a href="/login.php" class="btn-plan"><?= Lang::current() === 'sq' ? 'Fillo Tani' : 'Get Started' ?></a>
                </div>
                
                <div class="pricing-card featured">
                    <div class="popular-badge"><?= Lang::current() === 'sq' ? 'MË I PËRDORUR' : 'MOST POPULAR' ?></div>
                    <div class="plan-name">Pro</div>
                    <div class="plan-price">€79<span>/<?= Lang::current() === 'sq' ? 'muaj' : 'month' ?></span></div>
                    <p class="plan-description"><?= Lang::current() === 'sq' ? 'Për klinika në rritje' : 'For growing clinics' ?></p>
                    <ul class="plan-features">
                        <li><?= Lang::current() === 'sq' ? '10 Përdorues' : '10 Users' ?></li>
                        <li><?= Lang::current() === 'sq' ? '500 Pacientë' : '500 Patients' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Të gjitha veçoritë Starter' : 'All Starter features' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Inventari' : 'Inventory' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Raporte të Avancuara' : 'Advanced Reports' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Mbështetje Prioritare' : 'Priority Support' ?></li>
                    </ul>
                    <a href="/login.php" class="btn-plan"><?= Lang::current() === 'sq' ? 'Fillo Tani' : 'Get Started' ?></a>
                </div>
                
                <div class="pricing-card">
                    <div class="plan-name">Enterprise</div>
                    <div class="plan-price">€149<span>/<?= Lang::current() === 'sq' ? 'muaj' : 'month' ?></span></div>
                    <p class="plan-description"><?= Lang::current() === 'sq' ? 'Për klinika të mëdha' : 'For large clinics' ?></p>
                    <ul class="plan-features">
                        <li><?= Lang::current() === 'sq' ? 'Përdorues të pakufizuar' : 'Unlimited Users' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Pacientë të pakufizuar' : 'Unlimited Patients' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Të gjitha veçoritë Pro' : 'All Pro features' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'API Access' : 'API Access' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Trajnim Personalizuar' : 'Custom Training' ?></li>
                        <li><?= Lang::current() === 'sq' ? 'Menaxher Dedikuar' : 'Dedicated Manager' ?></li>
                    </ul>
                    <a href="/login.php" class="btn-plan"><?= Lang::current() === 'sq' ? 'Kontaktoni' : 'Contact Us' ?></a>
                </div>
            </div>
        </div>
    </section>
    
    <section class="cta-section">
        <div class="container">
            <h2><?= Lang::current() === 'sq' ? 'Gati për të filluar?' : 'Ready to get started?' ?></h2>
            <p><?= Lang::current() === 'sq' 
                    ? 'Bashkohuni me qindra klinika dentare që besojnë tek ne për menaxhimin e pacientëve' 
                    : 'Join hundreds of dental clinics that trust us for patient management' 
                ?></p>
            <a href="/login.php" class="btn-primary"><?= Lang::current() === 'sq' ? 'Fillo Falas Sot' : 'Start Free Today' ?></a>
        </div>
    </section>
    
    <section class="contact-section">
        <div class="container">
            <div class="contact-icon">📧</div>
            <h2><?= Lang::current() === 'sq' ? 'Krijoni llogarinë tuaj' : 'Create Your Account' ?></h2>
            <p><?= Lang::current() === 'sq' 
                ? 'Për të krijuar një llogari dhe për informacione mbi pagesat, ju lutemi na kontaktoni në:' 
                : 'To create an account and for payment information, please contact us at:' 
            ?></p>
            <a href="mailto:info@devsyx.com">info@devsyx.com</a>
            <p><?= Lang::current() === 'sq' 
                ? 'Ekipi ynë do t\'ju përgjigjet brenda 24 orëve' 
                : 'Our team will respond within 24 hours' 
            ?></p>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?= APP_NAME ?></h3>
                    <p><?= Lang::current() === 'sq' ? 'Platforma moderne për menaxhimin e klinikave dentare me teknologji të avancuar dhe dizajn intuitiv' : 'Modern platform for dental clinic management with advanced technology and intuitive design' ?></p>
                </div>
                <div class="footer-section">
                    <h3><?= Lang::current() === 'sq' ? 'Produkt' : 'Product' ?></h3>
                    <a href="#features"><?= Lang::current() === 'sq' ? 'Veçoritë' : 'Features' ?></a>
                    <a href="#pricing"><?= Lang::current() === 'sq' ? 'Çmimet' : 'Pricing' ?></a>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Demo' : 'Demo' ?></a>
                </div>
                <div class="footer-section">
                    <h3><?= Lang::current() === 'sq' ? 'Kompania' : 'Company' ?></h3>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Rreth nesh' : 'About' ?></a>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Kontakt' : 'Contact' ?></a>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Blog' : 'Blog' ?></a>
                </div>
                <div class="footer-section">
                    <h3><?= Lang::current() === 'sq' ? 'Ligjore' : 'Legal' ?></h3>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Privatësia' : 'Privacy' ?></a>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Termat' : 'Terms' ?></a>
                    <a href="#"><?= Lang::current() === 'sq' ? 'Cookies' : 'Cookies' ?></a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= APP_NAME ?>. <?= Lang::current() === 'sq' ? 'Të gjitha të drejtat e rezervuara.' : 'All rights reserved.' ?></p>
                <p>Made with ❤️ by <a href="https://devsyx.com" target="_blank">devsyx.com</a></p>
            </div>
        </div>
    </footer>
    
    <script>
        window.addEventListener('scroll', function() {
            const header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>
</body>
</html>
