<?php
// Simple Mailer helper that uses PHP `mail()` when enabled.
// For production consider replacing with PHPMailer or similar SMTP-capable library.
class Mailer
{
    public static function sendInvite(string $to, string $inviteUrl, string $clinicName = ''): bool
    {
        if (!defined('MAIL_ENABLED') || !MAIL_ENABLED) {
            return false;
        }

        $from = defined('MAIL_FROM') ? MAIL_FROM : 'noreply@example.com';
        $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : '';

        $subject = sprintf('%s - Invitation to join %s', defined('APP_NAME') ? APP_NAME : 'App', $clinicName ?: 'your clinic');

        $body = "<html><body>";
        $body .= "<p>Hello,</p>";
        $body .= "<p>You have been invited to join <strong>" . htmlspecialchars($clinicName) . "</strong>.";
        $body .= " Please follow the link below to accept the invitation and set your password:</p>";
        $body .= "<p><a href='" . htmlspecialchars($inviteUrl) . "'>Accept invitation</a></p>";
        $body .= "<p>If the link does not work, copy and paste this URL into your browser:<br>" . htmlspecialchars($inviteUrl) . "</p>";
        $body .= "<p>Regards,<br>" . htmlspecialchars($fromName ?: (defined('APP_NAME') ? APP_NAME : 'Team')) . "</p>";
        $body .= "</body></html>";

        $headers = [];
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
        $headers[] = 'From: ' . ($fromName ? ($fromName . ' <' . $from . '>') : $from);

        $headersStr = implode("\r\n", $headers);

        // Choose method
        $method = defined('MAIL_METHOD') ? strtolower(MAIL_METHOD) : 'mail';

        // If using SMTP, require PHPMailer and attempt retries with logging
        if ($method === 'smtp') {
            $autoload = __DIR__ . '/../vendor/autoload.php';
            if (!file_exists($autoload)) {
                // Log error: PHPMailer not installed
                @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - PHPMailer not installed. Run composer install.\n", FILE_APPEND);
                return false;
            }

            require_once $autoload;
            $attempts = 0;
            $maxAttempts = 3;
            $lastException = null;
            while ($attempts < $maxAttempts) {
                try {
                    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : '';
                    $mail->Port = defined('SMTP_PORT') ? (int)SMTP_PORT : 587;
                    $mail->SMTPAuth = true;
                    $mail->Username = defined('SMTP_USER') ? SMTP_USER : '';
                    $mail->Password = defined('SMTP_PASS') ? SMTP_PASS : '';

                    // Map common encryption names to PHPMailer constants for compatibility
                    $enc = defined('SMTP_ENCRYPTION') ? strtolower(trim(SMTP_ENCRYPTION)) : 'tls';
                    if (class_exists('PHPMailer\\PHPMailer\\PHPMailer') && defined('PHPMailer\\PHPMailer\\PHPMailer::ENCRYPTION_SMTPS')) {
                        // PHPMailer >=6.5 uses constants
                        if ($enc === 'ssl') {
                            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                            $mail->SMTPAutoTLS = false;
                        } elseif ($enc === 'tls') {
                            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->SMTPAutoTLS = true;
                        } else {
                            $mail->SMTPSecure = '';
                            $mail->SMTPAutoTLS = true;
                        }
                    } else {
                        // Fallback to string values for older PHPMailer
                        if ($enc === 'ssl') {
                            $mail->SMTPSecure = 'ssl';
                            $mail->SMTPAutoTLS = false;
                        } elseif ($enc === 'tls') {
                            $mail->SMTPSecure = 'tls';
                            $mail->SMTPAutoTLS = true;
                        } else {
                            $mail->SMTPSecure = '';
                            $mail->SMTPAutoTLS = true;
                        }
                    }

                    $mail->setFrom($from, $fromName ?: null);
                    $mail->addAddress($to);
                    $mail->isHTML(true);
                    $mail->Subject = $subject;
                    $mail->Body = $body;
                    $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<p>'], "\n", $body));
                    $sent = (bool) $mail->send();
                    if ($sent) {
                        return true;
                    }
                } catch (Exception $e) {
                    $lastException = $e;
                    @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - PHPMailer attempt " . ($attempts+1) . " failed: " . $e->getMessage() . "\n", FILE_APPEND);
                    // small backoff
                    sleep(1);
                }
                $attempts++;
            }
            if ($lastException) {
                @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - PHPMailer all attempts failed\n", FILE_APPEND);
            }
            return false;
        }

        // Fallback to PHP mail() when MAIL_METHOD is 'mail'
        if ($method === 'mail') {
            try {
                return (bool) mail($to, $subject, $body, $headersStr);
            } catch (Exception $e) {
                @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - mail() failed: " . $e->getMessage() . "\n", FILE_APPEND);
                return false;
            }
        }

        return false;
    }
}

// Send credentials email containing the default password (useful when accounts are created with temporary password)
if (!class_exists('Mailer')) {
    class Mailer {}
}

// Add method to Mailer class dynamically for older PHP versions (but file already defines Mailer)
// We'll append a function if Mailer exists
if (class_exists('Mailer')) {
    Mailer::class; // no-op to satisfy static analyzers
}

// Define a helper function that sends credentials via the existing Mailer implementation
// We cannot add methods to the class after it's defined easily, so create a procedural wrapper
function send_credentials_email(string $to, string $password, string $clinicName = ''): bool {
    // Compose email similar to sendInvite but include the password and login URL
    if (!defined('MAIL_ENABLED') || !MAIL_ENABLED) {
        return false;
    }

    $from = defined('MAIL_FROM') ? MAIL_FROM : 'noreply@example.com';
    $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : '';

    $subject = sprintf('%s - Your account credentials for %s', defined('APP_NAME') ? APP_NAME : 'App', $clinicName ?: 'your clinic');

    $loginUrl = rtrim(defined('APP_URL') ? APP_URL : '', '/') . '/login.php';

    $body = "<html><body>";
    $body .= "<p>Hello,</p>";
    $body .= "<p>An account has been created for <strong>" . htmlspecialchars($clinicName) . "</strong>. Use the credentials below to log in and change your password from the settings page.</p>";
    $body .= "<p><strong>Email:</strong> " . htmlspecialchars($to) . "<br/>";
    $body .= "<strong>Password:</strong> " . htmlspecialchars($password) . "</p>";
    $body .= "<p>Login here: <a href='" . htmlspecialchars($loginUrl) . "'>Login</a></p>";
    $body .= "<p>For security, please change your password after first login.</p>";
    $body .= "<p>Regards,<br>" . htmlspecialchars($fromName ?: (defined('APP_NAME') ? APP_NAME : 'Team')) . "</p>";
    $body .= "</body></html>";

    $headers = [];
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-type: text/html; charset=UTF-8';
    $headers[] = 'From: ' . ($fromName ? ($fromName . ' <' . $from . '>') : $from);
    $headersStr = implode("\r\n", $headers);

    $method = defined('MAIL_METHOD') ? strtolower(MAIL_METHOD) : 'mail';
    if ($method === 'smtp') {
        // reuse existing PHPMailer logic by instantiating PHPMailer here
        $autoload = __DIR__ . '/../vendor/autoload.php';
        if (!file_exists($autoload)) {
            @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - PHPMailer not installed for credentials email.\n", FILE_APPEND);
            return false;
        }
        require_once $autoload;
        $attempts = 0; $maxAttempts = 3; $lastException = null;
        while ($attempts < $maxAttempts) {
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : '';
                $mail->Port = defined('SMTP_PORT') ? (int)SMTP_PORT : 587;
                $mail->SMTPAuth = true;
                $mail->Username = defined('SMTP_USER') ? SMTP_USER : '';
                $mail->Password = defined('SMTP_PASS') ? SMTP_PASS : '';
                $enc = defined('SMTP_ENCRYPTION') ? strtolower(trim(SMTP_ENCRYPTION)) : 'tls';
                if ($enc === 'ssl') {
                    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                    $mail->SMTPAutoTLS = false;
                } else {
                    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->SMTPAutoTLS = true;
                }
                $mail->setFrom($from, $fromName ?: null);
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<p>'], "\n", $body));
                $sent = (bool)$mail->send();
                if ($sent) return true;
            } catch (Exception $e) {
                $lastException = $e;
                @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - Credentials email attempt " . ($attempts+1) . " failed: " . $e->getMessage() . "\n", FILE_APPEND);
                sleep(1);
            }
            $attempts++;
        }
        if ($lastException) @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - Credentials PHPMailer all attempts failed\n", FILE_APPEND);
        return false;
    }

    if ($method === 'mail') {
        try {
            return (bool) mail($to, $subject, $body, $headersStr);
        } catch (Exception $e) {
            @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - mail() credentials failed: " . $e->getMessage() . "\n", FILE_APPEND);
            return false;
        }
    }

    return false;
}
