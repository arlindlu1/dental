<?php
/**
 * Helper Functions
 */

function redirect($url) {
    header("Location: $url");
    exit;
}

function asset($path) {
    return '/assets/' . ltrim($path, '/');
}

function formatDate($date, $format = 'd/m/Y') {
    return date($format, strtotime($date));
}

function formatMoney($amount, $currency = '€') {
    return number_format($amount, 2, '.', ',') . ' ' . $currency;
}

function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function generateInvoiceNumber($clinicId) {
    $db = Database::getInstance();
    $year = date('Y');
    
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM invoices WHERE clinic_id = ? AND YEAR(date) = ?");
    $stmt->bind_param("ii", $clinicId, $year);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $number = $row['count'] + 1;
    return "DNT-{$year}-" . str_pad($number, 4, '0', STR_PAD_LEFT);
}

function uploadFile($file, $directory = 'patients') {
    $uploadDir = __DIR__ . '/../uploads/' . $directory . '/';
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    // Basic validation and hardening
    $maxSize = 5 * 1024 * 1024; // 5MB
    $allowedExt = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'pdf' => 'application/pdf'
    ];

    if (!isset($file['error']) || is_array($file['error'])) {
        error_log('Invalid file upload parameters');
        return false;
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        error_log('File upload error code: ' . $file['error']);
        return false;
    }

    if ($file['size'] > $maxSize) {
        error_log('Uploaded file too large: ' . $file['size']);
        return false;
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    // Use finfo to validate MIME type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!in_array($ext, array_keys($allowedExt)) || $allowedExt[$ext] !== $mime) {
        // Allow some mismatches for SVG and others by checking allowed MIME presence
        if (!in_array($mime, $allowedExt)) {
            error_log(sprintf('Rejected upload (ext=%s, mime=%s)', $ext, $mime));
            return false;
        }
    }

    $filename = bin2hex(random_bytes(8)) . '_' . time() . '.' . $ext;
    $filepath = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        error_log('Failed to move uploaded file to ' . $filepath);
        return false;
    }

    // Set safe permissions
    @chmod($filepath, 0644);

    return '/uploads/' . $directory . '/' . $filename;
}

function getStatusBadge($status) {
    $badges = [
        'scheduled' => '<span style="background: #3b82f6; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Scheduled</span>',
        'confirmed' => '<span style="background: #10b981; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Confirmed</span>',
        'completed' => '<span style="background: #059669; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Completed</span>',
        'cancelled' => '<span style="background: #ef4444; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Cancelled</span>',
        'no_show' => '<span style="background: #f59e0b; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">No Show</span>',
        'paid' => '<span style="background: #10b981; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Paid</span>',
        'unpaid' => '<span style="background: #ef4444; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Unpaid</span>',
        'partial' => '<span style="background: #f59e0b; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Partial</span>',
        'active' => '<span style="background: #10b981; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Active</span>',
        'inactive' => '<span style="background: #6b7280; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">Inactive</span>',
        'vip' => '<span style="background: #8b5cf6; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">VIP</span>',
    ];
    
    return $badges[$status] ?? $status;
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . ' minutes ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    
    return date('d M Y', $time);
}

function lang($key, $default = '') {
    // Ensure Lang class is available — some entrypoints may include Helpers before Lang
    if (!class_exists('Lang')) {
        $langFile = __DIR__ . '/Lang.php';
        if (file_exists($langFile)) {
            require_once $langFile;
        }
    }

    if (class_exists('Lang')) {
        return Lang::get($key, $default);
    }

    // Fallback: return default or key when Lang isn't available
    return $default ?: $key;
}

/**
 * Safe execute helpers for prepared statements and raw queries
 */
function safe_stmt_execute($stmt) {
    if (!$stmt) return false;
    if (!$stmt->execute()) return false;
    $res = $stmt->get_result();
    if ($res === false) return false;
    return $res;
}

function safe_stmt_fetch_assoc($stmt) {
    $res = safe_stmt_execute($stmt);
    if (!$res) return null;
    return $res->fetch_assoc();
}

function safe_stmt_fetch_all($stmt) {
    $res = safe_stmt_execute($stmt);
    if (!$res) return [];
    return $res->fetch_all(MYSQLI_ASSOC);
}

function safe_query_count($db, $sql) {
    $res = $db->query($sql);
    if (!$res) return 0;
    $row = $res->fetch_assoc();
    if (!$row) return 0;
    return isset($row['count']) ? (int)$row['count'] : 0;
}

function safe_query_value($db, $sql, $key = null) {
    $res = $db->query($sql);
    if (!$res) return null;
    $row = $res->fetch_assoc();
    if (!$row) return null;
    if ($key === null) return $row;
    return $row[$key] ?? null;
}

/**
 * Simple file-based email queue helpers.
 */
function enqueue_email(array $item) {
    $queueFile = __DIR__ . '/../storage/email_queue.json';
    $queue = [];
    if (file_exists($queueFile)) {
        $content = @file_get_contents($queueFile);
        $queue = $content ? json_decode($content, true) ?? [] : [];
    }
    $item['attempts'] = $item['attempts'] ?? 0;
    $item['created_at'] = $item['created_at'] ?? date('c');
    $queue[] = $item;
    @file_put_contents($queueFile, json_encode($queue, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    return true;
}

function read_email_queue() {
    $queueFile = __DIR__ . '/../storage/email_queue.json';
    if (!file_exists($queueFile)) return [];
    $content = @file_get_contents($queueFile);
    return $content ? (json_decode($content, true) ?? []) : [];
}

function write_email_queue(array $queue) {
    $queueFile = __DIR__ . '/../storage/email_queue.json';
    @file_put_contents($queueFile, json_encode($queue, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
}
