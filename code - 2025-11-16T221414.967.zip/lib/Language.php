<?php
/**
 * Compatibility wrapper for legacy Language usage
 * Delegates to the modern Lang static class.
 */

require_once __DIR__ . '/Lang.php';

class Language {
    private static $instance = null;

    private function __construct() {}

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Language();
        }
        return self::$instance;
    }

    public function get($key, $default = '') {
        return Lang::get($key, $default);
    }

    public function setLang($lang) {
        return Lang::setLang($lang);
    }

    public function current() {
        return Lang::current();
    }
}
