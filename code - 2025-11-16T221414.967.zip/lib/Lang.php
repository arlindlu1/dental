<?php
/**
 * Language Handler
 * Manages multilingual content
 */

class Lang {
    private static $lang = 'sq';
    private static $translations = [];
    private static $initialized = false;
    
    private static function init() {
        if (self::$initialized) return;
        
        // Allow switching language via ?lang= on any page
        if (isset($_GET['lang'])) {
            $requested = trim($_GET['lang']);
            if (in_array($requested, ['sq', 'en'])) {
                // Update session and current language without calling setLang()
                // to avoid recursive init() -> setLang() -> init() loops.
                $_SESSION['lang'] = $requested;
                self::$lang = $requested;
            }
        }

        // Get language from session or default
        if (isset($_SESSION['lang'])) {
            self::$lang = $_SESSION['lang'];
        } elseif (defined('DEFAULT_LANG')) {
            self::$lang = DEFAULT_LANG;
        }
        
        // Load translations
        $langFile = __DIR__ . '/../lang/' . self::$lang . '.php';
        if (file_exists($langFile)) {
            self::$translations = require $langFile;
        }
        
        self::$initialized = true;
    }
    
    public static function get($key, $default = '') {
        self::init();
        
        $keys = explode('.', $key);
        $value = self::$translations;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default ?: $key;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    public static function setLang($lang) {
        if (in_array($lang, ['sq', 'en'])) {
            $_SESSION['lang'] = $lang;
            self::$lang = $lang;
            // Mark uninitialized so translations are reloaded on next call to init()
            self::$initialized = false;
        }
    }
    
    public static function current() {
        self::init();
        return self::$lang;
    }
}
