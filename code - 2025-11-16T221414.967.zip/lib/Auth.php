<?php
/**
 * Authentication Handler
 * Manages user sessions and authentication
 */

class Auth {
    
    public static function check() {
        return isset($_SESSION['user_id']) && isset($_SESSION['clinic_id']);
    }
    
    public static function checkAdmin() {
        return isset($_SESSION['super_admin_id']);
    }
    
    public static function user() {
        if (!self::check()) {
            return null;
        }
        
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND clinic_id = ?");
        $stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['clinic_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public static function clinic() {
        if (!self::check()) {
            return null;
        }
        
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM clinics WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['clinic_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public static function admin() {
        if (!self::checkAdmin()) {
            return null;
        }
        
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM super_admins WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['super_admin_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public static function login($email, $password) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT u.*, c.status as clinic_status FROM users u JOIN clinics c ON u.clinic_id = c.id WHERE u.email = ? AND u.is_active = 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $user = $result->fetch_assoc();
        
        if (!password_verify($password, $user['password'])) {
            return false;
        }
        
        if ($user['clinic_status'] !== 'active' && $user['clinic_status'] !== 'trial') {
            return false;
        }
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['clinic_id'] = $user['clinic_id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];
        
        // Update last login (scoped to clinic for safety)
        $updateStmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ? AND clinic_id = ?");
        $updateStmt->bind_param("ii", $user['id'], $user['clinic_id']);
        $updateStmt->execute();
        
        // Log activity
        self::logActivity('login', null, null, 'User logged in');
        
        return true;
    }
    
    public static function loginAdmin($email, $password) {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM super_admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $admin = $result->fetch_assoc();
        
        if (!password_verify($password, $admin['password'])) {
            return false;
        }
        
        $_SESSION['super_admin_id'] = $admin['id'];
        $_SESSION['super_admin_name'] = $admin['name'];
        
        return true;
    }
    
    public static function logout() {
        self::logActivity('logout', null, null, 'User logged out');
        session_destroy();
    }
    
    public static function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
    
    public static function canAccess($requiredRole) {
        if (!self::check()) {
            return false;
        }
        
        $roles = ['reception' => 1, 'doctor' => 2, 'admin' => 3];
        $userRole = $_SESSION['user_role'];
        
        return $roles[$userRole] >= $roles[$requiredRole];
    }
    
    public static function logActivity($action, $entityType = null, $entityId = null, $details = null) {
        if (!self::check() && !self::checkAdmin()) {
            return;
        }

        $db = Database::getInstance();
        $clinicId = $_SESSION['clinic_id'] ?? 0;
        $userId = $_SESSION['user_id'] ?? ($_SESSION['super_admin_id'] ?? 0);
        $stmt = $db->prepare("INSERT INTO activity_logs (clinic_id, user_id, action, entity_type, entity_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        // bind_param requires variables (passed by reference). Evaluate complex values into temporaries first.
        $entityTypeVal = is_scalar($entityType) ? $entityType : json_encode($entityType);
        $detailsVal = is_scalar($details) ? $details : json_encode($details);
        $entityIdVal = $entityId === null ? 0 : (int)$entityId;

        $stmt->bind_param("iississ", $clinicId, $userId, $action, $entityTypeVal, $entityIdVal, $detailsVal, $ip);
        $stmt->execute();
    }
    
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public static function requireLogin() {
        if (!self::check()) {
            redirect('/login.php');
        }
    }
    
    public static function requireAdmin() {
        if (!self::checkAdmin()) {
            redirect('/admin/login.php');
        }
    }
}
