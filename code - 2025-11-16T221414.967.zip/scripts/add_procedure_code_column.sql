-- Add code column to procedures table
ALTER TABLE `procedures` ADD COLUMN `code` varchar(50) DEFAULT NULL AFTER `name_en`;
