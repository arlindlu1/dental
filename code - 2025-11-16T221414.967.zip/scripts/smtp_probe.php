<?php
require_once __DIR__ . '/../config/config.php';

$log = __DIR__ . '/../storage/logs/mailer.log';
file_put_contents($log, "\n" . date('c') . " - Starting SMTP probe run\n", FILE_APPEND);

if (!defined('HAS_VENDOR') || !HAS_VENDOR) {
    file_put_contents($log, date('c') . " - vendor/autoload.php missing, cannot run PHPMailer probe\n", FILE_APPEND);
    echo "Vendor autoload missing. Run composer install.\n";
    exit(1);
}

require_once __DIR__ . '/../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$host = SMTP_HOST ?: 'smtp.hostinger.com';
$user = SMTP_USER ?: 'no-reply@dentisti.pro';
$pass = SMTP_PASS ?: 'Admin123!@@!';
$from = MAIL_FROM ?: $user;
$to = getenv('MAIL_TEST_TO') ?: $user;

$configs = [
    ['port' => 465, 'secure' => 'ssl', 'auto_tls' => false],
    ['port' => 587, 'secure' => 'tls', 'auto_tls' => true],
    ['port' => 25,  'secure' => '',    'auto_tls' => true],
];

foreach ($configs as $cfg) {
    $port = $cfg['port'];
    $secure = $cfg['secure'];
    $autoTls = $cfg['auto_tls'];

    file_put_contents($log, date('c') . " - Attempting host={$host} port={$port} secure={$secure} auto_tls=" . ($autoTls? '1':'0') . "\n", FILE_APPEND);

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->SMTPDebug = 3;
        $mail->Debugoutput = function($str, $level) use ($log) {
            file_put_contents($log, date('c') . " - DEBUG[{$level}]: {$str}\n", FILE_APPEND);
        };

        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $user;
        $mail->Password = $pass;
        $mail->SMTPSecure = $secure === 'ssl' ? 'ssl' : ($secure === 'tls' ? 'tls' : '');
        $mail->SMTPAutoTLS = $autoTls;
        $mail->Timeout = 10;

        $mail->setFrom($from, MAIL_FROM_NAME ?: null);
        $mail->addAddress($to);
        $mail->Subject = "SMTP Probe: {$host}:{$port} ({$secure})";
        $mail->Body = "Probe body";

        $ok = $mail->send();
        file_put_contents($log, date('c') . " - send() returned: " . ($ok ? 'true' : 'false') . " for port={$port}\n", FILE_APPEND);
        echo "Attempt port={$port} secure={$secure} => " . ($ok ? "OK\n" : "Failed\n");
    } catch (Exception $e) {
        $msg = $e->getMessage();
        file_put_contents($log, date('c') . " - Exception for port={$port}: {$msg}\n", FILE_APPEND);
        echo "Exception on port={$port}: {$msg}\n";
    }
    // Small pause
    sleep(1);
}

file_put_contents($log, date('c') . " - Probe run complete\n", FILE_APPEND);
echo "Probe complete, check storage/logs/mailer.log for details.\n";
