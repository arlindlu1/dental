-- Add columns for enhanced clinic onboarding
ALTER TABLE clinics
  ADD COLUMN business_number VARCHAR(100) DEFAULT NULL,
  ADD COLUMN contact_person VARCHAR(255) DEFAULT NULL,
  ADD COLUMN contact_phone VARCHAR(50) DEFAULT NULL,
  ADD COLUMN city VARCHAR(100) DEFAULT NULL,
  ADD COLUMN postal_code VARCHAR(20) DEFAULT NULL,
  ADD COLUMN opening_hours TEXT DEFAULT NULL;
