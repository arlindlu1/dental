<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';

$opts = [];
foreach ($argv as $a) {
    if (strpos($a, '--') === 0) {
        $p = substr($a, 2);
        if (strpos($p, '=') !== false) {
            [$k, $v] = explode('=', $p, 2);
            $opts[$k] = $v;
        } else {
            $opts[$p] = true;
        }
    }
}

$email = $opts['email'] ?? $opts['e'] ?? null;
$password = $opts['password'] ?? $opts['p'] ?? 'admin123';
$name = $opts['name'] ?? 'Super Admin';

if (!$email) {
    echo "Usage: php scripts/create_super_admin.php --email=admin@example.com [--password=admin123] [--name='Admin']\n";
    exit(1);
}

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();

    $stmt = $conn->prepare("SELECT id FROM super_admins WHERE email = ? LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        echo "Super admin with email {$email} already exists.\n";
        exit(0);
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $ins = $conn->prepare("INSERT INTO super_admins (name, email, password, created_at) VALUES (?, ?, ?, NOW())");
    $ins->bind_param('sss', $name, $email, $hashed);
    if ($ins->execute()) {
        echo "Created super admin: {$email}\n";
    } else {
        echo "Failed to create super admin: " . $conn->error . "\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
