<?php
// scripts/smoke_checks.php
// Lightweight non-destructive environment checks for production readiness.
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';

$errors = [];

// 1) DB connection
try {
    $db = Database::getInstance();
    $res = $db->query("SELECT 1");
    if ($res === false) $errors[] = 'Database query failed: ' . $db->error;
} catch (Throwable $e) {
    $errors[] = 'Database connection failed: ' . $e->getMessage();
}

// 2) Required tables exist (quick checks)
$requiredTables = ['users','clinics','invoices','patients','activity_logs'];
foreach ($requiredTables as $t) {
    $r = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($t) . "'");
    if (!$r || $r->num_rows === 0) {
        $errors[] = "Missing required table: $t";
    }
}

// 3) Storage directories writable
$paths = [__DIR__ . '/../storage', __DIR__ . '/../storage/logs', __DIR__ . '/../uploads'];
foreach ($paths as $p) {
    if (!is_dir($p) || !is_writable($p)) {
        $errors[] = "Path not writable: $p";
    }
}

// 4) Vendor dependencies installed
if (!file_exists(__DIR__ . '/../vendor/autoload.php')) {
    $errors[] = 'Composer vendor directory not found. Run `composer install`.';
}

// 5) Mailer quick smoke (uses existing probe if available)
$smtpHost = SMTP_HOST ?: '';
if (!empty($smtpHost)) {
    // only check that config exists; do not attempt credentials-auth here
    echo "SMTP host configured: $smtpHost\n";
} else {
    echo "No SMTP host configured; system will use mail() fallback.\n";
}

// 6) Email queue existence check
$queueFile = __DIR__ . '/../storage/email_queue.json';
if (!file_exists($queueFile)) {
    echo "Email queue file not found (this may be fine): $queueFile\n";
} else {
    echo "Email queue file exists: $queueFile\n";
}

// Output results
if (!empty($errors)) {
    echo "SMOKE CHECKS FAILED:\n";
    foreach ($errors as $e) echo " - $e\n";
    exit(2);
}

echo "SMOKE CHECKS OK\n";
exit(0);
