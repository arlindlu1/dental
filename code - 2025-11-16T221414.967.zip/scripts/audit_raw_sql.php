<?php
$root = __DIR__ . '/../';
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$results = [];
foreach ($it as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getRealPath();
    if (!preg_match('/\\.php$/', $path)) continue;
    // skip vendor
    if (strpos($path, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR) !== false) continue;
    $content = file_get_contents($path);
    if (strpos($content, '->query(') !== false) {
        // capture few lines around first occurrence
        $lines = explode("\n", $content);
        foreach ($lines as $num => $line) {
            if (strpos($line, '->query(') !== false) {
                $start = max(0, $num - 2);
                $end = min(count($lines)-1, $num + 2);
                $snippet = array_slice($lines, $start, $end - $start + 1);
                $results[] = [$path, $num+1, implode("\n", $snippet)];
                break;
            }
        }
    }
}
if (empty($results)) {
    echo "No raw query usages found.\n";
} else {
    foreach ($results as $r) {
        echo "File: " . str_replace(getcwd() . DIRECTORY_SEPARATOR, '', $r[0]) . " (line " . $r[1] . ")\n";
        echo $r[2] . "\n----\n";
    }
}
