<?php
require_once __DIR__ . '/../config/config.php';

$log = __DIR__ . '/../storage/logs/mailer.log';
file_put_contents($log, "\n" . date('c') . " - Starting SMTP debug run\n", FILE_APPEND);

if (!defined('HAS_VENDOR') || !HAS_VENDOR) {
    file_put_contents($log, date('c') . " - vendor/autoload.php missing, cannot run PHPMailer\n", FILE_APPEND);
    echo "Vendor autoload missing. Run composer install.\n";
    exit(1);
}

require_once __DIR__ . '/../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$to = getenv('MAIL_TEST_TO') ?: (defined('SMTP_USER') ? SMTP_USER : MAIL_FROM);

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->SMTPDebug = 3;
    $mail->Debugoutput = function($str, $level) use ($log) {
        file_put_contents($log, date('c') . " - DEBUG[{$level}]: {$str}\n", FILE_APPEND);
    };

    $mail->Host = SMTP_HOST ?: '';
    $mail->Port = SMTP_PORT ?: 587;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USER ?: '';
    $mail->Password = SMTP_PASS ?: '';
    // PHPMailer expects '' or 'ssl'/'tls'
    $mail->SMTPSecure = SMTP_ENCRYPTION ?: '';
    $mail->SMTPSecure = $mail->SMTPSecure === 'ssl' ? 'ssl' : ($mail->SMTPSecure === 'tls' ? 'tls' : '');
    $mail->Timeout = 15;
    $mail->SMTPAutoTLS = false;

    $mail->setFrom(MAIL_FROM ?: $mail->Username, MAIL_FROM_NAME ?: null);
    $mail->addAddress($to);
    $mail->Subject = 'SMTP Debug Test';
    $mail->Body = 'SMTP Debug Test';

    $ok = $mail->send();
    file_put_contents($log, date('c') . " - send() returned: " . ($ok ? 'true' : 'false') . "\n", FILE_APPEND);
    echo ($ok ? "Sent OK\n" : "Send returned false\n");
} catch (Exception $e) {
    file_put_contents($log, date('c') . " - PHPMailer Exception: " . $e->getMessage() . "\n", FILE_APPEND);
    echo "PHPMailer Exception: " . $e->getMessage() . "\n";
}
