<?php
/**
 * Initialize required directories and add simple protections.
 * Run once after deployment or during setup.
 */

$base = __DIR__ . '/../';
$dirs = [
    $base . 'uploads',
    $base . 'uploads/patients',
    $base . 'uploads/clinics',
    $base . 'storage',
    $base . 'storage/logs'
];

foreach ($dirs as $d) {
    if (!is_dir($d)) {
        mkdir($d, 0755, true);
        echo "Created: $d\n";
    }
    // create index.html to prevent directory listing
    $index = rtrim($d, '/') . '/index.html';
    if (!file_exists($index)) {
        file_put_contents($index, "", LOCK_EX);
        echo "Created index: $index\n";
    }
    // create .gitignore to avoid committing uploads
    $gitignore = rtrim($d, '/') . '/.gitignore';
    if (!file_exists($gitignore)) {
        file_put_contents($gitignore, "*\n!.gitignore\nindex.html\n", LOCK_EX);
        echo "Created gitignore: $gitignore\n";
    }
}

// Add simple Apache .htaccess in uploads to disable PHP execution and deny access to .php files
 $htaccess = $base . 'uploads/.htaccess';
 $htContents = <<<'HT'
# Prevent execution of PHP inside uploads
<FilesMatch "\.(php|php[0-9]|phtml)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Disable directory listing
Options -Indexes
HT;
if (!file_exists($htaccess)) {
    @file_put_contents($htaccess, $htContents, LOCK_EX);
    echo "Created: $htaccess\n";
}

// Ensure storage/logs/errors.log exists
$errlog = $base . 'storage/logs/errors.log';
if (!file_exists($errlog)) {
    @file_put_contents($errlog, "", LOCK_EX);
    echo "Created: $errlog\n";
}
// Ensure php-error.log exists for PHP configured error_log
$phpErr = $base . 'storage/logs/php-error.log';
if (!file_exists($phpErr)) {
    @file_put_contents($phpErr, "", LOCK_EX);
    echo "Created: $phpErr\n";
}

echo "Initialization complete.\n";
