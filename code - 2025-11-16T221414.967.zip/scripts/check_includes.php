<?php
// Scans PHP files for include/require statements and checks whether targets exist.
// Run: php scripts/check_includes.php

$root = realpath(__DIR__ . '/../');
$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$missing = [];
$checked = [];

foreach ($rii as $file) {
    if ($file->isDir()) continue;
    $path = $file->getPathname();
    if (!preg_match('/\.(php|inc)$/i', $path)) continue;
    $contents = file_get_contents($path);

    // Use PHP tokenizer to find include/require statements safely
    $tokens = token_get_all($contents);
    $count = count($tokens);
    for ($i = 0; $i < $count; $i++) {
        $t = $tokens[$i];
        if (!is_array($t)) continue;
        $tokenName = token_name($t[0]);
        if (in_array($t[0], [T_REQUIRE_ONCE, T_REQUIRE, T_INCLUDE_ONCE, T_INCLUDE], true)) {
            // Next significant token(s) may be parentheses and then a string
            $j = $i + 1;
            // skip whitespace and parentheses
            while ($j < $count && (is_array($tokens[$j]) && $tokens[$j][0] === T_WHITESPACE || $tokens[$j] === '(')) {
                $j++;
            }
            if ($j < $count && is_array($tokens[$j]) && $tokens[$j][0] === T_CONSTANT_ENCAPSED_STRING) {
                $raw = $tokens[$j][1];
                // strip quotes
                $raw = trim($raw, "'\"");

                // ignore dynamic includes (variables or concatenation)
                if (preg_match('/[\$\{\}]/', $raw)) continue;

                // resolve candidate
                $candidate = null;
                if (strpos($raw, '__DIR__') !== false) {
                    // skip complex __DIR__ usages in strings
                    $candidate = null;
                } else {
                    // try relative to project root
                    $candidate = realpath($root . DIRECTORY_SEPARATOR . ltrim($raw, '/\\'));
                    if (!$candidate) {
                        $candidate = realpath(dirname($path) . DIRECTORY_SEPARATOR . $raw);
                    }
                }

                $key = $raw . ' referenced in ' . str_replace($root . DIRECTORY_SEPARATOR, '', $path);
                if (isset($checked[$key])) continue;
                $checked[$key] = true;

                if (!$candidate || !file_exists($candidate)) {
                    $missing[] = [
                        'file' => str_replace($root . DIRECTORY_SEPARATOR, '', $path),
                        'target' => $raw,
                        'resolved' => $candidate ?: null
                    ];
                }
            }
        }
    }
}

if (empty($missing)) {
    echo "No missing include/require targets detected.\n";
    exit(0);
}

echo "Missing include/require targets:\n\n";
foreach ($missing as $m) {
    echo "- In file: {$m['file']}\n  Target: {$m['target']}\n";
    echo "  Resolved path: " . ($m['resolved'] ?: '[could not resolve]') . "\n\n";
}

exit(1);
