<?php
$root = __DIR__ . '/../views/';
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$missing = [];
foreach ($it as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getRealPath();
    if (!preg_match('/\\.php$/', $path)) continue;
    $content = file_get_contents($path);
    // skip layout and public assets within views
    if (strpos($content, 'Auth::check') === false && strpos($content, 'Auth::requireLogin') === false) {
        // Heuristic: skip header/footer/partials
        $basename = basename($path);
        if (in_array($basename, ['header.php','footer.php','sidebar.php','topbar.php'])) continue;
        $missing[] = $path;
    }
}
if (empty($missing)) {
    echo "All view files contain login checks or are partials.\n";
} else {
    echo "View files missing Auth checks:\n";
    foreach ($missing as $m) echo " - " . str_replace(getcwd() . DIRECTORY_SEPARATOR, '', $m) . "\n";
}
