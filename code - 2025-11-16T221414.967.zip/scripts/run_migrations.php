<?php
// Simple migration runner: executes SQL files in the scripts/ directory
// Usage: php run_migrations.php

require_once __DIR__ . '/../config/config.php';

if (!defined('DB_HOST') || !defined('DB_NAME')) {
    echo "Please set database constants in config/config.php (DB_HOST, DB_NAME, DB_USER, DB_PASS)\n";
    exit(1);
}

$dir = __DIR__;
$files = glob($dir . '/*.sql');
if (empty($files)) {
    echo "No SQL migration files found in scripts/\n";
    exit(0);
}

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) {
    echo "DB connection failed: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error . "\n";
    exit(1);
}

foreach ($files as $file) {
    echo "Applying: " . basename($file) . "... ";
    $sql = file_get_contents($file);
    if ($sql === false) {
        echo "failed to read file\n";
        continue;
    }

    // Use multi_query to allow multiple statements
    if ($mysqli->multi_query($sql)) {
        // flush results
        do {
            if ($res = $mysqli->store_result()) {
                $res->free();
            }
        } while ($mysqli->more_results() && $mysqli->next_result());
        echo "OK\n";
    } else {
        echo "ERROR: " . $mysqli->error . "\n";
    }
}

$mysqli->close();
echo "Migrations complete.\n";
