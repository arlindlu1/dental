<?php
// Scans code for lang('key'[, 'default']) and Lang::get('key'[, 'default']) and compares against lang/en.php
$root = __DIR__ . '/../';
$en = include $root . 'lang/en.php';

function flatten($arr, $prefix = '') {
    $out = [];
    foreach ($arr as $k => $v) {
        $key = $prefix === '' ? $k : $prefix . '.' . $k;
        if (is_array($v)) {
            $out = array_merge($out, flatten($v, $key));
        } else {
            $out[$key] = $v;
        }
    }
    return $out;
}
$existing = flatten($en);

// Recursively scan files
$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$used = [];
$defaults = [];
foreach ($rii as $file) {
    if ($file->isDir()) continue;
    $path = $file->getPathname();
    // skip vendor, node_modules, storage, public, uploads, and assets directories
    $low = strtolower($path);
    $badDirs = ['' . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR, '' . DIRECTORY_SEPARATOR . 'node_modules' . DIRECTORY_SEPARATOR, '' . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR, '' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR, '' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR, '' . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR];
    foreach ($badDirs as $bd) {
        if (strpos($low, strtolower($bd)) !== false) continue 2;
    }
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    if (!in_array($ext, ['php', 'phtml', 'tpl'])) continue;
    $contents = @file_get_contents($path);
    if (!$contents) continue;
    // lang('key', 'Default')
    if (preg_match_all("/lang\('\s*([^']+)\s*'\s*(?:,\s*'([^']*)')?/", $contents, $m, PREG_SET_ORDER)) {
        foreach ($m as $match) {
            $k = $match[1];
            $used[$k] = true;
            if (isset($match[2]) && $match[2] !== '') $defaults[$k] = $match[2];
        }
    }
    // Lang::get('key', 'Default')
    if (preg_match_all("/Lang::get\(\'([^']+)\'\s*(?:,\s*\'([^']*)\')?\)/", $contents, $m2, PREG_SET_ORDER)) {
        foreach ($m2 as $match) {
            $k = $match[1];
            $used[$k] = true;
            if (isset($match[2]) && $match[2] !== '') $defaults[$k] = $match[2];
        }
    }
}

$usedKeys = array_keys($used);
sort($usedKeys);
$missing = [];
foreach ($usedKeys as $k) {
    if (!array_key_exists($k, $existing)) {
        $missing[$k] = $defaults[$k] ?? null;
    }
}

if (empty($missing)) {
    echo "No missing language keys found.\n";
    exit(0);
}

$validMissing = [];
foreach ($missing as $k => $d) {
    // ignore accidental 'key' captured from comments or non-localized code
    if ($k === 'key') continue;
    $validMissing[$k] = $d;
    echo $k . " => " . ($d ?? '') . "\n";
}

echo "\nTotal missing: " . count($validMissing) . "\n";
