# scripts/schedule_email_worker.ps1
# Helper PowerShell script to register a Scheduled Task that runs the PHP email worker every 5 minutes.
# Run in an elevated PowerShell prompt on Windows server where PHP CLI is available.

param(
    [string]$PhpPath = 'php',
    [string]$ProjectPath = "$PSScriptRoot\..",
    [int]$Minutes = 5,
    [string]$TaskName = 'dentisti_pro_EmailWorker'
)

$action = New-ScheduledTaskAction -Execute $PhpPath -Argument "`"$ProjectPath\scripts\email_worker.php`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes $Minutes) -RepetitionDuration ([TimeSpan]::MaxValue)
$principal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Description "Runs email worker to process queued emails every $Minutes minutes." -Force

Write-Host "Scheduled Task '$TaskName' registered to run every $Minutes minutes (PHP: $PhpPath)."