-- Migration: add table to mark users who must change password on first login
CREATE TABLE IF NOT EXISTS `password_change_required` (
  `user_id` INT NOT NULL PRIMARY KEY,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
