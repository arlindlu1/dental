<?php
// scripts/admin_auth_audit.php
// Scans `admin/` PHP files to ensure admin pages call Auth::checkAdmin() or Auth::requireAdmin()
$root = realpath(__DIR__ . '/..');
$adminDir = $root . DIRECTORY_SEPARATOR . 'admin';
$report = [];
foreach (new DirectoryIterator($adminDir) as $file) {
    if ($file->isDot() || !$file->isFile()) continue;
    $path = $file->getPathname();
    if (!preg_match('/\.php$/i', $path)) continue;
    $content = file_get_contents($path);
    // Skip helper files
    if (basename($path) === '_admin_guard.php') continue;
    if (stripos($content, 'Auth::checkAdmin') === false && stripos($content, 'Auth::requireAdmin') === false && stripos($content, "'_admin_guard.php'") === false) {
        $report[] = substr($path, strlen($root) + 1);
    }
}

if (empty($report)) {
    echo "All admin files include admin check or guard.\n";
    exit(0);
}

echo "Admin pages missing admin guard/check (manual review recommended):\n";
foreach ($report as $r) echo " - $r\n";
exit(0);
