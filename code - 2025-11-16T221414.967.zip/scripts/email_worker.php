<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Mailer.php';
require_once __DIR__ . '/../lib/Helpers.php';

$log = __DIR__ . '/../storage/logs/mailer.log';
file_put_contents($log, date('c') . " - Email worker started\n", FILE_APPEND);

$queue = read_email_queue();
if (empty($queue)) {
    file_put_contents($log, date('c') . " - Queue empty\n", FILE_APPEND);
    echo "Queue empty\n";
    exit(0);
}

$changed = false;
foreach ($queue as $i => $item) {
    if (!isset($item['type']) || $item['attempts'] >= 5) continue;

    $sent = false;
    try {
        if ($item['type'] === 'invite') {
            $to = $item['to'] ?? null;
            $inviteUrl = $item['invite_url'] ?? null;
            $clinicName = $item['clinic_name'] ?? '';
            if ($to && $inviteUrl) {
                $sent = Mailer::sendInvite($to, $inviteUrl, $clinicName);
            }
        }
    } catch (Exception $e) {
        $sent = false;
        file_put_contents($log, date('c') . " - Worker exception: " . $e->getMessage() . "\n", FILE_APPEND);
    }

    if ($sent) {
        file_put_contents($log, date('c') . " - Sent queued " . ($item['type'] ?? '?') . " to " . ($item['to'] ?? '') . "\n", FILE_APPEND);
        // remove this item
        unset($queue[$i]);
        $changed = true;
    } else {
        $queue[$i]['attempts'] = ($queue[$i]['attempts'] ?? 0) + 1;
        $queue[$i]['last_attempt'] = date('c');
        file_put_contents($log, date('c') . " - Failed send attempt " . $queue[$i]['attempts'] . " for " . ($item['to'] ?? '') . "\n", FILE_APPEND);
        $changed = true;
        if ($queue[$i]['attempts'] >= 5) {
            file_put_contents(__DIR__ . '/../storage/logs/email_failed.log', date('c') . " - Permanently failed: " . json_encode($queue[$i]) . "\n", FILE_APPEND);
            unset($queue[$i]);
        }
    }
}

if ($changed) write_email_queue(array_values($queue));
file_put_contents($log, date('c') . " - Email worker finished\n", FILE_APPEND);
echo "Worker finished\n";
