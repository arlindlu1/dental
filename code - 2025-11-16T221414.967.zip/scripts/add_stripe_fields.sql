-- Add Stripe fields to clinics table
ALTER TABLE clinics 
ADD COLUMN IF NOT EXISTS stripe_customer_id VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS stripe_subscription_id VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS subscription_status ENUM('active', 'canceled', 'past_due', 'trialing') DEFAULT 'trialing',
ADD COLUMN IF NOT EXISTS subscription_end_date DATE NULL;
