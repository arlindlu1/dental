# Runs PHP syntax check on all PHP files in the repo
$root = Split-Path -Path $PSScriptRoot -Parent
Write-Host "Running php -l syntax check from: $root"
$errors = @()
Get-ChildItem -Path $root -Recurse -Include *.php | ForEach-Object {
    $file = $_.FullName
    $proc = Start-Process -FilePath php -ArgumentList "-l`, `"$file`"" -NoNewWindow -RedirectStandardOutput -RedirectStandardError -PassThru -Wait
    $out = $proc.StandardOutput.ReadToEnd() + $proc.StandardError.ReadToEnd()
    if ($out -match "Errors parsing") {
        $errors += @{ file = $file; message = $out }
    }
}
if ($errors.Count -eq 0) {
    Write-Host "All PHP files passed syntax check." -ForegroundColor Green
    exit 0
} else {
    Write-Host "Syntax errors found in PHP files:" -ForegroundColor Red
    foreach ($e in $errors) {
        Write-Host "File: $($e.file)" -ForegroundColor Yellow
        Write-Host $e.message
    }
    exit 1
}
