<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Mailer.php';

$recipient = getenv('MAIL_TEST_TO') ?: (defined('SMTP_USER') ? SMTP_USER : (defined('MAIL_FROM') ? MAIL_FROM : null));
if (!$recipient) {
    echo "No test recipient configured. Set MAIL_TEST_TO env or ensure SMTP_USER / MAIL_FROM is set.\n";
    exit(1);
}

$inviteUrl = (rtrim(defined('APP_URL') ? APP_URL : '', '/')) ?: 'http://localhost';
$inviteUrl .= '/invite.php?token=test-token-' . bin2hex(random_bytes(6));

$sent = Mailer::sendInvite($recipient, $inviteUrl, 'Test Clinic');

if ($sent) {
    echo "Mail sent successfully to {$recipient}\n";
    @file_put_contents(__DIR__ . '/../storage/logs/mailer.log', date('c') . " - TEST mail sent to {$recipient}\n", FILE_APPEND);
    exit(0);
}

echo "Mail sending failed. Check storage/logs/mailer.log for details.\n";
exit(2);
