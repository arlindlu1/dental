Production tasks and checks

This project includes helper scripts to validate and operate the production-ready system.

1) Smoke checks
- `php scripts/smoke_checks.php`
  - Verifies DB connectivity, required tables, storage writable, and vendor installation.

2) SQL write audit
- `php scripts/sql_write_audit.php`
  - Scans PHP files for UPDATE/DELETE statements whose WHERE clause does not mention `clinic_id`. The output is a review list — fix manually or request automated patching.

3) Admin auth audit
- `php scripts/admin_auth_audit.php`
  - Scans files in `admin/` to ensure they include admin guard checks (`Auth::checkAdmin()`/`Auth::requireAdmin()` or include `_admin_guard.php`).

4) Email worker scheduling (Windows)
- Use `scripts/schedule_email_worker.ps1` to register a scheduled task that runs `php scripts/email_worker.php` every 5 minutes.
- Example (run as Administrator):
  powershell -ExecutionPolicy Bypass -File scripts/schedule_email_worker.ps1 -PhpPath "C:\\php\\php.exe" -ProjectPath "C:\\inetpub\\wwwroot\\project"

5) Migrations
- Ensure DB is reachable; run `php scripts/run_migrations.php` or apply SQL files in `install/` manually.

6) SMTP
- If SMTP auth fails with `535`, verify mailbox password or create an app-specific password with the provider. Use `scripts/smtp_probe.php` to test SMTP connectivity.

7) Email queue
- The file-based queue is at `storage/email_queue.json`. Ensure `storage/` is writable and set up the scheduled task to drain the queue.

If you want, I can automatically apply fixes for the remaining write statements missing `clinic_id` scoping, but I recommend reviewing the `scripts/sql_write_audit.php` output first.
