<?php
$root = __DIR__ . '/../admin/';
$it = new DirectoryIterator($root);
$missing = [];
foreach ($it as $file) {
    if ($file->isDot() || !$file->isFile()) continue;
    if ($file->getExtension() !== 'php') continue;
    $path = $file->getRealPath();
    $content = file_get_contents($path);
    // consider present if checkAdmin or requireAdmin present
    if (strpos($content, 'Auth::checkAdmin') === false && strpos($content, 'Auth::requireAdmin') === false) {
        $missing[] = $path;
    }
}
if (empty($missing)) {
    echo "All admin entry files contain admin auth checks.\n";
} else {
    echo "Admin files missing auth checks:\n";
    foreach ($missing as $m) echo " - " . str_replace(getcwd() . DIRECTORY_SEPARATOR, '', $m) . "\n";
}
