<?php
require_once __DIR__ . '/../config/config.php';
// Trigger a test exception to verify error logging
throw new Exception('Test exception from scripts/test_error.php — verify errors.log');
