#!/usr/bin/env bash
# Packaging script for shared hosting (Linux/macOS)
# Usage: run from project root: ./scripts/package_for_shared_host.sh
set -euo pipefail

OUTPUT=${1:-release.zip}
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TMP_DIR="/tmp/$(basename "$ROOT_DIR")-package-$(date +%s)"

echo "Packaging project at: $ROOT_DIR"

# Check composer
if ! command -v composer >/dev/null 2>&1; then
  echo "Composer not found. Install Composer and retry." >&2
  exit 1
fi

# Run composer install
echo "Running composer install --no-dev --optimize-autoloader"
composer install --no-dev --optimize-autoloader

mkdir -p "$TMP_DIR"

echo "Copying files to temp dir: $TMP_DIR"
rsync -a --exclude ".git" --exclude ".gitignore" --exclude "node_modules" --exclude "tests" --exclude ".vscode" --exclude ".idea" "$ROOT_DIR/" "$TMP_DIR/"

# Ensure uploads and storage/logs exist
mkdir -p "$TMP_DIR/uploads"
mkdir -p "$TMP_DIR/storage/logs"

# Create zip
cd "$TMP_DIR"
zip -r "$ROOT_DIR/$OUTPUT" .

# Cleanup
cd /
rm -rf "$TMP_DIR"

echo "Package created: $ROOT_DIR/$OUTPUT"
echo "Upload $ROOT_DIR/$OUTPUT to your shared hosting and extract it into the public_html (or the desired folder)."
echo "After extraction, visit /install/installer.php to run the web installer."
