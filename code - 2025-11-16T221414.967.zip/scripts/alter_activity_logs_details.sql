-- Make sure activity_logs.details can hold JSON and longer text
ALTER TABLE activity_logs
MODIFY COLUMN details TEXT NULL;
