# Packaging script for shared hosting (PowerShell)
# Usage: run from project root with PowerShell
# This script runs composer install, prepares a clean package and creates release.zip

param(
    [string]$OutputZip = "release.zip"
)

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "Packaging project at: $root"

# Check composer
$composer = Get-Command composer -ErrorAction SilentlyContinue
if (-not $composer) {
    Write-Error "Composer is not available in PATH. Please install Composer and try again."
    exit 1
}

# Run composer install --no-dev --optimize-autoloader
Write-Host "Running composer install --no-dev --optimize-autoloader"
composer install --no-dev --optimize-autoloader
if ($LASTEXITCODE -ne 0) {
    Write-Error "composer install failed. Fix errors and retry."
    exit 1
}

# Prepare temp package directory
$tmp = Join-Path $env:TEMP ([IO.Path]::GetRandomFileName())
New-Item -ItemType Directory -Path $tmp | Out-Null
Write-Host "Created temp dir: $tmp"

# Copy files to temp excluding dev artifacts
$excludes = @('.git', '.gitignore', 'node_modules', 'tests', '.vscode', '.idea')
Get-ChildItem -Path $root -Force | ForEach-Object {
    if ($excludes -contains $_.Name) { return }
    $dest = Join-Path $tmp $_.Name
    if ($_.PSIsContainer) {
        robocopy $_.FullName $dest /E /NFL /NDL /NJH /NJS /nc /ns /nfl | Out-Null
    } else {
        Copy-Item $_.FullName $dest -Force
    }
}

# Ensure uploads and storage/logs directories exist
New-Item -ItemType Directory -Path (Join-Path $tmp 'uploads') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $tmp 'storage\logs') -Force | Out-Null

# Create the zip
$zipPath = Join-Path $root $OutputZip
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Write-Host "Creating zip: $zipPath"
Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zipPath -Force

# Cleanup temp
Remove-Item -Recurse -Force $tmp

Write-Host "Package created: $zipPath"
Write-Host "Upload $zipPath to your shared hosting and extract it into the public_html (or the desired folder)."
Write-Host "After extraction, visit /install/installer.php to run the web installer."
