<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/Database.php';

// Print last 200 lines of the error log to help debugging
$logFile = __DIR__ . '/../storage/logs/errors.log';
if (file_exists($logFile)) {
    echo "== Last errors.log (tail 200) ==\n";
    $lines = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        echo "Cannot read errors.log\n";
    } else {
        $tail = array_slice($lines, -200);
        foreach ($tail as $l) echo $l . "\n";
    }
} else {
    echo "errors.log not found at $logFile\n";
}

// Connect to DB and show the most recent user rows (last 5)
try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $res = $conn->query("SELECT id, clinic_id, email, password, name, role, is_active, created_at FROM users ORDER BY created_at DESC LIMIT 5");
    if ($res) {
        echo "\n== Last 5 users ==\n";
        while ($row = $res->fetch_assoc()) {
            echo sprintf("id=%s clinic_id=%s email=%s is_active=%s created_at=%s\n", $row['id'], $row['clinic_id'], $row['email'], $row['is_active'], $row['created_at']);
            echo "password hash: " . substr($row['password'],0,80) . "...\n";
        }
    } else {
        echo "Failed to query users table: " . $conn->error . "\n";
    }
} catch (Exception $e) {
    echo "DB error: " . $e->getMessage() . "\n";
}

// Helpful note
echo "\nRun: php scripts/diagnose_clinic_create.php from project root.\n";
