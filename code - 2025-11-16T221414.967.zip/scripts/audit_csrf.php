<?php
$root = __DIR__ . '/../';
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$matches = [];
foreach ($files as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getRealPath();
    if (!preg_match('/\\.php$/', $path)) continue;
    // skip vendor
    if (strpos($path, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR) !== false) continue;
    $content = file_get_contents($path);
    if (strpos($content, "\$_SERVER['REQUEST_METHOD']") !== false) {
        $hasCsrf = strpos($content, 'verifyCSRFToken') !== false;
        $matches[] = [$path, $hasCsrf];
    }
}
foreach ($matches as [$p, $has]) {
    echo ($has ? '[OK] ' : '[MISSING CSRF] ') . str_replace(getcwd() . DIRECTORY_SEPARATOR, '', $p) . PHP_EOL;
}
