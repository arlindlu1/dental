<?php
// scripts/sql_write_audit.php
// Scans PHP files for UPDATE/DELETE/INSERT statements that may be missing tenant scoping (clinic_id).
// This script is read-only and prints a report for review.

$root = realpath(__DIR__ . '/..');
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$pattern = '/\b(UPDATE|DELETE FROM)\b[^;\n]+WHERE[^;\n]*/i';
$report = [];

foreach ($iterator as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getPathname();
    if (!preg_match('/\.php$/i', $path)) continue;
    // Skip vendor
    if (strpos($path, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR) !== false) continue;
    $content = file_get_contents($path);
    if (preg_match_all($pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
        foreach ($matches[0] as $m) {
            $sql = $m[0];
            // If line contains clinic_id, consider it safe
            if (stripos($sql, 'clinic_id') === false) {
                // Determine line number
                $pos = $m[1];
                $line = substr_count(substr($content, 0, $pos), "\n") + 1;
                $report[] = [
                    'file' => substr($path, strlen($root) + 1),
                    'line' => $line,
                    'snippet' => trim(preg_replace('/\s+/', ' ', $sql)),
                ];
            }
        }
    }
}

if (empty($report)) {
    echo "No write statements without 'clinic_id' in WHERE detected (report empty).\n";
    exit(0);
}

echo "Potential tenant-scoping issues (manual review recommended):\n";
foreach ($report as $r) {
    echo "- {$r['file']}:{$r['line']} => {$r['snippet']}\n";
}

exit(0);
